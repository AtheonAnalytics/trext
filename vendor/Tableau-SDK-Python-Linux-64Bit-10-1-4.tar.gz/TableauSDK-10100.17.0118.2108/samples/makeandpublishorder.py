# -----------------------------------------------------------------------------
#
# This file is the copyrighted property of Tableau Software and is protected
# by registered patents and other applicable U.S. and international laws and
# regulations.
#
# Unlicensed use of the contents of this file is prohibited. Please refer to
# the NOTICES.txt file for further details.
#
# -----------------------------------------------------------------------------
from datetime import datetime
import sys
from tableausdk import *
from tableausdk.Extract import *
from tableausdk.Server import *


# Define the table's schema
def makeTableDefinition():
    tableDef = TableDefinition()
    tableDef.setDefaultCollation(Collation.EN_GB)
    tableDef.addColumn('Purchased',       Type.DATETIME)
    tableDef.addColumn('Product',         Type.CHAR_STRING)
    tableDef.addColumn('uProduct',        Type.UNICODE_STRING)
    tableDef.addColumn('Price',           Type.DOUBLE)
    tableDef.addColumn('Quantity',        Type.INTEGER)
    tableDef.addColumn('Taxed',           Type.BOOLEAN)
    tableDef.addColumn('Expiration Date', Type.DATE)

    # Column with non-default collation
    tableDef.addColumnWithCollation('Produkt', Type.CHAR_STRING, Collation.DE)

    return tableDef

# Print a Table's schema to stderr.
def printTableDefinition(tableDef):
    for i in range(tableDef.getColumnCount()):
        type = tableDef.getColumnType(i)
        name = tableDef.getColumnName(i)
        print >> sys.stderr, "Column {0}: {1} ({2:#06x})".format(i, name, type)

# Insert a few rows of data.
def insertData(table):
    tableDef = table.getTableDefinition()

    row = Row(tableDef)
    row.setDateTime(0, 2012, 7, 3, 11, 40, 12, 4550) # Purchased
    row.setCharString(1, 'Beans')                    # Product
    row.setString(    2, u'uniBeans'   )             # uProduct
    row.setDouble(    3, 1.08)                       # Price
    row.setDate(      6, 2029, 1, 1)                 # Expiration date
    row.setCharString(7, 'Bohnen')

    for i in range(10):
        row.setBoolean(5, i % 2 == 1)                # Taxed
        row.setInteger(4, i * 10)                    # Quantity
        table.insert(row)

try:
    # Initialize Tableau Extract API
    ExtractAPI.initialize()

    with Extract('order2-py.tde') as extract:

        table = None
        if not extract.hasTable('Extract'):
            # Table does not exist; create it
            tableDef = makeTableDefinition()
            table = extract.addTable('Extract', tableDef)
        else:
            # Open an existing table to add more rows
            table = extract.openTable('Extract')

        tableDef = table.getTableDefinition()
        printTableDefinition(tableDef)

        insertData(table)

        extract.close()

    # Clean up Tableau Extract API
    ExtractAPI.cleanup()

except TableauException, e:
    print 'Something bad happened:', e

try:
    # Initialize Tableau Server API
    ServerAPI.initialize()

    # Create the server connection object
    serverConnection = ServerConnection()

    # Connect to the server
    serverConnection.connect('http://localhost', 'username', 'password', 'siteID');

    # Publish order-py.tde to the server under the default project with name Order-py
    serverConnection.publishExtract('order2-py.tde', 'default', 'Order2-py', False);

    # Disconnect from the server
    serverConnection.disconnect();

    # Destroy the server connection object
    serverConnection.close();

    # Clean up Tableau Server API
    ServerAPI.cleanup();

except TableauException, e:
    # Handle the exception depending on the type of exception received

    errorMessage = "Error: "

    if e.errorCode == Result.INTERNAL_ERROR:
        errorMessage += "INTERNAL_ERROR - Could not parse the response from the server."

    elif e.errorCode == Result.INVALID_ARGUMENT:
        errorMessage += "INVALID_ARGUMENT - " + e.message

    elif e.errorCode == Result.CURL_ERROR:
        errorMessage += "CURL_ERROR - " + e.message

    elif e.errorCode == Result.SERVER_ERROR:
        errorMessage += "SERVER_ERROR - " + e.message

    elif e.errorCode == Result.NOT_AUTHENTICATED:
        errorMessage += "NOT_AUTHENTICATED - " + e.message

    elif e.errorCode == Result.BAD_PAYLOAD:
        errorMessage += "BAD_PAYLOAD - Unknown response from the server. Make sure this version of Tableau API is compatible with your server."

    elif e.errorCode == Result.INIT_ERROR:
        errorMessage += "INIT_ERROR - " + e.message

    else:
        errorMessage += "An unknown error occured."

    print errorMessage

