#!/usr/bin/python
from exasol import outputService
outputService()
