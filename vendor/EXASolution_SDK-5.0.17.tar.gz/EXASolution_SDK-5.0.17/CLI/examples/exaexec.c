/*********************************************************
*                                                        *
*       This code is property of EXASOL AG Germany.      *
*       It may not be redistributed or sold by others.   *
*                                                        *
*       Copyright EXASOL AG, 2012 - 2015                 *
*       Author: Michael Tenchea                          *
*           (Michael.Tenchea@exasol.com)                 *
*                                                        *
*********************************************************/


/*
 * This program was created for testing purpouses. It is currently used to test some EXA functionalities.
 * We have added it to the SDK in the intention of illustrating some basics of the EXA-CLI interface.
 * 
 * User parameters:
 *   -c <hostList:port> A list of hosts and ports that can be used to connect to the EXASolution
 *   -u <user> EXA user name
 *   -P <password> EXA user password
 *   -s <schema> schema to work in (optional)
 *   -f <fetchSize> size of the blocks to be fetched (optional)
 *   -acoff sets autocommit to off before connecting
 * Execution modes are selected by user. Depending from Exec-mode this program will know what to do:
 * 
 *   -execDirect
 *      Executes a statement and prints the number of columns and rows in the resultset.
 *      Usage: echo "select * from cat" | ./exaexec -u sys -p 2255 -h cmw1 -P exasol -execDirect
 * 
 *   -prepareOnly
 *      Prepare a statement without executing it. Prints the number of columns returned by prepare.
 *      Usage: echo "select * from cat" | ./exaexec -u sys -p 2255 -h cmw1 -P exasol -prepareOnly
 * 
 *   -preparedExec
 *      Prepare a statement and executes it. Prints number of rows in the resultset returned by execute.
 *      Usage: echo "select * from cat" | ./exaexec -u sys -p 2255 -h cmw1 -P exasol -preparedExec
 * 
 *   -batchExec
 *      Batch executes all statements entered in stdin. Statements must be separated by "\n\n".
 *      Returns the rowcount for each statement.
 *      Usage:  echo -e "select * from cat \n\n select * from cat" | ./exaexec -u sys -p 2255 -h cmw1 -P exasol -batchExec
 *    
 *   -preparedParams
 *      This option is used to copy a table into an other. The tables must have similar structures.
 *      Herefor a prepared statement that requires parameters is used. This statement is executed 
 *      with parameter values read from a table in the database.
 *      Usage example:
 *        echo "create schema test" | ./exaexec -u sys -p 2255 -h cmw1 -P exasol -execDirect
 *        echo "create table src(i decimal(18,0))" | ./exaexec -u sys -p 2255 -h cmw1 -P exasol -s test -execDirect
 *        echo "insert into src values 1, 2, 3" | ./exaexec -u sys -p 2255 -h cmw1 -P exasol -s test -execDirect
 *        echo "create table dest(i decimal(18,0))" | ./exaexec -u sys -p 2255 -h cmw1 -P exasol -s test -execDirect
 *        echo "insert into dest values (?)" | ./exaexec -u sys -p 2255 -h cmw1 -P exasol -s test -t src -preparedParams
 *        echo "select * from dest" | ./exaexec -u sys -p 2255 -h cmw1 -P exasol -s test -execDirect
 * 
 *   -preparedParamsOutput
 *      Works like preparedParams. If the result of prepared execution is a resultset, the data is printed on stdout. 
 */ 


#include "exaCInterface.h"

#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef __cplusplus
    #include <stdbool.h>
#endif

#ifdef _WIN32
    #pragma warning (disable : 4996)
#endif

#define MAX_IDENTIFIER_OCTET_LEN 512

typedef enum ExecMode
{
    NotInitialized=0,
    ExecDirect=1,
    PrepareOnly=2,
    PreparedExec=3,
    BatchExec=4,
    PreparedParams=5,
    PreparedParamsOutput=6
} ExecMode;

//This struct manages the user input:
typedef struct SQLReader
{
    /* private */
    char * buffer;
    int bufferLen;
    /* public */
    char exaHost[MAX_IDENTIFIER_OCTET_LEN];
    char exaPort[32];
    char exaUser[MAX_IDENTIFIER_OCTET_LEN];
    char exaConnectionString[MAX_IDENTIFIER_OCTET_LEN*10];
    char exaPassword[MAX_IDENTIFIER_OCTET_LEN];
    char exaSchema[MAX_IDENTIFIER_OCTET_LEN];
    char dataTable[MAX_IDENTIFIER_OCTET_LEN];
    char inputFile[MAX_PATH];
    ExecMode execMode;
    bool acoff;
    SQLULEN fetchSize;
    FILE * file;
} SQLReader;

SQLReader* newSQLReader()
{
    SQLReader* SQLR = (SQLReader*) malloc(sizeof(SQLReader));
    SQLR->buffer=NULL;
    SQLR->bufferLen=0;
    SQLR->execMode=NotInitialized;
    SQLR->exaHost[0]=0;
    SQLR->exaPort[0]=0;
    SQLR->exaConnectionString[0]=0;
    SQLR->exaUser[0]=0;
    SQLR->exaPassword[0]=0;
    SQLR->exaSchema[0]=0;
    SQLR->dataTable[0]=0;
    SQLR->fetchSize=5000;
    SQLR->inputFile[0]=0;
    SQLR->file=NULL;
    SQLR->acoff=false;
    return SQLR;
}

void closeSQLReader(SQLReader* SQLR)
{
    if (stdin!=SQLR->file && NULL!=SQLR->file) fclose(SQLR->file);
    free(SQLR->buffer);
}

//return a 0 terminated str if found, NULL if eof
char* NextSQL(SQLReader* SQLR)
{
    int sqlLen=0;
    while (!feof(SQLR->file))
    {
        if (SQLR->bufferLen<=sqlLen)
        {
            //Resizing
            SQLR->bufferLen+=2000;
            SQLR->buffer = (char*) realloc(SQLR->buffer, sizeof(char) * SQLR->bufferLen);
        }
        if (0==fread(SQLR->buffer+sqlLen, 1, 1, SQLR->file))
        {
            if (sqlLen==0) return NULL;
            *(SQLR->buffer+sqlLen)='\n';
        }
        if (sqlLen>0 && *(unsigned char*)(SQLR->buffer+sqlLen-1)=='\n' && *(unsigned char*)(SQLR->buffer+sqlLen)=='\n')
        {
            *(SQLR->buffer+sqlLen-1)=0;
            return SQLR->buffer;
        }
        sqlLen++;
    }
    if (sqlLen==0) 
    { 
         free(SQLR->buffer);
         SQLR->buffer=NULL;
    }
    return SQLR->buffer;
}

int ReadCommandLine(SQLReader* SQLR, int argc, char ** argv)
{
    for (int i=1; i<argc-1; i++)
    {
        if (0==strcmp(argv[i], "-u")) strcpy(SQLR->exaUser, argv[i+1]);
        if (0==strcmp(argv[i], "-p")) strcpy(SQLR->exaPort, argv[i+1]);
        if (0==strcmp(argv[i], "-h")) strcpy(SQLR->exaHost, argv[i+1]);
        if (0==strcmp(argv[i], "-c")) strcpy(SQLR->exaConnectionString, argv[i+1]);
        if (0==strcmp(argv[i], "-P")) strcpy(SQLR->exaPassword, argv[i+1]);
        if (0==strcmp(argv[i], "-s")) strcpy(SQLR->exaSchema, argv[i+1]);
        if (0==strcmp(argv[i], "-t")) strcpy(SQLR->dataTable, argv[i+1]);
        if (0==strcmp(argv[i], "-f")) SQLR->fetchSize=atol(argv[i+1]);
        if (0==strcmp(argv[i], "-i")) strcpy(SQLR->inputFile, argv[i+1]);
    }
    for (int i=1; i<argc; i++)
    {
        if (0==strcmp(argv[i], "-execDirect")) SQLR->execMode=ExecDirect;
        if (0==strcmp(argv[i], "-prepareOnly")) SQLR->execMode=PrepareOnly;
        if (0==strcmp(argv[i], "-preparedExec")) SQLR->execMode=PreparedExec;
        if (0==strcmp(argv[i], "-execPrepared")) SQLR->execMode=PreparedExec;
        if (0==strcmp(argv[i], "-batchExec")) SQLR->execMode=BatchExec;
        if (0==strcmp(argv[i], "-execBatch")) SQLR->execMode=BatchExec;
        if (0==strcmp(argv[i], "-preparedParams")) SQLR->execMode=PreparedParams;
        if (0==strcmp(argv[i], "-preparedParamsOutput")) SQLR->execMode=PreparedParamsOutput;
        if (0==strcmp(argv[i], "-acoff")) SQLR->acoff=true;
    }
    if (0==strlen(SQLR->exaConnectionString))
    {
        if (0==strlen(SQLR->exaHost)) { printf("ERROR=server host not specified: -h <exa host>\n"); return -1; }
        if (0==strlen(SQLR->exaPort)) { printf("ERROR=port not specified: -p <exa port>\n"); return -1; }
    }
    if (0==strlen(SQLR->exaUser)) { printf("ERROR=user name not specified: -u <exa username>\n"); return -1; }
    if (0==strlen(SQLR->exaPassword)) { printf("ERROR=password not specified: -P <exa password>\n"); return -1; }
    if ((PreparedParams==SQLR->execMode || PreparedParamsOutput==SQLR->execMode) && 0==strlen(SQLR->dataTable)) { printf("ERROR=preparedParams mode selected but no parameter table specified: -t <data table name>\n"); return -1; }
    if (NotInitialized==SQLR->execMode) { printf("ERROR=exec mode not specified: -execDirect, -prepareOnly, -preparedExec, -preparedParams, -preparedParamsOutput or -batchExec\n"); return -1; }     
    if (SQLR->fetchSize<1) { printf("Invalid fetch size specified.\n"); return -1; }
    if (0<strlen(SQLR->inputFile)) 
    { 
        SQLR->file=fopen(SQLR->inputFile, "rb");
        if (NULL==SQLR->file) { printf("Error opening input file %s\n", SQLR->inputFile); return -1; }
    } else
    {
        SQLR->file=stdin;
    }
    return 0;
}

//Reads all error messages from the specified handle
int PrintError(SQLSMALLINT handleType, SQLHANDLE handle)
{
    char error[MAX_IDENTIFIER_OCTET_LEN];
    SQLSMALLINT count=1;
    while (SQL_SUCCESS==EXAGetDiagRec(handleType, handle, count, NULL, NULL, (SQLCHAR*)error, sizeof(error), NULL))
    {   
        if (1==count) printf ("SQL-ERROR=");
        printf("%s;", error);
        count++;
    }
    if (count>1)
    {
        printf("\n");
        return SQL_SUCCESS;
    }
    return SQL_ERROR;
}

//Reads the resultset from a statement and writes data to stdout
int GetResults(SQLHSTMT hstmt, ExecMode executionMode)
{
    do {
        //If statement contains no error, do:
        if (SQL_ERROR==PrintError(SQL_HANDLE_STMT, hstmt))
        {
            SQLSMALLINT nCols=0;
            EXANumResultCols(hstmt, &nCols);
            char * buff=NULL;
            char columnName[MAX_IDENTIFIER_OCTET_LEN];
            int buffLen=0;
            int pos=0;
            SQLULEN colSize=0;
            SQLRETURN ret=0;
            switch(executionMode)
            {
            case PreparedParamsOutput:
                //Calculate buffer size and printing column names
                for (SQLSMALLINT col=1; col<=nCols; col++)
                {
                    EXADescribeCol(hstmt, col, (SQLCHAR*)columnName, sizeof(columnName), NULL, NULL, &colSize, NULL, NULL);
                    printf("%*.*s ", (int)colSize, (int)colSize, columnName);
                    buffLen+=(int)colSize+1;
                }
                printf("\n");
                //Allocating fetch buffer
                buff = (char*) malloc(sizeof(char) * (buffLen+1));
                //Binding all columns in the result set. The output type will be SQL_CHAR. All data will be retrived as char form EXA-CLI.
                for (SQLSMALLINT col=1; col<=nCols; col++)
                {
                    //Read column description. Function parameters that are NULL, are just not needed.
                    EXADescribeCol(hstmt, col, (SQLCHAR*)NULL, 0, NULL, NULL, &colSize, NULL, NULL);
                    for(int i=0; i<(int)colSize; i++) { printf("-"); }
                    printf(" ");

                    //Binding columns to some buffer. In this case the output datatype will be SQL_CHAR
                    EXABindCol(hstmt, col, SQL_CHAR, (buff+pos), colSize+1, NULL);
                    pos+=(int)colSize+1;
                }

                //Telling EXA-CLI that only one row at the time is to be written
                printf("\n");
                EXASetStmtAttr(hstmt, SQL_ATTR_ROW_ARRAY_SIZE, (SQLPOINTER)1, 4);
                memset(buff, 32, buffLen);

                //Fetching data into the allocated buffer
                ret=EXAFetch(hstmt);

                //Fetch and display data
                while (SQL_SUCCESS==ret || SQL_SUCCESS_WITH_INFO==ret)
                {
                    for(int i=0; i<buffLen; i++) { if (0==buff[i]) buff[i]=32; }
                    buff[buffLen]=0;
                    printf("%s\n", buff);
                    memset(buff, 32, buffLen);
                    ret=EXAFetch(hstmt);
                }

                //Delete column bindings. It is very important to free the statements this way in order
                //to reuse them!
                EXAFreeStmt(hstmt, SQL_UNBIND);
                EXAFreeStmt(hstmt, SQL_CLOSE);

                //Drawing a line of "#" between result tables:
                for(int i=0; i<buffLen-1; i++) printf("#");
                printf("\n");
                free(buff);
                buff=NULL;
                break;
            default:
                //Displays some general information on the result of the SQL
                printf("----------\n");
                printf("RESULTCOLS=%i\n", (int)nCols);
                SQLBIGINT nLines=0;
                EXAGetStmtAttr(hstmt, EXA_STMT_ATTR_TOTAL_ROWS, &nLines, 0, NULL);
                printf("ROWS=%lli\n", (long long int)nLines);
                SQLSMALLINT nParams=0;
                EXANumParams(hstmt, &nParams);
                printf("PARAMCOUNT=%i\n", (int)nParams);
                SQLLEN rowCount=0;
                EXARowCount(hstmt, &rowCount);
                printf("ROWSAFFECTED=%i\n", (int)rowCount);
                break;
            }
        }

    //Looking for more results in the statement.
    } while (SQL_NO_DATA!=EXAMoreResults(hstmt));

    //Closes the statement. 
    EXAFreeStmt(hstmt, SQL_CLOSE);

    return 0;
}


//Main function: depending on exec-mode takes the requested actions.
int main(int argc, char ** argv)
{
    setlocale(LC_CTYPE, "");
    //Reading user input
    SQLReader* input = newSQLReader();
    if (0!=ReadCommandLine(input, argc, argv)) return -1;
    char * sqlStr;
    SQLHENV henv;
    SQLHDBC hdbc;
    SQLHSTMT hstmt;
    char tmp[1024];

    //Allocating handles: 
    //Environment handle
    EXAAllocHandle(SQL_HANDLE_ENV, NULL, &henv);

    //Connection handle
    EXAAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);

    //Check if autocommit must be disabled (default it is on)
    if (true==input->acoff)
    {
        EXASetConnectAttr(hdbc, SQL_ATTR_AUTOCOMMIT, (SQLPOINTER)SQL_AUTOCOMMIT_OFF, 0);
    }

    //Connect to the server
    if (0!=strlen(input->exaConnectionString))
    {
        if (SQL_SUCCESS!=EXAServerConnect(hdbc, input->exaConnectionString, SQL_NTS,
                                            input->exaPort, SQL_NTS,
                                            input->exaUser, SQL_NTS,
                                            input->exaPassword, SQL_NTS)) { PrintError(SQL_HANDLE_DBC, hdbc); return -1; }
    } else
    {
        if (SQL_SUCCESS!=EXAServerConnect(hdbc, input->exaHost, SQL_NTS,
                                            input->exaPort, SQL_NTS,
                                            input->exaUser, SQL_NTS,
                                            input->exaPassword, SQL_NTS)) { PrintError(SQL_HANDLE_DBC, hdbc); return -1; }
    } 
    //Allocate statement handle
    EXAAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);

    //Opening schema
    if (strlen(input->exaSchema))
    {
        sprintf(tmp, "open schema %s", input->exaSchema);
        if (SQL_SUCCESS!=EXAExecDirect(hstmt, (SQLCHAR*)tmp, SQL_NTS)) { PrintError(SQL_HANDLE_STMT, hstmt); return -1; }
    }

    //For each SQL from input, takes requested action:
    while (NULL!=(sqlStr=NextSQL(input)))
    {
        if (strlen(sqlStr))
        {
            switch (input->execMode)
            {
            case ExecDirect:

                //Executes SQL in server
                if (SQL_SUCCESS==EXAExecDirect(hstmt, (SQLCHAR*)sqlStr, SQL_NTS)) GetResults(hstmt, ExecDirect);
                else { PrintError(SQL_HANDLE_STMT, hstmt); EXAFreeStmt(hstmt, SQL_CLOSE); }
                break;
            case PrepareOnly:

                //Prepare SQL for execution
                if (SQL_SUCCESS==EXAPrepare(hstmt, (SQLCHAR*)sqlStr, SQL_NTS)) GetResults(hstmt, PrepareOnly);
                else { PrintError(SQL_HANDLE_STMT, hstmt); EXAFreeStmt(hstmt, SQL_CLOSE); }
                break;
            case PreparedExec:

                //Prepare SQL for execution
                if (SQL_SUCCESS==EXAPrepare(hstmt, (SQLCHAR*)sqlStr, SQL_NTS)) {}
                else { PrintError(SQL_HANDLE_STMT, hstmt); EXAFreeStmt(hstmt, SQL_CLOSE); }

                //Executing the prepared SQL associated to hstmt
                if (SQL_SUCCESS==EXAExecute(hstmt)) GetResults(hstmt, PreparedExec);
                else { PrintError(SQL_HANDLE_STMT, hstmt); EXAFreeStmt(hstmt, SQL_CLOSE); }
                break;
            case BatchExec:
                //Adds an SQL string to the batch list
                EXAPrepareBatch(hstmt, sqlStr, SQL_NTS);
                break;
            case PreparedParams:
            case PreparedParamsOutput:

                //Closes the statement (it may be open from a previous run)
                EXAFreeStmt(hstmt, SQL_CLOSE);

                //Clears the parameter bindings
                EXAFreeStmt(hstmt, SQL_RESET_PARAMS);

                //Prepare SQL
                if (SQL_SUCCESS==EXAPrepare(hstmt, (SQLCHAR*)sqlStr, SQL_NTS))
                {
                    SQLHSTMT hstmt_data;

                    //Allocate statement to read parameter data from the table specified with "-t"
                    EXAAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt_data);
                    char sqlStr[MAX_IDENTIFIER_OCTET_LEN*2];
                    sprintf(sqlStr, "select * from %s", input->dataTable);

                    //Reading all data from the table
                    if (SQL_SUCCESS!=EXAExecDirect(hstmt_data, (SQLCHAR*)sqlStr, SQL_NTS)) { PrintError(SQL_HANDLE_STMT, hstmt_data); return -1; }
                    SQLSMALLINT nColumns, dataType, ret;
                    SQLLEN typeSize;
                    SQLULEN rowsFetched;

                    //Get the number of columns in the result table
                    EXANumResultCols(hstmt_data, &nColumns);
                    if (nColumns<=0) { printf("Error: 0 parameter columns read.\n"); return -1; }

                    //Data buffer array
                    char ** buffers;

                    //Indicator buffer array. (see also ODBC reference)
                    SQLLEN ** indicators;
                    buffers = (char**) malloc(sizeof(char*) * (nColumns+1));
                    indicators = (SQLLEN**) malloc(sizeof(SQLLEN*) * (nColumns+1));
                    SQLHDESC ird;

                    //Reads the implementation row descriptor handle from the statement
                    EXAGetStmtAttr(hstmt_data, SQL_ATTR_IMP_ROW_DESC, &ird, 0, NULL);
                    for (SQLSMALLINT col=1; col<=nColumns; col++)
                    {
                        indicators[col] = (SQLLEN*) malloc(sizeof(SQLLEN) * input->fetchSize);

                        //Read EXA native data types. Using EXA data types is only useful if data must be transfered from EXA to EXA. In any other
                        //cases use SQL datatypes (ODBC types). SQL datatypes can be retrived using EXADescribeCol.
                        //EXA native types are used here to increase the speed and lower the memory usage while transfering data.
                        EXADescribeCol2(hstmt_data, col, &dataType);

                        //Read buffer size for each column
                        EXAGetDescField(ird, col, SQL_DESC_OCTET_LENGTH, (SQLPOINTER)(&typeSize), sizeof(typeSize), NULL);
                        //Decimal type stored in 4 bytes
                        if (EXA_INT32==dataType) typeSize=4;
                        //Decimal type stored in 8 bytes
                        if (EXA_INT64==dataType) typeSize=8;
                        //Decimal type stored in 16 bytes
                        if (EXA_INT128==dataType) typeSize=16;
                        
                        //Char types need room for ending 0
                        if (SQL_VARCHAR==dataType || SQL_CHAR==dataType) typeSize=typeSize*4+4; //*4 because of unicode characters, +4 for termination

                        //Allocate column buffers
                        buffers[col] = (char*) malloc(sizeof(char) * (input->fetchSize*typeSize));
                        SQLULEN columnSize;
                        SQLSMALLINT decimalDigits;
                        if (SQL_ERROR==EXADescribeCol(hstmt_data, col, (SQLCHAR*)NULL, 0, NULL, NULL, &columnSize, &decimalDigits, NULL))  
                        {
                            PrintError(SQL_HANDLE_STMT, hstmt_data); 
                            return -1; 
                        }
                        //Binding buffers to the data in the result set
                        if (SQL_ERROR==EXABindCol(hstmt_data, col, dataType, buffers[col], typeSize, indicators[col]))  
                        { 
                            PrintError(SQL_HANDLE_STMT, hstmt_data); 
                            return -1; 
                        }

                        //Binding parameters to the buffers containing the data. In this program here, the buffers from the fetch are reused in 
                        //prepared statements. This procedure is used to gain best performance and optimum memory usage.
                        if (SQL_ERROR==EXABindParameter(hstmt, col, SQL_PARAM_INPUT, dataType, SQL_DEFAULT, columnSize, decimalDigits, buffers[col], typeSize, indicators[col])) { PrintError(SQL_HANDLE_STMT, hstmt); return -1; }
                    }
                    do {
                        //Fetch metod is default: fetch by column (see ODBC column wise binding)
                        //Specifies how many rows will be fetched
                        EXASetStmtAttr(hstmt_data, SQL_ATTR_ROW_ARRAY_SIZE, (SQLPOINTER)((size_t)input->fetchSize), 0);
                        
                        //Specifies a variable where fetch can write how mamy rows was realy fetched
                        EXASetStmtAttr(hstmt_data, SQL_ATTR_ROWS_FETCHED_PTR, (SQLPOINTER)(&rowsFetched), 0);

                        //Fill the buffer with data
                        ret=EXAFetch(hstmt_data);
                        if (SQL_SUCCESS==ret || SQL_SUCCESS_WITH_INFO==ret) 
                        {
                            //Parameter are also column wise bound (default)
                            //Specifies how many rows will be insterted in a block:
                            EXASetStmtAttr(hstmt, SQL_ATTR_PARAMSET_SIZE, (SQLPOINTER)((size_t)rowsFetched), 0);

                            //Executes the statement using the parameters
                            if (SQL_SUCCESS!=EXAExecute(hstmt)) { PrintError(SQL_HANDLE_STMT, hstmt); return -1; }  

                            //Displaying results if any
                            GetResults(hstmt, input->execMode);
                        }
                    } while (SQL_SUCCESS==ret || SQL_SUCCESS_WITH_INFO==ret);

                    //Check for errors
                    if (SQL_ERROR==ret) { PrintError(SQL_HANDLE_STMT, hstmt_data); return -1; }

                    //Freeing resources for a new run
                    EXAFreeHandle(SQL_HANDLE_STMT, hstmt_data);
                    
                    //Clean up buffers
                    for (SQLSMALLINT col=1; col<=nColumns; col++)
                    {
                        free(buffers[col]);
                        free(indicators[col]);
                    }
                    free(buffers);
                    free(indicators);
                } else
                {
                    PrintError(SQL_HANDLE_STMT, hstmt); return -1;
                }
                break;
            case NotInitialized:
            default:
                printf("ERROR=no exec mode specified\n"); return -1;
            }
        }
    }

    if (BatchExec==input->execMode)
    {
        //Executing all batches ( -batchExec mode was selected)
        EXAExecuteBatch(hstmt);
        //Display result(s)
        GetResults(hstmt, BatchExec);
    }
    
    //Free the statement handle. All resultsets, binding and attributes will be deleted.
    EXAFreeHandle(SQL_HANDLE_STMT, hstmt);

    //Disconnect from server
    EXADisconnect(hdbc);

    //Free the connection handle. All connection data is deleted.
    EXAFreeHandle(SQL_HANDLE_DBC, hdbc);

    //Free the environment handle.
    EXAFreeHandle(SQL_HANDLE_ENV, henv);

    return 0;
}

