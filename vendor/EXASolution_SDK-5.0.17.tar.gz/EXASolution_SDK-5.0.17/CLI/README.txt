EXASolution SDK

Copyright (c) 2004-2016 EXASOL AG. All rights reserved.

==============================================================================

EXASolution Call Level Interface (CLI)
Native C++ programming interface to access EXASolution.

------------------------------------------------------------------------------

BUILDING A EXASolution CLIENT

The EXASolution SDK provides the libraries required to
build an EXASolution client using native CLI on AIX, HP-UX, Linux,
and Solaris.

The examples directory contains the code for a simple client (exaexec) and a
Makefile for each supported platform. Please refer to these Makefiles as a
starting point for building your application. To find out how "exaexec" works,
please read the code comments in the file examples/exaexec.c.

Before connecting to a running $(PRODUCT_NAME)s server, make sure that
your network configuration allows TCP connections to the EXASolution
host. At first run of a client, network configuration issues are a frequent
cause for connection errors.


EXASolution CLI API DOCUMENTATION

The EXASolution CLI API is based on to the Microsoft ODBC API. The
online ODBC documentation covers most of the EXASolution CLI interface.
There are a few differences between the EXASolution CLI and the ODBC API:

- In EXASolution CLI, function names start with "EXA", not with "SQL"
  as in ODBC.

- For some EXASolution specific functionalities, like "batch execution"
  and "parallel read/write", we have declared specific functions. Refer to
  the code comments in "exaCInterface.h" for details.


COMPATIBILITY AND SYSTEM SPECIFIC NOTES

- AIX

  EXASolution SDK is tested on AIX 5.3, AIX 6.1, and AIX 7.1 with IBM's
  GCC 4.2.0.
  At the moment, a C++-compiler is recommended (use g++, not gcc).
  Compilation with IBM's XL C/C++ compiler is not supported.

  If missing, install from the AIX installation media

    * bos.adt.libm

  and download and install the following packages for AIX 5.3 or AIX 6.1
  (for AIX 7.1 use the AIX 6.1 packages)

    * gcc 4.2.0 (development)
    * gcc-c++ 4.2.0 (development)
    * libgcc 4.2.0 (runtime)
    * libstdc++ 4.2.0 (runtime)
    * libstd++-devel 4.2.0 (development)

  from http://www-03.ibm.com/systems/power/software/aix/linux/toolbox/download.html

- FreeBSD

  EXASolution SDK is tested on FreeBSD 9.3 (with GCC) and on
  FreeBSD 10.1 and 10.2 (with Clang).
  At the moment, a C++-compiler is recommended (use CC, not cc).
  The following packages need to be installed for build and use: gmp, libiconv.

- HP-UX
 
  EXASolution SDK is tested on HP-UX 11.31 with aCC.
  At the moment, a C++-compiler is recommended (use aCC, not cc).
  Compilation with GCC is not supported.

- Linux

  For a list of supported Linux distributions, see the EXASolution User
  Manual, Chapter "Clients and Interfaces", Section "SDK".
  The libraries were built using GCC 4.1.0, so we recommend this compiler
  version to build your applications.
  At the moment, a C++-compiler is recommended (use g++, not gcc).

- MacOS X

  MacOS is not supported at the moment.

- Solaris

  EXASolution SDK is tested on Solaris 10 and 11 on SPARC and x86 with
  Oracle Solaris Studio 12.2 C++ compiler.
  The libraries were built using this compiler version, so we recommend it
  to build your applications.
  At the moment, a C++-compiler is recommended (use CC, not cc).
  Compilation with GCC is not supported.


COMPILING C SOURCE FILES

The provided libraries work with programs written in C (or mixed C and C++)
as long as the C sources are compiled with a C++ compiler. Using a pure C
compiler is possible, but requires a different library. Refer to the
respective Makefile in the examples directory for details.

