#ifndef EXACINTERFACE_H
#define EXACINTERFACE_H

/** @file
 * @brief Main EXASolution CLI header file.
 */

#ifndef WIN32
	#define ODBCVER 0x0351
	#define HAVE_LONG_LONG 1
#endif
#ifdef EXAWIN64
	#define BUILD_REAL_64_BIT_MODE 1
#endif

//32 or 64 bit
#ifndef _WIN32
	#if (__WORDSIZE > 32) || defined(__LP64__) || defined(_LP64)
		#define __64BIT_ODBC 1
	#else
		#define __32BIT_ODBC 1
	#endif
#endif

#ifndef EXA_DLL_EXPORT
	#define EXA_DLL_EXPORT  
#endif

#include <string.h>


#ifdef _WIN32
	#include <windows.h>
	#include <windef.h>

	#include <sql.h>
	#include <sqlext.h>
	#include <odbcinst.h>
#else
	#if defined(__hpux) || defined(__APPLE__)
		#include "/usr/include/iconv.h"
	#else
		#include <iconv.h>
	#endif

	#include "unixodbc.h"
#endif


#ifndef SQL_API
	#define SQL_API
#endif

#include "exaDefs.h"



 typedef struct __ConnectionStru
 {
     char exaPort[12];
     SQLINTEGER exaPortLen;
     char exaServer[64];
     SQLINTEGER exaServerLen;
 } ConnectionStru;

/////////////////////////////////////////////////////////////////////////////////////
// Please note that for the functions which are marked as "ODBC function", you can //
// get more detaild desriptionn in ODBC 3.5 documentation.                         //
/////////////////////////////////////////////////////////////////////////////////////

/**
 * EXASolution CLI specific function. Used to get the version of the CLI library. The buffer should be at least VERSION_BUFFER_SIZE=128 characters long.
 *
 * @param[out]  verbuff          Buffer for the version string. The string will be zero terminated.
 * @return      SQL_SUCCESS, SQL_ERROR.
 */
EXA_DLL_EXPORT SQLRETURN  CLIDllVersion(char * verbuff);


/**
 * EXASolution CLI specific function. Adds an SQL statement to a batch list. All SQL`s will be executed when EXAExecuteBatch is called. It will produce as many results as SQL strings were added.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   sqlString        SQL statement text.
 * @param[in]   sqlStrLen        Length in characters of the string. Can be SQL_NTS if the string is zero terminated.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAPrepareBatch(
        SQLHSTMT          StatementHandle,
        const char *      sqlString,
        SQLINTEGER        sqlStrLen);


/**
 * EXASolution CLI specific function. Wide-char version of EXAPrepareBatch. Adds an SQL statement to a batch list. All SQL`s will be executed when EXAExecuteBatch is called. It will produce as many results as SQL strings were added.
 *
 * @param[in]   StatementHandle   CLI handle identifying the statement object.
 * @param[in]   sqlString         SQL statement text.
 * @param[in]   sqlStrLen         Length in characters of the string. Can be SQL_NTS if the string is zero terminated.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAPrepareBatchW(
        SQLHSTMT          StatementHandle,
        const SQLWCHAR*   sqlString,
        SQLINTEGER        sqlStrLen);


/** ODBC function. EXAParamData is used together with EXAPutData to supply parameter data at statement execution time. 
 *
 * @param[in]   StatementHandle   CLI handle identifying the statement object.
 * @param[in]   Value             Pointer to a buffer in which to return the address of the ParameterValuePtr buffer specified in EXABindParameter.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_NEED_DATA, SQL_NO_DATA, SQL_STILL_EXECUTING.
 */
EXA_DLL_EXPORT SQLRETURN  EXAParamData (
        SQLHSTMT        StatementHandle,
        SQLPOINTER *    Value);




/** ODBC function. SQLPutData allows an application to send data for a parameter or column to the driver at statement execution time. This function can be used to send character or binary data values in parts. 
 * @param[in]   StatementHandle   CLI handle identifying the statement object.
 * @param[in]   DataPtr           Pointer to the data buffer.
 * @param[in]   StrLen_or_Ind     Length of the data.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_STILL_EXECUTING, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAPutData (
        SQLHSTMT        StatementHandle,
        SQLPOINTER      DataPtr,
        SQLLEN          StrLen_or_Ind);


/**
 * EXASolution CLI specific function. Executes all batch SQL added by EXAPrepareBatch. After successful execution, the first resultset (from the first SQL) is active. To go to the next result set, use EXAMoreResults.
 *
 * @param[in]   StatementHandle   CLI handle identifying the statement object.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAExecuteBatch(SQLHSTMT StatementHandle);


/**
 * EXASolution CLI specific function. Retrieves a list containing all cluster nodes in a ConnectionStru array. The function creates an array of ConnectionStru objects and deletes it by the next use of the statement handle.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[out]  nHostsPtr        Buffer in which to return the number of hosts-port pairs contained in the list.
 * @param[out]  ConnectionPtr    Pointer to array of ConnectionStru objects created by the driver.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetHostnames (
        SQLHSTMT           StatementHandle,
        SQLINTEGER *       nHostsPtr,
        ConnectionStru **  ConnectionPtr);


/**
 * EXASolution CLI function. Can be used only in parallel connections. It creates an resultset in a parallel connection using a EXASolution internal handle read from the main connection. This resultset is used to read data in parallel mode from one ore more nodes of the same EXASolution cluster.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   handle           EXASolution internal handle for a resultset. It can be read using EXAGetStmtAttr
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAExecuteDescRes (
        SQLHSTMT        StatementHandle,
        SQLINTEGER      handle);


/**
 * EXASolution CLI function. Closes the resultset held by the EXASolution server. This function is called automatically when a new SQL statement is executed on the same statement handle or if the statement handle is freed.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAExecuteCloseRes (
        SQLHSTMT        StatementHandle);


/**
 * EXASolution CLI function. Starts parallel read and insert modes. It has to be called on the main connection only. The token received here must be given to the clients that connect in parallel using EXASlaveConnect.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   nConnections     Number of parallel connections that will be used by the parallel client application. If the requested number is too big, EXASolution will return the maximum number of parallel connection that are possible.
 * @param[out]  nConnectionsPtr  Number of parallel connections that will be really used. In parallel mode the client must open all parallel connections. In that connections all commands must be called simultaneously except EXAFetch and EXAExecute with insert parameters.
 * @param[out]  ConnectionPtr    The driver returns here an array of ConnectionStru objects containing the connection data (host and port) for all parallel connections. The user must save this data immediately after calling EXAEnterParallel because the driver deletes the array the next time the statement handle is accessed.
 * @param[out]  TokenPtr         A token used to identify all parallel connections that belong together.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAEnterParallel (
        SQLHSTMT           StatementHandle,
        SQLINTEGER         nConnections,
        SQLINTEGER *       nConnectionsPtr,
        ConnectionStru **  ConnectionPtr,
        SQLBIGINT *        TokenPtr);


/**
 * EXASolution CLI function. For parallel connections only. If the statement has a result which the client application wants to fetch, it can determine which position in the global result set has the staring row of his local (parallel) result set using this function. The sum of the local results always builds the global result, as it was generated by the SQL statement send on the main connection.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[out]  slaveOffset      Position of the first row of the local result set in the global result. Row numbers start at 0.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetSlaveOffset (
        SQLHSTMT        StatementHandle,
        SQLBIGINT *     slaveOffset);


/**
 * ODBC function. Returns the number of rows affected by a statement (insert/update/delete...).
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[out]  RowCountPtr      Address where to write the rowcount value.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXARowCount(
        SQLHSTMT        StatementHandle,
        SQLLEN *        RowCountPtr);


/**
 * ODBC function. Offers an easy but not the most performing way to read data from a result table. Before calling this function the cursor must be positioned using EXAFetch or EXAFetchScroll.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   ColumnNumber     Number of column from which to get the data.
 * @param[in]   TargetType       Data type in which the data will be returned (like SQL_C_CHAR, SQL_C_SLONG, etc.).
 * @param[out]  TargetValue      Pointer to a buffer in which to return the data.
 * @param[in]   BufferLength     Length in bytes of the buffer.
 * @param[out]  StrLen_or_Ind    Pointer in which to return the length of the value for variable length types. If SQL_NULL_DATA is returned, it means that the data was NULL and the the buffer content must not be read.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE, SQL_SUCCESS_WITH_INFO.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetData(
        SQLHSTMT        StatementHandle,
        SQLSMALLINT     ColumnNumber,
        SQLSMALLINT     TargetType,
        SQLPOINTER      TargetValue,
        SQLLEN          BufferLength,
        SQLLEN *        StrLen_or_Ind);


/**
 * ODBC function. Returns information about the EXASolution.
 *
 * @param[in]   ConnectionHandle CLI handle identifying the connection object.
 * @param[in]   InfoType         Type code for the requested information (see ODBC standard).
 * @param[out]  InfoValue        Buffer for the information data. The data type of the buffer depends on InfoType.
 * @param[in]   BufferLength     Length in bytes for the variable size data types of the buffer. For fixed types the buffer length is ignored.
 * @param[out]  StringLength     Length of the string data in case the output's data type is a character string.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE, SQL_SUCCESS_WITH_INFO.
*/
EXA_DLL_EXPORT SQLRETURN  EXAGetInfo(
        SQLHDBC         ConnectionHandle,
        SQLSMALLINT     InfoType,
        SQLPOINTER      InfoValue,
        SQLSMALLINT     BufferLength,
        SQLSMALLINT *   StringLength);


/**
 * ODBC function. This is the wide-char version of EXAGetInfo.
 *
 * @param[in]   ConnectionHandle CLI handle identifying the connection object.
 * @param[in]   InfoType         Type code for the requested information (see ODBC standard).
 * @param[out]  InfoValue        Buffer for the information data. The data type of the buffer depends on InfoType.
 * @param[in]   BufferLength     Length in bytes for the variable size data types of the buffer. For fixed types the buffer length is ignored.
 * @param[out]  StringLength     Length of the string data in case the output's data type is a character string.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE, SQL_SUCCESS_WITH_INFO.
*/
EXA_DLL_EXPORT SQLRETURN  EXAGetInfoW(
        SQLHDBC         ConnectionHandle,
        SQLSMALLINT     InfoType,
        SQLPOINTER      InfoValue,
        SQLSMALLINT     BufferLength,
        SQLSMALLINT *   StringLength);


/**
 * ODBC function. Creates a new statement, connection or environment object identified by a handle.
 *
 * @param[in]   HandleType       Type of the object to be created.
 * @param[in]   InputHandle      Handle for the parent of the new object. To create an environment object this value must be NULL.
 * @param[out]  OutputHandlePtr  The new handle.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAAllocHandle (
        SQLSMALLINT     HandleType,
        SQLHANDLE       InputHandle,
        SQLHANDLE *     OutputHandlePtr);


/**
 * ODBC function. This function has to be called before fetching data. It must be called to tell fetch where to put the data from the result set, to which data type to transform it and how big the buffer for each data cell is.
 *
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @param[in]   ColumnNumber    Number of the column to bind. Column numbers are starting with 1.
 * @param[in]   TargetType      Data type to which to convert to (like SQL_C_SLONG, SQL_C_CHAT, etc.).
 * @param[out]  TargetValuePtr  Pointer to the begin of the buffer. See also ODBC api reference for column/row-wise column binding.
 * @param[in]   BufferLength    Length in bytes of the buffer.
 * @param[out]  StrLen_or_Ind   A buffer where the driver will write the length for variable length data or SQL_NULL_DATA for all data that is NULL.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE.
*/
EXA_DLL_EXPORT SQLRETURN  EXABindCol (
        SQLHSTMT        StatementHandle,
        SQLSMALLINT     ColumnNumber,
        SQLSMALLINT     TargetType,
        SQLPOINTER      TargetValuePtr,
        SQLLEN          BufferLength,
        SQLLEN *        StrLen_or_Ind);


/**
 * ODBC function. Tells the driver where the client application holds the parameter data needed for prepared statements.
 *
 * @param[in]   StatementHandle   CLI handle identifying the statement object.
 * @param[in]   ParameterNumber   Number of the question marks form the prepared statement that has to be replaced by the values bound here.
 * @param[in]   InputOutputType   Specifies if the parameter bound is an input or an output parameter.
 * @param[in]   ValueType         Data type of the value stored by the client application (like SQL_C_CHAR, SQL_C_TYPE_DATE, etc.).
 * @param[in]   ParameterType     SQL type of the parameter (like SQL_CHAR, SQL_TYPE_DATE, etc.).
 * @param[in]   ColumnSize        Column size of the parameter SQL type like described in the ODBC api specification.
 * @param[in]   DecimalDigits     Used to describe decimal values with fixed number of decimal digits. For other data types, it is ignored.
 * @param[in]   ParameterValuePtr Pointer to the beginning of the buffer where the application stores the parameter data for this column. See also ODBC api reference for column/row-wise parameter binding.
 * @param[in]   BufferLength      ParameterValue length in bytes of the buffer for one value.
 * @param[in]   StrLen_or_IndPtr  A buffer where the user will write the length for variable length data or SQL_NULL_DATA for data of all types that is NULL.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE.
*/
EXA_DLL_EXPORT SQLRETURN  EXABindParameter (
        SQLHSTMT         StatementHandle,
        SQLSMALLINT      ParameterNumber,
        SQLSMALLINT      InputOutputType,
        SQLSMALLINT      ValueType,
        SQLSMALLINT      ParameterType,
        SQLULEN          ColumnSize,
        SQLSMALLINT      DecimalDigits,
        SQLPOINTER       ParameterValuePtr,
        SQLLEN           BufferLength,
        SQLLEN *         StrLen_or_IndPtr);

/** ODBC function. Cancels asynchronous executing statements.
 * @param[in]   StatementHandle Statement handle
 * @return SQL_ERROR.
 */
EXA_DLL_EXPORT SQLRETURN  EXACancel (
        SQLHSTMT        StatementHandle);

/**
 * ODBC function. Reads an attribute describing the specified column.
 *
 * @param[in]   StatementHandle         CLI handle identifying the statement object.
 * @param[in]   ColumnNumber            Number of the column being described.
 * @param[in]   FieldIdentifier         Type of the information requested.
 * @param[out]  CharacterAttributePtr   Buffer where the driver will write character string output.
 * @param[in]   BufferLength            Size in bytes of the character attribute buffer.
 * @param[out]  StringLengthPtr         In this pointer the driver returns the length of the character attribute.
 * @param[out]  NumericAttributePtr     If the data type of the requested attribute is numeric, the value is returned here.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
*/
EXA_DLL_EXPORT SQLRETURN  EXAColAttribute (
        SQLHSTMT        StatementHandle,
        SQLSMALLINT     ColumnNumber,
        SQLSMALLINT     FieldIdentifier,
        SQLPOINTER      CharacterAttributePtr,
        SQLSMALLINT     BufferLength,
        SQLSMALLINT *   StringLengthPtr,
        SQLLEN *        NumericAttributePtr);


/**
 * ODBC function. This is the wide-char version of EXAColAttribute. Reads an attribute describing the specified column.
 *
 * @param[in]   StatementHandle         CLI handle identifying the statement object.
 * @param[in]   ColumnNumber            Number of the column being described.
 * @param[in]   FieldIdentifier         Type of the information requested.
 * @param[out]  CharacterAttributePtr   Buffer where the driver will write character string output.
 * @param[in]   BufferLength            Size in bytes of the character attribute buffer.
 * @param[out]  StringLengthPtr         In this pointer the driver returns the length of the character attribute.
 * @param[out]  NumericAttributePtr     If the data type of the requested attribute is numeric, the value is returned here.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
*/
EXA_DLL_EXPORT SQLRETURN  EXAColAttributeW (
        SQLHSTMT        StatementHandle,
        SQLSMALLINT     ColumnNumber,
        SQLSMALLINT     FieldIdentifier,
        SQLPOINTER      CharacterAttributePtr,
        SQLSMALLINT     BufferLength,
        SQLSMALLINT *   StringLengthPtr,
        SQLLEN *        NumericAttributePtr);

/**
 * ODBC function. It creates a resultset containing all columns that fit the description given by the parameter of this function call.
 *
 * @param[in]   StatementHandle  CLI handle identifying a statement object.
 * @param[in]   CatalogName      Search pattern for the name of the catalog. Use NULL for the default catalog.
 * @param[in]   NameLength1      Length in characters of the catalog name.
 * @param[in]   SchemaName       Name or search pattern of the schema(s) where to look for the columns.
 * @param[in]   NameLength2      Length in characters of the schema name.
 * @param[in]   TableName        Name or search pattern of the table(s) to where to look for the columns.
 * @param[in]   NameLength3      Length in characters of the table name.
 * @param[in]   ColumnName       Name or search pattern of the column(s) you are looking for.
 * @param[in]   NameLength4      Length in characters of the column name.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAColumns (
        SQLHSTMT        StatementHandle,
        char *          CatalogName,
        SQLSMALLINT     NameLength1,
        char *          SchemaName,
        SQLSMALLINT     NameLength2,
        char *          TableName,
        SQLSMALLINT     NameLength3,
        char *          ColumnName,
        SQLSMALLINT     NameLength4);


/**
 * ODBC function. This is the wide-char version of EXAColumns. It creates a resultset containing all columns that fit the description given by the parameter of this function call.
 *
 * @param[in]   StatementHandle CLI handle identifying a statement object.
 * @param[in]   CatalogName     Name of the catalog. Use NULL for the default catalog.
 * @param[in]   NameLength1     Length in characters of the catalog name.
 * @param[in]   SchemaName      Name or search pattern of the schema(s) where to look for the columns.
 * @param[in]   NameLength2     Length in characters of the schema name.
 * @param[in]   TableName       Name or search pattern of the table(s) to where to look for the columns.
 * @param[in]   NameLength3     Length in characters of the table name.
 * @param[in]   ColumnName      Name or search pattern of the column(s) you are looking for.
 * @param[in]   NameLength4     Length in characters of the column name.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAColumnsW (
        SQLHSTMT        StatementHandle,
        SQLWCHAR *      CatalogName,
        SQLSMALLINT     NameLength1,
        SQLWCHAR *      SchemaName,
        SQLSMALLINT     NameLength2,
        SQLWCHAR *      TableName,
        SQLSMALLINT     NameLength3,
        SQLWCHAR *      ColumnName,
        SQLSMALLINT     NameLength4);


/**
 * ODBC function. Creates a resultset describing all column privileges for the selected columns.
 *
 * @param[in]   StatementHandle CLI handle identifying a statement object.
 * @param[in]   CatalogName     Name of the catalog. Use NULL for the default catalog.
 * @param[in]   NameLength1     Length in characters of the catalog name.
 * @param[in]   SchemaName      Name or search pattern of the schema(s) where to look for the columns.
 * @param[in]   NameLength2     Length in characters of the schema name.
 * @param[in]   TableName       Name or search pattern of the table(s) to where to look for the columns.
 * @param[in]   NameLength3     Length in characters of the table name.
 * @param[in]   ColumnName      Name or search pattern of the column(s) in question.
 * @param[in]   NameLength4     Length in characters of the column name.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAColumnPrivileges (
        SQLHSTMT        StatementHandle,
        char *          CatalogName,
        SQLSMALLINT     NameLength1,
        char *          SchemaName,
        SQLSMALLINT     NameLength2,
        char *          TableName,
        SQLSMALLINT     NameLength3,
        char *          ColumnName,
        SQLSMALLINT     NameLength4);


/**
 * ODBC function. Wide-char version of EXAColumnPrivileges. It creates a resultset describing all column privileges for the selected columns.
 *
 * @param[in]   StatementHandle CLI handle identifying a statement object.
 * @param[in]   CatalogName     Name of the catalog. Use NULL for the default catalog.
 * @param[in]   NameLength1     Length in characters of the catalog name.
 * @param[in]   SchemaName      Name or search pattern of the schema(s) where to look for the columns.
 * @param[in]   NameLength2     Length in characters of the schema name.
 * @param[in]   TableName       Name or search pattern of the table(s) to where to look for the columns.
 * @param[in]   NameLength3     Length in characters of the table name.
 * @param[in]   ColumnName      Name or search pattern of the column(s) in question.
 * @param[in]   NameLength4     Length in characters of the column name.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAColumnPrivilegesW (
        SQLHSTMT        StatementHandle,
        SQLWCHAR *      CatalogName,
        SQLSMALLINT     NameLength1,
        SQLWCHAR *      SchemaName,
        SQLSMALLINT     NameLength2,
        SQLWCHAR *      TableName,
        SQLSMALLINT     NameLength3,
        SQLWCHAR *      ColumnName,
        SQLSMALLINT     NameLength4);


/**
 * ODBC function. Copies a CLI descriptor to another.
 *
 * @param[in]   SourceDescHandle  Handle of a descriptor from which to copy the data.
 * @param[in]   TargetDescHandle  Handle of the descriptor the data will be written into.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXACopyDesc (
        SQLHDESC SourceDescHandle,
        SQLHDESC TargetDescHandle);


/**
 * EXASolution CLI specific function. It opens a connection to the EXASolution server. This will be a so called main connection, on which all SQL commands and interface functions will work, except a few that work only on parallel connections.
 *
 * @param[in]   ConnectionHandle CLI handle identifying a connection object.
 * @param[in]   ServerHost       An so called cluster string (please refer the EXASolution user manual for details) containing the host name(s) or address(es) of the server and the port where it's listening.
 * @param[in]   ServerHostLen    Length in characters of the server host parameter. Put here SQL_NTS and the driver will consider the host string is zero terminated.
 * @param[in]   Port             Here can be specified a default port to be used for the hosts from the cluster string. It applies only to the hosts that don't have a port associated. This parameter can stay unused (NULL) as his main purpose is to keep the compliance to the older versions of EXA-CLI.
 * @param[in]   PortStrLen       Length in characters of the port. Can be SQL_NTS.
 * @param[in]   UserName         Name of the database user who is connecting.
 * @param[in]   UserNameLength   Length in characters of the user name. Can be SQL_NTS.
 * @param[in]   Password         The database users password.
 * @param[in]   PasswordLength   Length in characters of the password. Can be SQL_NTS.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAServerConnect (
        SQLHDBC         ConnectionHandle,
        const char *    ServerHost,
        SQLINTEGER      ServerHostLen,
        const char *    Port,
        SQLINTEGER      PortStrLen,
        const char *    UserName,
        SQLSMALLINT     UserNameLength,
        const char *    Password,
        SQLSMALLINT     PasswordLength);


/**
 * EXASolution CLI specific function. This is the wide-char version of EXAServerConnect. It opens a connection to the EXASolution server. This will be a so called main connection, on which all SQL commands and interface functions will work, except a few that work only on parallel connections.
 *
 * @param[in]   ConnectionHandle  CLI handle identifying a connection object.
 * @param[in]   ServerHost        An so called cluster string (please refer the EXASolution user manual for details) containing the host name(s) or address(es) of the server and the port where it's listening.
 * @param[in]   ServerHostLen     Length in characters of the server host parameter. Put here SQL_NTS and the driver will consider the host string is zero terminated.
 * @param[in]   Port              Here can be specified a default port to be used for the hosts from the cluster string. It applies only to the hosts that don't have a port associated. This parameter can stay unused (NULL) as his main purpose is to keep the compliance to the older versions of EXA-CLI.
 * @param[in]   PortStrLen        Length in characters of the port. Can be SQL_NTS.
 * @param[in]   UserName          Name of the database user who is connecting.
 * @param[in]   UserNameLength    Length in characters of the user name. Can be SQL_NTS.
 * @param[in]   Password          The database users password.
 * @param[in]   PasswordLength    Length in characters of the password. Can be SQL_NTS.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAServerConnectW (
        SQLHDBC          ConnectionHandle,
        const SQLWCHAR * ServerHost,
        SQLINTEGER       ServerHostLen,
        const SQLWCHAR * Port,
        SQLINTEGER       PortStrLen,
        const SQLWCHAR * UserName,
        SQLSMALLINT      UserNameLength,
        const SQLWCHAR * Password,
        SQLSMALLINT      PasswordLength);


/**
 * EXASolution CLI specific function. This opens a restricted connection to the EXASolution server. It can be used only in the parallel mode, when an application reads a resultset or inserts data into one table simultaneously on multiple connections to one EXASolution instance.
 *
 * @param[in]   ConnectionHandle  CLI handle identifying a connection object.
 * @param[in]   ServerHost        Host name or IP of the node where to connect to.
 * @param[in]   ServerHostLen     Length in characters of the host name.
 * @param[in]   Port              The port on which the server is listening for incoming connections.
 * @param[in]   PortStrLen        The length in characters of the port.
 * @param[in]   SlaveToken        A special token used to associate this parallel connection to a main connection. Use EXAEnterParallel to get this token.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXASlaveConnect (
        SQLHDBC         ConnectionHandle,
        char *          ServerHost,
        SQLINTEGER      ServerHostLen,
        char *          Port,
        SQLINTEGER      PortStrLen,
        SQLBIGINT       SlaveToken);


/**
 * ODBC function. Retrieves the most commonly asked column attributes. If one ore more attributes do not concern you, simply send NULL as argument instead of the buffer pointer for them.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   ColumnNumber     The number of the column to describe.
 * @param[out]  ColumnName       A buffer where the driver will write the name of the column. This name is zero terminated.
 * @param[in]   BufferLength     The size in characters of the column name buffer.
 * @param[out]  NameLengthPtr    A pointer to a buffer in which the driver will return the length in characters of the column name.
 * @param[out]  DataTypePtr      Here the driver writes the SQL data type of the column (like SQL_INTEGER, SQL_TYPE_TIMESTAMP, etc. ).
 * @param[out]  ColumnSizePtr    A buffer where the column size is written by the driver.
 * @param[out]  DecimalDigitsPtr A buffer for the number of decimal digits of a decimal type with fixed precision and scale.
 * @param[out]  NullablePtr      This value tells you if the column can contain NULL's.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXADescribeCol (
        SQLHSTMT        StatementHandle,
        SQLSMALLINT     ColumnNumber,
        SQLCHAR *       ColumnName,
        SQLSMALLINT     BufferLength,
        SQLSMALLINT *   NameLengthPtr,
        SQLSMALLINT *   DataTypePtr,
        SQLULEN *       ColumnSizePtr,
        SQLSMALLINT *   DecimalDigitsPtr,
        SQLSMALLINT *   NullablePtr);


/**
 * ODBC function. This is the wide-char version of EXADescribeCol. Retrieves the most commonly asked column attributes. If one ore more attributes do not concern you, simply send NULL as argument instead of the buffer pointer for them.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   ColumnNumber     The number of the column to describe.
 * @param[out]  ColumnName       A buffer where the driver will write the name of the column. This name is zero terminated.
 * @param[in]   BufferLength     The size in characters of the column name buffer.
 * @param[out]  NameLengthPtr    A pointer to a buffer in which the driver will return the length in characters of the column name.
 * @param[out]  DataTypePtr      Here the driver writes the SQL data type of the column (like SQL_INTEGER, SQL_TYPE_TIMESTAMP, etc. ).
 * @param[out]  ColumnSizePtr    A buffer where the column size is written by the driver.
 * @param[out]  DecimalDigitsPtr A buffer for the number of decimal digits of a decimal type with fixed precision and scale.
 * @param[out]  NullablePtr      This value tells you if the column can contain NULL's.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXADescribeColW (
        SQLHSTMT        StatementHandle,
        SQLSMALLINT     ColumnNumber,
        SQLWCHAR *      ColumnName,
        SQLSMALLINT     BufferLength,
        SQLSMALLINT *   NameLengthPtr,
        SQLSMALLINT *   DataTypePtr,
        SQLULEN *       ColumnSizePtr,
        SQLSMALLINT *   DecimalDigitsPtr,
        SQLSMALLINT *   NullablePtr);


/**
 * EXASolution CLI function. Retrieves the native data type from a column. Using this data type in fetch or get data will require the minimum amount of data transformations in the driver.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   ColumnNumber     Number of the column in the result set.
 * @param[out]  NativeDataType   A buffer in which to retrieve the native C data type (like SQL_C_CHAR, EXA_INT64, etc.) of the column.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXADescribeCol2(
        SQLHSTMT        StatementHandle,
        SQLSMALLINT     ColumnNumber,
        SQLSMALLINT *   NativeDataType);


/**
 * ODBC function. Retrieves a description of a parameter after preparing a statement containing parameter place holders (question marks). As the driver can't determine at this time the type of the parameter, this function always considers the parameter as the biggest varchar supported by EXASolution.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   ParameterNumber  Number of the parameter to be described.
 * @param[out]  DataTypePtr      SQL data type (like SQL_BIGINT, SQL_CHAR, etc.) of the parameter.
 * @param[out]  ParameterSizePtr Column size of the parameter.
 * @param[out]  DecimalDigitsPtr A buffer for the number of decimal digits of a decimal type parameter with fixed precision and scale.
 * @param[out]  NullablePtr      Tells you if the column can contain NULL's or not.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXADescribeParam (
        SQLHSTMT        StatementHandle,
        SQLSMALLINT     ParameterNumber,
        SQLSMALLINT *   DataTypePtr,
        SQLULEN *       ParameterSizePtr,
        SQLSMALLINT *   DecimalDigitsPtr,
        SQLSMALLINT *   NullablePtr);


/**
 * ODBC function. Closes a connection to EXASolution. It deletes all statement objects created with for connection that is disconnecting. This function is used for main and parallel connections.
 *
 * @param[in]   ConnectionHandle  CLI handle identifying the connection object.
 * @return      SQL_SUCCESS, SQL_INVALID_HANDLE
 */
EXA_DLL_EXPORT SQLRETURN  EXADisconnect (
        SQLHDBC         ConnectionHandle);


/**
 * ODBC function. Sends an SQL statement to the server for execution and returns one or more results (resultsets, rowcounts, errors messages). It can be also used for direct execution of prepared statements when parameters are bound. It is strongly recommended to free all results and parameter bindings using EXAFreeStmt as soon as they aren't needed any more.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   StatementText    A SQL statement. It can contain parameter holders if this parameters were already bound using EXABindParameter.
 * @param[in]   TextLength       The length of the SQL statement. Can be SQL_NTS if the statement text is zero terminated.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAExecDirect (
        SQLHSTMT        StatementHandle,
        SQLCHAR *       StatementText,
        SQLINTEGER      TextLength);


/**
 * ODBC function. Wide-char version of EXAExecDirect. Sends an SQL statement to the server for execution and returns one or more results (resultsets, rowcounts, errors messages). It can be also used for direct execution of prepared statements when parameters are bound. It is strongly recommended to free all results and parameter bindings using EXAFreeStmt as soon as they aren't needed any more.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   StatementText    A SQL statement. It can contain parameter holders if this parameters were already bound using EXABindParameter.
 * @param[in]   TextLength       The length of the SQL statement. Can be SQL_NTS if the statement text is zero terminated.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAExecDirectW (
        SQLHSTMT        StatementHandle,
        SQLWCHAR *      StatementText,
        SQLINTEGER      TextLength);


/**
 * ODBC function. Executes a statement that was prepared using EXAPrepare and returns one or more results (resultsets, rowcounts, errors messages).
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAExecute (
        SQLHSTMT        StatementHandle);


/**
 * ODBC function. Fetches the data from a result set into the bound columns. It also increases the cursor with a count equal to the fetch offset, no matter if columns are bound or not. See "column-wise binding" and "row-wise binding" in the ODBC api reference for more details about how to bind the columns.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAFetch (
        SQLHSTMT        StatementHandle);


/**
 * ODBC function. Does the same as fetch but the user has better control on how the cursor changes.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   FetchOrientation Tells what rows are fetched and how the cursor is modified after fetching.
 * @param[in]   FetchOffset      The number of rows fetched. It also depends on what fetch orientation is used.
 * @return      SQL_SUCCESS, SQL_NO_DATA, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
*/
EXA_DLL_EXPORT SQLRETURN  EXAFetchScroll (
        SQLHSTMT        StatementHandle,
        SQLSMALLINT     FetchOrientation,
        SQLLEN          FetchOffset);


/**
 * ODBC function. It can return a list of foreign keys in the specified table (columns in the specified table that refer to primary keys in other tables) or a list of foreign keys in other tables that refer to the primary key in the specified table. This function returns an empty result set and is implemented only for ODBC compliance.
 *
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @param[in]   PKCatalogName   Search pattern for the primary key catalog name.
 * @param[in]   NameLength1     Primary key catalog name length.
 * @param[in]   PKSchemaName    Search pattern for the primary key schema name.
 * @param[in]   NameLength2     Primary key schema name length.
 * @param[in]   PKTableName     Search pattern for the primary key table name.
 * @param[in]   NameLength3     Primary key table name length.
 * @param[in]   FKCatalogName   Search pattern for the foreign key catalog name.
 * @param[in]   NameLength4     Foreign key catalog name length.
 * @param[in]   FKSchemaName    Search pattern for the foreign key schema name.
 * @param[in]   NameLength5     Foreign key schema name length.
 * @param[in]   FKTableName     Search pattern for the foreign key table name.
 * @param[in]   NameLength6     Foreign key table name length.
 * @return      SQL_SUCCESS, SQL_NO_DATA, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAForeignKeys(
        SQLHSTMT        StatementHandle,
        char *          PKCatalogName,
        SQLSMALLINT     NameLength1,
        char *          PKSchemaName,
        SQLSMALLINT     NameLength2,
        char *          PKTableName,
        SQLSMALLINT     NameLength3,
        char *          FKCatalogName,
        SQLSMALLINT     NameLength4,
        char *          FKSchemaName,
        SQLSMALLINT     NameLength5,
        char *          FKTableName,
        SQLSMALLINT     NameLength6);


/**
 * ODBC function. Wide-char version of EXAForeignKeys. It can return a list of foreign keys in the specified table (columns in the specified table that refer to primary keys in other tables) or a list of foreign keys in other tables that refer to the primary key in the specified table. This function returns an empty result set and is implemented only for ODBC compliance.
 *
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @param[in]   PKCatalogName   Search pattern for the primary key catalog name.
 * @param[in]   NameLength1     Primary key catalog name length.
 * @param[in]   PKSchemaName    Search pattern for the primary key schema name.
 * @param[in]   NameLength2     Primary key schema name length.
 * @param[in]   PKTableName     Search pattern for the primary key table name.
 * @param[in]   NameLength3     Primary key table name length.
 * @param[in]   FKCatalogName   Search pattern for the foreign key catalog name.
 * @param[in]   NameLength4     Foreign key catalog name length.
 * @param[in]   FKSchemaName    Search pattern for the foreign key schema name.
 * @param[in]   NameLength5     Foreign key schema name length.
 * @param[in]   FKTableName     Search pattern for the foreign key table name.
 * @param[in]   NameLength6     Foreign key table name length.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAForeignKeysW(
        SQLHSTMT        StatementHandle,
        SQLWCHAR *      PKCatalogName,
        SQLSMALLINT     NameLength1,
        SQLWCHAR *      PKSchemaName,
        SQLSMALLINT     NameLength2,
        SQLWCHAR *      PKTableName,
        SQLSMALLINT     NameLength3,
        SQLWCHAR *      FKCatalogName,
        SQLSMALLINT     NameLength4,
        SQLWCHAR *      FKSchemaName,
        SQLSMALLINT     NameLength5,
        SQLWCHAR *      FKTableName,
        SQLSMALLINT     NameLength6);


/**
 * ODBC function. Deletes the object identified by the handle and frees its resources.
 *
 * @param[in]   HandleType      Specifies the type of the handle in the second argument.
 * @param[in]   Handle          A handle to a environment, connection, statement or descriptor object.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAFreeHandle (
        SQLSMALLINT     HandleType,
        SQLHANDLE       Handle);


/**
 * ODBC function. Frees some resources used by a statement or resets it to its initial state.
 *
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @param[in]   Option          Specifies what resources are freed or reset.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAFreeStmt(
        SQLHSTMT        StatementHandle,
        SQLSMALLINT     Option);


/**
 * ODBC function. Returns attributes describing the specified connection.
 *
 * @param[in]   ConnectionHandle CLI handle identifying the connection object.
 * @param[in]   Attribute        Specifies what kind of the information is requested.
 * @param[out]  Value            A buffer where to return the requested attribute value. If the data type of the value has fixed length, the parameters BufferLength and StringLength are ignored.
 * @param[in]   BufferLength     Size of the buffer in bytes.
 * @param[out]  StringLength     The size in bytes of the output value if this has no fixed length data type.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetConnectAttr (
        SQLHDBC         ConnectionHandle,
        SQLINTEGER      Attribute,
        SQLPOINTER      Value,
        SQLINTEGER      BufferLength,
        SQLINTEGER *    StringLength);


/**
 * ODBC function. Wide-char version of EXAGetConnectAttr. Returns attributes describing the specified connection.
 *
 * @param[in]   ConnectionHandle CLI handle identifying the connection object.
 * @param[in]   Attribute        Specifies what kind of the information is requested.
 * @param[out]  Value            A buffer where to return the requested attribute value. If the data type of the value has fixed length, the parameters BufferLength and StringLength are ignored.
 * @param[in]   BufferLength     Size of the buffer in bytes.
 * @param[out]  StringLength     The size in bytes of the output value if this has no fixed length data type.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetConnectAttrW (
        SQLHDBC         ConnectionHandle,
        SQLINTEGER      Attribute,
        SQLPOINTER      Value,
        SQLINTEGER      BufferLength,
        SQLINTEGER *    StringLength);

/**
 * ODBC function. Returns the value of a specified descriptor field. It is used to read information about columns or parameters that are rarely requested and that you can't read using EXADescribeCol or EXADescribeParam.
 *
 * @param[in]   DescriptorHandle CLI handle identifying the descriptor object.
 * @param[in]   RecNumber        Column or parameter number, depending of the type of the descriptor.
 * @param[in]   FieldIdentifier  Specifies what information is requested.
 * @param[out]  Value            A buffer used to return the information.
 * @param[in]   BufferLength     Size of the buffer, is needed for variable length information only.
 * @param[out]  StringLength     The length in bytes of the variable length information.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetDescField (
        SQLHDESC        DescriptorHandle,
        SQLSMALLINT     RecNumber,
        SQLSMALLINT     FieldIdentifier,
        SQLPOINTER      Value,
        SQLINTEGER      BufferLength,
        SQLINTEGER *    StringLength);

/**
 * ODBC function. Returns the value of a specified descriptor field. It is used to read information about columns or parameters that are rarely requested and that you can't read using EXADescribeCol or EXADescribeParam.
 * This is the unicode version.
 * 
 * @param[in]   DescriptorHandle CLI handle identifying the descriptor object.
 * @param[in]   RecNumber        Column or parameter number, depending of the type of the descriptor.
 * @param[in]   FieldIdentifier  Specifies what information is requested.
 * @param[out]  Value            A buffer used to return the information.
 * @param[in]   BufferLength     Size of the buffer, is needed for variable length information only.
 * @param[out]  StringLength     The length in bytes of the variable length information.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetDescFieldW (
        SQLHDESC        DescriptorHandle,
        SQLSMALLINT     RecNumber,
        SQLSMALLINT     FieldIdentifier,
        SQLPOINTER      Value,
        SQLINTEGER      BufferLength,
        SQLINTEGER *    StringLength);



/**
 * ODBC function. Returns the current settings or values of multiple fields of a descriptor record. The fields returned describe the name, data type, and storage of column or parameter data.
 *
 * @param[in]   DescriptorHandle CLI handle identifying the descriptor object.
 * @param[in]   RecNumber        Column or parameter number, depending of the type of the descriptor.
 * @param[out]  Name             Name of the column.
 * @param[in]   BufferLength     Size in characters of the column name buffer.
 * @param[out]  StringLength     Length in characters of the column name.
 * @param[out]  Type             Data type of the column or parameter.
 * @param[out]  SubType          Not used.
 * @param[out]  Length           Octet length of the column or parameter.
 * @param[out]  Precision        Precision of the column or parameter.
 * @param[out]  Scale            Scale of the column or parameter.
 * @param[out]  Nullable         Specifies if the column or parameter can contain NULL values.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetDescRec (
        SQLHDESC        DescriptorHandle,
        SQLSMALLINT     RecNumber,
        SQLCHAR *          Name,
        SQLSMALLINT     BufferLength,
        SQLSMALLINT *   StringLength,
        SQLSMALLINT *   Type,
        SQLSMALLINT *   SubType,
        SQLLEN *        Length,
        SQLSMALLINT *   Precision,
        SQLSMALLINT *   Scale,
        SQLSMALLINT *   Nullable);

/**
 * ODBC function. Returns the current settings or values of multiple fields of a descriptor record. The fields returned describe the name, data type, and storage of column or parameter data.
 * This is the unicode version of the function.
 * 
 * @param[in]   DescriptorHandle CLI handle identifying the descriptor object.
 * @param[in]   RecNumber        Column or parameter number, depending of the type of the descriptor.
 * @param[out]  Name             Name of the column.
 * @param[in]   BufferLength     Size in characters of the column name buffer.
 * @param[out]  StringLength     Length in characters of the column name.
 * @param[out]  Type             Data type of the column or parameter.
 * @param[out]  SubType          Not used.
 * @param[out]  Length           Octet length of the column or parameter.
 * @param[out]  Precision        Precision of the column or parameter.
 * @param[out]  Scale            Scale of the column or parameter.
 * @param[out]  Nullable         Specifies if the column or parameter can contain NULL values.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetDescRecW (
        SQLHDESC        DescriptorHandle,
        SQLSMALLINT     RecNumber,
        SQLWCHAR *          Name,
        SQLSMALLINT     BufferLength,
        SQLSMALLINT *   StringLength,
        SQLSMALLINT *   Type,
        SQLSMALLINT *   SubType,
        SQLLEN *        Length,
        SQLSMALLINT *   Precision,
        SQLSMALLINT *   Scale,
        SQLSMALLINT *   Nullable);


/**
 * ODBC function. This function is used to retrieve diagnostic information from an environment, connection, statement or descriptor object.
 *
 * @param[in]	HandleType       Type of the handle in parameter two.
 * @param[in]	Handle           CLI handle identifying the environment, connection, statement or descriptor object.
 * @param[in]	RecNumber        Ordinal position of the memorized diagnostic information in the list. Starts at 1.
 * @param[in]	DiagIdentifier   Type of information to return.
 * @param[out]	DiagInfo         Buffer where the driver will retrieve the information.
 * @param[in]	BufferLength     Size in bytes of the buffer.
 * @param[out]	StringLength     The length in bytes of the value returned in the buffer.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetDiagField (
        SQLSMALLINT     HandleType,
        SQLHANDLE       Handle,
        SQLSMALLINT     RecNumber,
        SQLSMALLINT     DiagIdentifier,
        SQLPOINTER      DiagInfo,
        SQLSMALLINT     BufferLength,
        SQLSMALLINT *   StringLength);


/**
 * ODBC function. The wide-char version of EXAGetDiagField. This function is used to retrieve diagnostic information from an environment, connection, statement or descriptor object.
 *
 * @param[in]   HandleType      Type of the handle in parameter two.
 * @param[in]   Handle          CLI handle identifying the environment, connection, statement or descriptor object.
 * @param[in]   RecNumber       Ordinal position of the memorized diagnostic information in the list. Starts at 1.
 * @param[in]   DiagIdentifier  Type of information to return.
 * @param[out]  DiagInfo        Buffer where the driver will retrieve the information.
 * @param[in]   BufferLength    Size in bytes of the buffer.
 * @param[out]  StringLength    The length in bytes of the value returned in the buffer.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetDiagFieldW (
        SQLSMALLINT     HandleType,
        SQLHANDLE       Handle,
        SQLSMALLINT     RecNumber,
        SQLSMALLINT     DiagIdentifier,
        SQLPOINTER      DiagInfo,
        SQLSMALLINT     BufferLength,
        SQLSMALLINT *   StringLength);


/**
 * ODBC function. Retrieves the most commonly asked diagnostic information from an environment, connection, statement or descriptor object.
 *
 * @param[in]   HandleType      Type of the handle in parameter two.
 * @param[in]   Handle          CLI handle identifying the environment, connection, statement or descriptor object.
 * @param[in]   RecNumber       Ordinal position of the memorized diagnostic information in the list. Starts at 1.
 * @param[out]  Sqlstate        A code made of 5 characters (English letters and numbers) identifying the diagnostic information. This is locale independent. The provided buffer must be at least 5 bytes long.
 * @param[in]   NativeErrorPtr  Buffer where the driver returns an numeric error code. In EXASolution-CLI this is -1 for errors, greater or equal 0 for status messages and warnings.
 * @param[out]  MessageText     The diagnostic text. If translations for the current locale are available the translated text is returned. Default is English.
 * @param[in]   BufferLength    Length in characters of the buffer.
 * @param[out]  TextLengthPtr   Length in characters of the message text.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetDiagRec (
        SQLSMALLINT     HandleType,
        SQLHANDLE       Handle,
        SQLSMALLINT     RecNumber,
        SQLCHAR *       Sqlstate,
        SQLINTEGER *    NativeErrorPtr,
        SQLCHAR *       MessageText,
        SQLSMALLINT     BufferLength,
        SQLSMALLINT *   TextLengthPtr);


/**
 * ODBC function. Wide-char version of EXAGetDiagRec. Retrieves the most commonly asked diagnostic information from an environment, connection, statement or descriptor object.
 *
 * @param[in]   HandleType      Type of the handle in parameter two.
 * @param[in]   Handle          CLI handle identifying the environment, connection, statement or descriptor object.
 * @param[in]   RecNumber       Ordinal position of the memorized diagnostic information in the list. Starts at 1.
 * @param[out]  Sqlstate        A code made of 5 characters (English letters and numbers) identifying the diagnostic information. This is locale independent. The provided buffer must be at least 5 bytes long.
 * @param[in]   NativeErrorPtr  Buffer where the driver returns an numeric error code. In EXASolution-CLI this is -1 for errors, greater or equal 0 for status messages and warnings.
 * @param[out]  MessageText     The diagnostic text. If translations for the current locale are available the translated text is returned. Default is English.
 * @param[in]   BufferLength    Length in characters of the buffer.
 * @param[out]  TextLengthPtr   Length in characters of the message text.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetDiagRecW (
        SQLSMALLINT     HandleType,
        SQLHANDLE       Handle,
        SQLSMALLINT     RecNumber,
        SQLWCHAR *      Sqlstate,
        SQLINTEGER *    NativeErrorPtr,
        SQLWCHAR *      MessageText,
        SQLSMALLINT     BufferLength,
        SQLSMALLINT *   TextLengthPtr);


/**
 * ODBC function. Returns some information held by the environment object.
 *
 * @param[in]   EnvironmentHandle CLI handle identifying the environment object.
 * @param[in]   Attribute         Type of the information required.
 * @param[out]  ValuePtr          Buffer where the driver writes the required information.
 * @param[in]   BufferLength      Size of the buffer in bytes.
 * @param[out]  StringLengthPtr   Length in bytes of the value returned.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetEnvAttr (
        SQLHENV         EnvironmentHandle,
        SQLINTEGER      Attribute,
        SQLPOINTER      ValuePtr,
        SQLINTEGER      BufferLength,
        SQLINTEGER *    StringLengthPtr);


/**
 * ODBC function. Returns some information held in the statement object. It can return ODBC standard information and EXASolution specific information like EXA_STMT_ATTR_TOTAL_ROWS that returns the total rowcount of the current resultset.
 *
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @param[in]   Attribute       Identifies the information required.
 * @param[out]  ValuePtr        Buffer for the attribute value.
 * @param[in]   BufferLength    Size in bytes of the buffer.
 * @param[out]  StringLengthPtr Length in bytes of the information returned in the buffer.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetStmtAttr (
        SQLHSTMT        StatementHandle,
        SQLINTEGER      Attribute,
        SQLPOINTER      ValuePtr,
        SQLINTEGER      BufferLength,
        SQLINTEGER *    StringLengthPtr);

/**
 * ODBC function. Returns some information held in the statement object. It can return ODBC standard information and EXASolution specific information like EXA_STMT_ATTR_TOTAL_ROWS that returns the total rowcount of the current resultset.
 * This is the unicode version
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @param[in]   Attribute       Identifies the information required.
 * @param[out]  ValuePtr        Buffer for the attribute value.
 * @param[in]   BufferLength    Size in bytes of the buffer.
 * @param[out]  StringLengthPtr Length in bytes of the information returned in the buffer.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetStmtAttrW (
        SQLHSTMT        StatementHandle,
        SQLINTEGER      Attribute,
        SQLPOINTER      ValuePtr,
        SQLINTEGER      BufferLength,
        SQLINTEGER *    StringLengthPtr);


/**
 * ODBC function. Creates a resultset containing details about the data types supported by the EXASolution.
 *
 * @param[in]   StatementHandle CLI handle identifying a statement object.
 * @param[in]   DataType        Code of the SQL data type that has to be described. If SQL_ALL_TYPES is given here, a resultset containing all data types supported by EXASolution is returned.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAGetTypeInfo (
        SQLHSTMT        StatementHandle,
        SQLSMALLINT     DataType);


/**
 * ODBC function. The current resultset or rowcount will be disposed. If more results are available, the next result is made active. More than one results can be returned by prepared execution using parameter sets or by EXA-batch execution.
 *
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @return      SQL_SUCCESS, SQL_NO_DATA, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAMoreResults (
        SQLHSTMT        StatementHandle);





/**
 * ODBC function. Returns the number of columns held by the current resultset.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[out]  ColumnCountPtr   A buffer where the driver returns the column count.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXANumResultCols (
        SQLHSTMT        StatementHandle,
        SQLSMALLINT *   ColumnCountPtr);


/**
 * ODBC function. Returns the number of parameters needed by the prepared statement. This is the number of parameter placeholders found in the SQL statement.
 *
 * @param[in]   StatementHandle    CLI handle identifying the statement object.
 * @param[out]  ParameterCountPtr  A buffer where the driver returns the parameter count.
 * @return      SQL_SUCCESS, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXANumParams (
        SQLHSTMT        StatementHandle,
        SQLSMALLINT *   ParameterCountPtr);



/**
 * ODBC function. Prepares an SQL statement for execution. The SQL statement is sent to EXASolution which compiles it and prepares the repeated execution of this statement. Prepared statements are the best option only if they are executed with parameter sets with more than one row.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   StatementText    The SQL statement that has to be prepared.
 * @param[in]   TextLength       Length of the statement in characters.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAPrepare (
        SQLHSTMT        StatementHandle,
        SQLCHAR *       StatementText,
        SQLINTEGER      TextLength);


/**
 * ODBC function. Wide-char version of EXAPrepare. Prepares an SQL statement for execution. The SQL statement is sent to EXASolution which compiles it and prepares the repeated execution of this statement. Prepared statements are the best option only if they are executed with parameter sets with more than one row.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   StatementText    The SQL statement that has to be prepared.
 * @param[in]   TextLength       Length of the statement in characters.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAPrepareW (
        SQLHSTMT        StatementHandle,
        SQLWCHAR *      StatementText,
        SQLINTEGER      TextLength);


/**
 * ODBC function. Returns the column names of the primary key for a table.
 *
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAPrimaryKeys (
        SQLHSTMT        StatementHandle,
        char *          CatalogName,
        SQLSMALLINT     NameLength1,
        char *          SchemaName,
        SQLSMALLINT     NameLength2,
        char *          TableName,
        SQLSMALLINT     NameLength3);


/**
 * ODBC function. Wide-char version of EXAPrimaryKeys. Returns the column names of the primary key for a table.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   CatalogName      Search pattern for the name of the catalog in which to look for the table.
 * @param[in]   NameLength1      Primary key catalog name length.
 * @param[in]   SchemaName       Search pattern for the name of the schema in which to look for the table.
 * @param[in]   NameLength2      Primary key schema name length.
 * @param[in]   TableName        Search pattern for the table name where to look for primary keys.
 * @param[in]   NameLength3      Primary key table name length.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAPrimaryKeysW (
        SQLHSTMT        StatementHandle,
        SQLWCHAR *      CatalogName,
        SQLSMALLINT     NameLength1,
        SQLWCHAR *      SchemaName,
        SQLSMALLINT     NameLength2,
        SQLWCHAR *      TableName,
        SQLSMALLINT     NameLength3);


/**
 * ODBC function. Returns the list of input and output parameters as well as the columns that make up the result set for the specified procedures.
 *
 * @param[in]   StatementHandle  CLI handle identifying the statement object.
 * @param[in]   CatalogName      Search pattern for the name of the catalog in which to look for the procedure.
 * @param[in]   NameLength1      Procedure catalog name length.
 * @param[in]   SchemaName       Search pattern for the name of the schema in which to look for the procedure.
 * @param[in]   NameLength2      Procedure schema name length.
 * @param[in]   ProcName         Search pattern for the name of the procedure.
 * @param[in]   NameLength3      Procedure name length.
 * @param[in]   ColumnName       Search pattern for the column name.
 * @param[in]   NameLength4      Column name length.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAProcedureColumns (
        SQLHSTMT        StatementHandle,
        char *          CatalogName,
        SQLSMALLINT     NameLength1,
        char *          SchemaName,
        SQLSMALLINT     NameLength2,
        char *          ProcName,
        SQLSMALLINT     NameLength3,
        char *          ColumnName,
        SQLSMALLINT     NameLength4);


/**
 * ODBC function. Wide-char version of EXAProcedureColumns. Returns the list of input and output parameters, as well as the columns that make up the result set for the specified procedures.
 *
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @param[in]   CatalogName     Search pattern for the name of the catalog in which to look for the procedure.
 * @param[in]   NameLength1     Procedure catalog name length.
 * @param[in]   SchemaName      Search pattern for the name of the schema in which to look for the procedure.
 * @param[in]   NameLength2     Procedure schema name length.
 * @param[in]   ProcName        Search pattern for the name of the procedure.
 * @param[in]   NameLength3     Procedure name length.
 * @param[in]   ColumnName      Search pattern for the column name.
 * @param[in]   NameLength4     Column name length.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAProcedureColumnsW (
        SQLHSTMT        StatementHandle,
        SQLWCHAR *      CatalogName,
        SQLSMALLINT     NameLength1,
        SQLWCHAR *      SchemaName,
        SQLSMALLINT     NameLength2,
        SQLWCHAR *      ProcName,
        SQLSMALLINT     NameLength3,
        SQLWCHAR *      ColumnName,
        SQLSMALLINT     NameLength4);


/**
 * ODBC function. Returns the list of procedure names stored in EXASolution.
 *
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @param[in]   CatalogName     Search pattern for the name of the catalog in which to look for the procedures.
 * @param[in]   NameLength1     Procedures catalog name length.
 * @param[in]   SchemaName      Search pattern for the name of the schema in which to look for the procedures.
 * @param[in]   NameLength2     Procedures schema name length.
 * @param[in]   ProcName        Search pattern for the name of the procedures.
 * @param[in]   NameLength3     Procedures name length.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
*/
EXA_DLL_EXPORT SQLRETURN  EXAProcedures (
        SQLHSTMT        StatementHandle,
        char *          CatalogName,
        SQLSMALLINT     NameLength1,
        char *          SchemaName,
        SQLSMALLINT     NameLength2,
        char *          ProcName,
        SQLSMALLINT     NameLength3);


/**
 * ODBC function. Wide-char version of EXAProcedures. Returns the list of procedure names stored in EXASolution.
 *
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @param[in]   CatalogName     Search pattern for the name of the catalog in which to look for the procedures.
 * @param[in]   NameLength1     Procedures catalog name length.
 * @param[in]   SchemaName      Search pattern for the name of the schema in which to look for the procedures.
 * @param[in]   NameLength2     Procedures schema name length.
 * @param[in]   ProcName        Search pattern for the name of the procedures.
 * @param[in]   NameLength3     Procedures name length.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
*/
EXA_DLL_EXPORT SQLRETURN  EXAProceduresW (
        SQLHSTMT        StatementHandle,
        SQLWCHAR *      CatalogName,
        SQLSMALLINT     NameLength1,
        SQLWCHAR *      SchemaName,
        SQLSMALLINT     NameLength2,
        SQLWCHAR *      ProcName,
        SQLSMALLINT     NameLength3);


/**
 * ODBC function. Allows the user to change the values of some connection attributes.
 *
 * @param[in]   ConnectionHandle CLI handle identifying the connection object.
 * @param[in]   Attribute        Code of the attribute to be set.
 * @param[in]   ValuePtr         Buffer containing the new attribute value.
 * @param[in]   StringLength     Length in bytes of the variable length attribute values.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXASetConnectAttr (
        SQLHDBC         ConnectionHandle,
        SQLINTEGER      Attribute,
        SQLPOINTER      ValuePtr,
        SQLINTEGER      StringLength);


/**
 * ODBC function. Wide-char version of EXASetConnectAttr. Allows the user to change the values of some connection attributes.
 *
 * @param[in]   ConnectionHandle CLI handle identifying the connection object.
 * @param[in]   Attribute        Code of the attribute to be set.
 * @param[in]   ValuePtr         Buffer containing the new attribute value.
 * @param[in]   StringLength     Length in bytes of the variable length attribute values.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXASetConnectAttrW (
        SQLHDBC         ConnectionHandle,
        SQLINTEGER      Attribute,
        SQLPOINTER      ValuePtr,
        SQLINTEGER      StringLength);


/**
 * ODBC function. Sets the value of a single field of a descriptor record.
 *
 * @param[in]   DescriptorHandle CLI handle that identifies a descriptor object.
 * @param[in]   RecNumber Number of the record (column) affected. Starts at 1.
 * @param[in]   FieldIdentifier Identifies the affected field.
 * @param[in]   Value Buffer containing the new value.
 * @param[in]   BufferLength Length in bytes of the new value.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXASetDescField  (
        SQLHDESC        DescriptorHandle,
        SQLSMALLINT     RecNumber,
        SQLSMALLINT     FieldIdentifier,
        SQLPOINTER      Value,
        SQLINTEGER      BufferLength);

/**
 * ODBC function. Sets the value of a single field of a descriptor record.
 * This is the unicode version of the function.
 * 
 * @param[in]   DescriptorHandle CLI handle that identifies a descriptor object.
 * @param[in]   RecNumber Number of the record (column) affected. Starts at 1.
 * @param[in]   FieldIdentifier Identifies the affected field.
 * @param[in]   Value Buffer containing the new value.
 * @param[in]   BufferLength Length in bytes of the new value.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXASetDescFieldW  (
        SQLHDESC        DescriptorHandle,
        SQLSMALLINT     RecNumber,
        SQLSMALLINT     FieldIdentifier,
        SQLPOINTER      Value,
        SQLINTEGER      BufferLength);



/**
 * ODBC function. Sets the value of a set of fields in a descriptor record.
 *
 * @param[in]   DescriptorHandle CLI handle that identifies a descriptor object.
 * @param[in]   RecNumber        Number of the record (column) affected. Starts at 1.
 * @param[in]   Type             Data type of the record.
 * @param[in]   SubType          Additional data type information supplied for SQL_DATETIME or SQL_INTERVAL types.
 * @param[in]   Length           Octet length of the record.
 * @param[in]   Precision        Precision of the record.
 * @param[in]   Scale            Scale of the record.
 * @param[in]   Data             Pointer to the columns or the parameters data buffer.
 * @param[in]   StringLength     Pointer to the columns or the parameter string length buffer.
 * @param[in]   Indicator        Pointer to the columns or the parameters indicator buffer.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXASetDescRec (
        SQLHDESC        DescriptorHandle,
        SQLSMALLINT     RecNumber,
        SQLSMALLINT     Type,
        SQLSMALLINT     SubType,
        SQLLEN          Length,
        SQLSMALLINT     Precision,
        SQLSMALLINT     Scale,
        SQLPOINTER      Data,
        SQLLEN *        StringLength,
        SQLLEN *        Indicator);


/**
 * ODBC function. Sets the value of an environment attribute.
 *
 * @param[in]   EnvironmentHandle  CLI handle that identifies a environment object.
 * @param[in]   Attribute          A constant identifying the attribute.
 * @param[in]   ValuePtr           Buffer for the new value of the attribute.
 * @param[in]   StringLength       Length in bytes of the value if it is a string.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXASetEnvAttr (
        SQLHENV         EnvironmentHandle,
        SQLINTEGER      Attribute,
        SQLPOINTER      ValuePtr,
        SQLINTEGER      StringLength);


/**
 * ODBC function. Sets the position of the cursor in the result set. Only the operation SQL_POSITION is accepted in EXA-CLI.
 *
 * @param[in]   StatementHandle CLI handle that identifies the statement object.
 * @param[in]   RowNumber       A row number in the result set.
 * @param[in]   Operation       Use here only the constant: SQL_POSITION.
 * @param[in]   LockType        unused.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXASetPos (
        SQLHSTMT        StatementHandle,
        SQLBIGINT       RowNumber,
        SQLSMALLINT     Operation,
        SQLSMALLINT     LockType);


/**
 * ODBC function. Sets the value of a statement attribute.
 *
 * @param[in]   StatementHandle CLI handle that identifies the statement object.
 * @param[in]   Attribute       A constant identifying the attribute.
 * @param[in]   ValuePtr        Buffer holding the new attribute value.
 * @param[in]   StringLength    Length in bytes of the new value if it is a string.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXASetStmtAttr (
        SQLHSTMT        StatementHandle,
        SQLINTEGER      Attribute,
        SQLPOINTER      ValuePtr,
        SQLINTEGER      StringLength);


/**
 * ODBC function. Sets the value of a statement attribute.
 * This is the unicode version of the function.
 * @param[in]   StatementHandle CLI handle that identifies the statement object.
 * @param[in]   Attribute       A constant identifying the attribute.
 * @param[in]   ValuePtr        Buffer holding the new attribute value.
 * @param[in]   StringLength    Length in bytes of the new value if it is a string.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXASetStmtAttrW (
        SQLHSTMT        StatementHandle,
        SQLINTEGER      Attribute,
        SQLPOINTER      ValuePtr,
        SQLINTEGER      StringLength);


/**
 * ODBC function. Returns a list of tables and the privileges associated with each table.
 *
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @param[in]   CatalogName     Search pattern for the name of the catalog in which to look for the table.
 * @param[in]   NameLength1     Table catalog name length.
 * @param[in]   SchemaName      Search pattern for the name of the schema in which to look for the table.
 * @param[in]   NameLength2     Table schema name length.
 * @param[in]   TableName       Search pattern for the name of the table.
 * @param[in]   NameLength3     Table name length.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXATablePrivileges(
        SQLHSTMT        StatementHandle,
        char *          CatalogName,
        SQLSMALLINT     NameLength1,
        char *          SchemaName,
        SQLSMALLINT     NameLength2,
        char *          TableName,
        SQLSMALLINT     NameLength3);


/**
 * ODBC function. Wide-char version of EXATablePrivileges. Returns a list of tables and the privileges associated with each table.
 *
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @param[in]   CatalogName     Search pattern for the name of the catalog in which to look for the table.
 * @param[in]   NameLength1     Table catalog name length.
 * @param[in]   SchemaName      Search pattern for the name of the schema in which to look for the table.
 * @param[in]   NameLength2     Table schema name length.
 * @param[in]   TableName       Search pattern for the name of the table.
 * @param[in]   NameLength3     Table name length.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXATablePrivilegesW(
        SQLHSTMT        StatementHandle,
        SQLWCHAR *      CatalogName,
        SQLSMALLINT     NameLength1,
        SQLWCHAR *      SchemaName,
        SQLSMALLINT     NameLength2,
        SQLWCHAR *      TableName,
        SQLSMALLINT     NameLength3);


/**
 * ODBC function. Returns the list of table, catalog, or schema names, and table types, stored in the database.
 *
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @param[in]   CatalogName     Search pattern for the name of the catalogs in which to look for the tables.
 * @param[in]   NameLength1     Catalog name length.
 * @param[in]   SchemaName      Search pattern for the name of the schemas in which to look for the tables.
 * @param[in]   NameLength2     Schema name length.
 * @param[in]   TableName       Search pattern for the name of the tables.
 * @param[in]   NameLength3     Table name length.
 * @param[in]   TableType       Type of the table. Possible values are: "VIEW", "TABLE".
 * @param[in]   NameLength4     Length of the type identifier.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXATables (
        SQLHSTMT        StatementHandle,
        char *          CatalogName,
        SQLSMALLINT     NameLength1,
        char *          SchemaName,
        SQLSMALLINT     NameLength2,
        char *          TableName,
        SQLSMALLINT     NameLength3,
        char *          TableType,
        SQLSMALLINT     NameLength4);


/**
 * ODBC function. Wide-char version of EXATables. Returns the list of table, catalog, or schema names, and table types, stored in the database.
 *
 * @param[in]   StatementHandle CLI handle identifying the statement object.
 * @param[in]   CatalogName     Search pattern for the name of the catalogs in which to look for the tables.
 * @param[in]   NameLength1     Catalog name length.
 * @param[in]   SchemaName      Search pattern for the name of the schemas in which to look for the tables.
 * @param[in]   NameLength2     Schema name length.
 * @param[in]   TableName       Search pattern for the name of the tables.
 * @param[in]   NameLength3     Table name length.
 * @param[in]   TableType       Type of the table. Possible values are: "VIEW", "TABLE".
 * @param[in]   NameLength4     Length of the type identifier.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXATablesW (
        SQLHSTMT        StatementHandle,
        SQLWCHAR *      CatalogName,
        SQLSMALLINT     NameLength1,
        SQLWCHAR *      SchemaName,
        SQLSMALLINT     NameLength2,
        SQLWCHAR *      TableName,
        SQLSMALLINT     NameLength3,
        SQLWCHAR *      TableType,
        SQLSMALLINT     NameLength4);


/**
 * ODBC function. Executes a commit or a rollback on the currently open transaction.
 *
 * @param[in]   HandleType        Specifies the type of the handle.
 * @param[in]   Handle            CLI handle identifying a connection or an environment object.
 * @param[in]   CompletionType    SQL_COMMIT or SQL_ROLLBACK.
 * @return      SQL_SUCCESS, SQL_SUCCESS_WITH_INFO, SQL_ERROR, SQL_INVALID_HANDLE.
 */
EXA_DLL_EXPORT SQLRETURN  EXAEndTran  (
        SQLSMALLINT     HandleType,
        SQLHANDLE       Handle,
        SQLSMALLINT     CompletionType);


#endif//EXACINTERFACE_H


