#ifndef EXA_DEFS_H
#define EXA_DEFS_H

/** @file
 * @brief EXASolution CLI header file for EXASolution specific attributes.
 *
 * This are connection and statement attributes, used in functions like EXASetConnectAttr, EXAGetConnectAttr, EXASetStmtAttr, EXAGetStmtAttr.
 */

#if !defined(_WIN32) && !defined(NDEBUG) && !defined(_DEBUG)
#define _DEBUG 1
#endif

//Attributes used by SAP, ACCESS, ...:
//Stmt attr
#define UNKNOWN1002  1002
#define UNKNOWN3002  3002
//Dbc attr
#define UNKNOWN1011  1011
#define UNKNOWN1014  1014
#define UNKNOWN1015  1015
#define UNKNOWN1042  1042
#define UNKNOWN1052  1052
#define UNKNOWN30002 30002
#ifndef SQL_DLL_INDEX
#define SQL_DLL_INDEX 170
#endif
#ifndef SQL_CONVERT_GUID
#define SQL_CONVERT_GUID 173
#endif

///////////////////////////
//EXA specific attributes//
///////////////////////////


#define EXA_STMT_ATTR_PTR_ARRAY 21001

#define EXA_STMT_ATTR_PTR_ARRAY_SIZE 21002

#define EXA_STMT_ATTR_TOTAL_ROWS 21003

#define EXA_MAX_DATA_LEN 21004

#define EXA_MAX_STATEMENT_LEN 21005

#define EXA_USER_NAME 21006

#define EXA_DSN_NAME 21007

/** Used in EXASetConnectAttr it tells the driver to return SQL_SUCCESS after ever call of EXAPrepare. This doesn't affect what EXAPrepare does in EXASolution.
 * Type of ValuePtr: size_t */
#define EXA_PREPARE_ALWAYS_SUCCESSFUL 21009

/** Used in EXASetConnectAttr it specifies the name of the client who uses the driver. The name is send to the EXASolution server at connect time and appears in the log file.
 * Type of ValuePtr: char* */
#define EXA_CLIENT_NAME 21010

#define EXA_BYTES_READ_FROM_SERVER 21011
#define EXA_BYTES_WRITTEN_TO_SERVER 21012

/** Used in EXAGetConnectAttr it returns the current schema form the EXASolution session.
 * Type of ValuePtr: char* */
#define EXA_CURRENT_SCHEMA 21016

/** Used in EXASetConnectAttr or EXAGetConnectAttr it sets or returns the decimal numeric characters for the current session, for example: ",.". First character is the decimal separator, the second character is the thousands separator.
 * Type of ValuePtr: char* */
#define EXA_NUMERIC_CHARACTERS 21017

#define EXA_KEEP_ALIVE_SOCKET 21018

/** Used in EXASetConnectAttr it specifies version information of the client who uses the driver. The information is send to the EXASolution server at connect time and appears in the log file.
 * Type of ValuePtr: char* */
#define EXA_CLIENT_VERSION 21019

#define EXA_STMT_ATTR_PREPARED_MESSAGE_LEN 21022

#define EXA_STMT_ATTR_PROTOCOL_VER 21026

#define EXA_ATTR_PROTOCOL_VER EXA_STMT_ATTR_PROTOCOL_VER

#define EXA_CONNECT_ATTR_GET_DEFAULT_CONVERTER_PTR EXA_STMT_ATTR_GET_DEFAULT_CONVERTER_PTR

#define EXA_NUMERIC_CHARACTERS_IN_NUMERIC_PARAMETERS 21028

/** Used in EXAGetConnectAttr or EXASetConnectAttr it returns or sets the locale for the connection.
 * Type of ValuePtr: char* */
#define EXA_CONNECTION_LOCALE_ALL 21029
#define EXA_CONNECTION_LOCALE EXA_CONNECTION_LOCALE_ALL

#define EXA_CONNECTION_LOCALE_NUMERIC 21030

#define EXA_CONNECTION_DEFAULT_LOCALE 21031

//Ver 5 (alt, 2.0) Ver 6 (Unicode), Ver 7 (Unicode, Pwd encript)
#define EXA_CLIENT_SERVER_PROTOCOL_VER 21032

/** Used in EXAGetConnectAttr it returns the codesets supported by the EXASolution server.
 * Type of ValuePtr: char* */
#define EXA_GET_SUPPORTED_CODESETS 21033

/** Used in EXAGetConnectAttr it reads a pointer to a string in witch the driver holds a list of all host names actually active in the EXASolution cluster.
 * Type of ValuePtr: char** */
#define EXA_GET_HOSTS_PTR 21035

#define SQL_STMT_ATTR_GET_CLI_HANDLE 21036

/** Used in EXAGetConnectAttr it returns the version string of the EXASolution server where the driver is connected to.
 * Type of ValuePtr: char* */
#define EXA_SERVER_VERSION 21037

/** Used in EXAGetConnectAttr it returns the SVN revision of the EXASolution server where the driver is connected to.
 * Type of ValuePtr: char* */
#define EXA_SERVER_REVISION 21038

#define EXA_GET_CLUSTER 21039

#define EXA_GET_CLUSTER_SIZE 21040

/** Used in EXAGetConnectAttr it returns a pointer to a ConnectionStru holding the host and port of the server.
 * Type of ValuePtr: ConnectionStru** */
#define EXA_GET_SERVER 21041

/** Used in EXASetConnectAttr it kills the session with the ID specified in ValuePtr.
 * Type of ValuePtr: exa_int64 */
#define EXA_KILL_SESSION 21042

/** Used in EXAGetConnectAttr it returns the state of the actual transaction. The state can be: 1 if the transaction is committed, 0 if a transaction is open.
 * Type of ValuePtr: SQLUINTEGER* */
#define EXA_TRANSACTION_STATE 21043

/** Used in EXASetConnectAttr it forces a disconnect form the server. Sending in ValuePtr a value bigger than zero forces the connection to close, not expecting any confirmation from EXASolution.
 * Type of ValuePtr: size_t */
#define EXA_CLOSE_SOCKET 21045
#define EXA_COGNOSSUPPORT 21046
#define EXA_DESCRIBEFORCOLUMNS 21047
#define EXA_ANSI_DATA_ENCODING 21048
#define EXA_ANSI_ARG_ENCODING 21049
#define EXA_EXTENDED_FETCH_MAPPING 21050
#define EXA_CONNECTION_STRING 21051
#define MAX_KEYWORD_LEN 40
#define EXA_LOG_FULL 21053 
#define EXA_LOG_FULL_FILE 21054
#define EXA_LOG_FULL_MUTEX 21055

/** Used in EXASetConnectAttr. Possible values: "Y" and "N". If the value of this attribute is set to "Y", all catalog functions called in this connection will return table information only on the current schema. 
 * Type of ValuePtr: char* */ 
#define EXA_SHOW_ONLY_CURRENT_SCHEMA 21056

/** Used in EXASetConnectAttr. Possible values: "Y" and "N". If the value of this attribute is set to "Y", strings that are NULL read from resultsets created in this connection will be fetched as empty strings with length 0.
 * Type of ValuePtr: char* */ 
#define EXA_STRINGS_NOT_NULL 21057

#define EXA_ATTR_LICENSE_FILE 21058
#define EXA_GET_HOSTS_STRING 21059
#define EXA_UNICODE_ARG_ENCODING 21060
#define EXA_ATTR_FEEDBACK_INTERVAL 21061

/** Used in EXASetConnectAttr to set the maximum ColumnSize returned in EXADescribeParam for varchar columns.
 * Type of ValuePtr: SQLUINTEGER */
#define EXA_MAX_PARAM_SIZE 21062

#define EXA_SILENT_ATTR_ROWS_FETCHED_PTR 21063
#define EXA_SILENT_ATTR_ROW_STATUS_PTR 21064

/** Used in EXASetConnectAttr to set the ColumnSize returned in EXADescribeParam if the type cannot be determined
 * at compile time and the EXASolution server asks for varchar parameter data.
 * Type of ValuePtr: SQLUINTEGER */
#define EXA_DEFAULT_PARAM_SIZE 21065

#define EXA_UNICODE_DATA_ENCODING 21066
#define EXA_CONNECTION_LOCALE_CTYPE 21067
#define EXA_ALWAYS_USE_SEARCH_PATTERNS_IN_CATALOG_FUNCTIONS 21068
#define EXA_ERROR_RESET 21069
#define EXA_SILENT_ATTR_AUTOCOMMIT 21070
#define EXA_SILENT_ATTR_CURRENT_SCHEMA 21071
#define EXA_SILENT_ATTR_CURRENT_CATALOG 21072
#define EXA_CHARACTER_DISPLAY_SIZE 21073
//SQLUINTEGER:
#define EXA_GET_SERVER_VERSION_INT 21074
#define EXA_INT_TYPES_IN_RESULTS_IF_POSSIBLE 21075
#define EXA_SILENT_ATTR_IMP_ROW_DESC 21076
#define EXA_DEFAULT_C_TYPE 21077
/** Type timestamp UTC enabled (needed by loader)
*  Type of ValuePtr: SQLLEN */
#define EXA_ATTR_TSUTC_ENABLED 21078
/** Used in EXAGetConnectAttr it returns the session id of the current session.
 * Type of ValuePtr: exa_int64* */
#define EXA_SESSION_ID_DEPRECATED -9912
#define EXA_SESSION_ID 21079

#define EXA_TRUNCATE_DECIMALS_DEPRECATED -9913
#define EXA_TRUNCATE_DECIMALS 21080

/** Used in EXAGetStmtAttr it returns a pointer to the text of the current statement hold by the statement handle.
 * Type of ValuePtr: char** */
#define EXA_CURRENT_SQL_STMT_TEXT_PTR_DEPRECATED -9914
#define EXA_CURRENT_SQL_STMT_TEXT_PTR 21081

#define EXA_TIMESTAMP_PRECISION_DEPRECATED -9915
#define EXA_TIMESTAMP_PRECISION 21082

/** Used in EXAGetStmtAttr it returns the position of the cursor in the current result set.
 * Type of ValuePtr: SQLBIGINT* */
#define EXA_GET_CURSOR_DEPRECATED -9916
#define EXA_GET_CURSOR 21083

#define EXA_DESC_OCTET_LENGTH_BACKUP_DEPRECATED -9917
#define EXA_DESC_OCTET_LENGTH_BACKUP 21084

#define EXA_SET_CURSOR_DEPRECATED -9918
#define EXA_SET_CURSOR 21085

/** Used in EXASetStmtAttr it tells the driver to use string parameters as a pointer to string array. For the parameter column specified in ValuePtr, the
 * driver will dereference the char*'s found in the bound parameter array and use the strings pointed by them. This can save a lot of memory.
 * Type of ValuePtr: size_t */
#define EXA_PARAM_DATA_POINTERS_ON_DEPRECATED -9919
#define EXA_PARAM_DATA_POINTERS_ON 21086

/** Used in EXASetStmtAttr it tells the driver to read the string values of the specified column in default mode.
 * Type of ValuePtr: size_t */
#define EXA_PARAM_DATA_POINTERS_OFF_DEPRECATED -9920
#define EXA_PARAM_DATA_POINTERS_OFF 21087

#define EXA_WORD_FOR_TRUE_DEPRECATED -9921
#define EXA_WORD_FOR_TRUE 21088

#define EXA_WORD_FOR_FALSE_DEPRECATED -9922
#define EXA_WORD_FOR_FALSE 21089

//Statement attributes:
//Get server intern resultset handle. Val: SQLINTEGER
#define EXA_GET_EXA_HANDLE_DEPRECATED -9903
#define EXA_GET_EXA_HANDLE 21090

//Set floating precision in printf.
#define EXA_STMT_ATTRIBUTE_FLOAT_PRECISION_DEPRECATED -9904
#define EXA_STMT_ATTRIBUTE_FLOAT_PRECISION 21091

/** Used in EXAGetStmtAttr it will return the size of the result set in rows. 
 * Type of ValuePtr: SQLBIGINT* */
#define EXA_STMT_ATTR_MY_ROW_COUNT_DEPRECATED -9905
#define EXA_STMT_ATTR_MY_ROW_COUNT 21092

//Set internal standardised numeric output. Val: char
#define EXA_EXTERNAL_CONVERTION_DEPRECATED -9906
#define EXA_EXTERNAL_CONVERTION 21093

//Get server intern prepared statement handle. Val: SQLINTEGER
#define EXA_GET_PREPARED_HANDLE_DEPRECATED -9907
//Statement attribute
#define EXA_GET_PREPARED_HANDLE 21094
//Connection attribute, SQLBIGINT, 0=off, -1=first and last, n=number of lines from the beginning of the block 
#define EXA_LOG_FULL_LINES 21095
#define EXA_SESSION_TIMEZONE 21096
#define EXA_SESSION_TIMEZONE_BEHAVIOR 21097
#define EXA_SILENT_GET_SESSION_ID 21098
#define EXA_SOCKET_ENCRYPTION 21099
#define EXA_RANDOM_SEED 21101
#define EXA_IS_CONNECTION_ENCRYPTED 21102
#define EXA_SERVER_ENFORCED_ENCRYPTION 21103
#define EXA_DEBUG_COMM 21104
#define EXA_COLUMNS_MICRO_CACHE 21105
#define EXA_LEGACY_CATALOG 21106
#define EXA_GET_STMT_STATUS_MSG 21107
#define EXA_MAX_HANDLES 21108 //used only for debugging, upper limit is 2000

#ifndef MAX_PATH
#define MAX_PATH 260  
#endif

#ifdef _WIN32 
#define snprintf _snprintf
#endif

#ifdef _WIN32
#define SETCODEPAGEERROR -1
#else
#define SETCODEPAGEERROR NULL
#endif

#define NUM_BUFFER_SIZE 128
#define LOGIN_MAGIC 0x01121201
#define MINIMUM_SUPPORTED_PROTOCOL_VERSION 7
#define MAXIMUM_SUPPORTED_PROTOCOL_VERSION 13

#define EXA_TIMESTAMP_SIZE 20
#define EXA_DATE_SIZE 10

#define FIRST_VALID_PTR 10000

#define NEW_SYSTEM_SCHEMA "\"$ODBCJDBC\"."

#define EXA_INT8				421
#define EXA_INT16				422
#define EXA_INT32				423
#define EXA_INT64				424
#define EXA_INT128				425
#define EXA_INT192				426
#define EXA_INT256				427
#define EXA_VARCHAR_PTR			428
#define EXA_WCHAR_UTF8			429
#define EXA_WCHAR_UTF16			430
#define EXA_TYPE_TIMESTAMP_UTC  431

#ifdef _WIN32
    #ifdef EXAWIN64
        typedef __int64 ssize_t;
    #else
        typedef __int32 ssize_t;
    #endif

    typedef __int8 exa_int8;
    typedef __int16 exa_int16;
	typedef unsigned __int16 exa_uint16;
    typedef __int32 exa_int32;
    typedef unsigned __int32 exa_uint32;
    typedef __int64 exa_int64;
    typedef unsigned __int64 exa_uint64;

#else
    #include <inttypes.h>
    typedef int INT;
    typedef int errno_t;
    #if !defined(__INTEL_COMPILER) && !defined(__HP_aCC) && !defined(__HP_cc)
        typedef long long __int64;
    #endif

    typedef int8_t exa_int8;
    typedef int16_t exa_int16;
	typedef uint16_t exa_uint16;
    typedef int32_t exa_int32;
    typedef uint32_t exa_uint32;
    typedef int64_t exa_int64;
    typedef uint64_t exa_uint64;

    #define _TRUNCATE ((size_t)-1)
#endif

#define exa_int128 char[16]

typedef double exa_double;
typedef float exa_real;

#define ODBCINI "odbc.ini"
#define ODBCINI_W L"odbc.ini"

#define MAX_DECIMAL9 999999999
#define MIN_DECIMAL9 -999999999
#define MAX_DECIMAL18 999999999999999999L
#define MIN_DECIMAL18 -999999999999999999L
#define MAX_UINT32  0xFFFFFFFF
#define MAX_INT32   0x7FFFFFFF
#define MIN_INT32  -0x7FFFFFFF
#define MAX_USHORT 0xFFFF
#define MAX_SHORT  0x7FFF
#define MIN_SHORT -0x7FFF
#define MAX_UCHAR  0xFF
#define EXA_MAX_CHAR 0x7F
#define EXA_MIN_CHAR -0x7F

#define T_char _CHAR
#define T_smallint _SMALLINT
#define T_integer _INTEGER
#define T_date _DATE
#define T_boolean _BOOLEAN
#define T_byte _BYTE
#define T_binary _BINARY

#define _RESULT_EMPTY_ -2
//#define _RESULT_ERROR_ -1
//#define _RESULT_ROWCOUNT_ 0
//#define _RESULT_TABLE_ 1
//#define _RESULT_PREPARED_HANDLE_ 2
//#define _RESULT_COLUMN_COUNT_ 3
//#define _RESULT_WARNING_ 4
//#define _RESULT_STILL_EXECUTING_ 5
//#define _RESULT_MORE_ROWS_ 6

#define EXA_DIRECT 0
#define EXA_PREPARE 1

#define EXA_CONNECTED 1
#define EXA_NOT_CONNECTED 0
#define EXA_RESULTSET_HANDLE 4
#define EXA_COLUMN_HANDLE 5
#define INT_CONVER_BUFFER_LEN 64
#define SQL_HANDLE 101
#define EXA_ANY_HANDLE 99
#define MAX_HOSTLIST_SIZE 0x7FFF /*32767*/
#define MAX_EXACLUSTER_NODES 1000

#define EXA_NULL_DATA 0
#define EXA_NOT_NULL 1

#define DEFAULT_ROWSET_SIZE 1

#define VERSION_BUFFER_SIZE 128

#define DEFAULT_MAX_IDENTIFIER_LEN 128

#define DEFAULT_MAX_VARCHAR_LEN 20000

#define MAX_IDENTIFIER_OCTET_LEN 512

#define MAX_LITERAL_PRE_AND_SUFIX_LEN 8

#define EXA_CLOSE 1
#define EXA_RESET_PARAMS 3

//Bitmap for charAttr
#define IS_VARCHAR 1
#define IS_UTF8 16

//Defines form Windows <share.h>
#ifndef _SH_DENYRW
#define _SH_DENYRW      0x10    /* deny read/write mode */
#define _SH_DENYWR      0x20    /* deny write mode */
#define _SH_DENYRD      0x30    /* deny read mode */
#define _SH_DENYNO      0x40    /* deny none mode */
#define _SH_SECURE      0x80    /* secure mode */
#endif


//DSN
#define EXA_SERVER			        L"EXA Server"
#define EXA_PORT			        L"EXA Port"
#define EXA_UID			            L"EXA UID"
#define EXA_PWD				        L"EXA PWD"
#define EXA_SCHEMA			        L"EXA Schema"
#define EXA_LOGFILE			        L"SQL log file"
#define PREPARE_AS			        L"Prepare AS"
#define CONNECTION_LCALL	        L"Connection LC_ALL"
#define CONNECTION_LCNUMERIC        L"Connection LC_NUMERIC"
#define AUTOCOMMIT                  L"Autocommit"
#define QUERY_TIMEOUT               L"Query Timeout"
#define COGNOS_SUPPORT              L"Cognos Support"
#define ADDITIONAL_PARAMS           L"Additional Params"

//Connection string 
#define UID                         L"UID"
#define EXAUID                      L"EXAUID"
#define PWD                         L"PWD"
#define EXAPWD                      L"EXAPWD"
#define EXAHOST                     L"EXAHOST"
#define EXAPORT                     L"EXAPORT"
#define EXASCHEMA                   L"EXASCHEMA"
#define EXALOGFILE                  L"EXALOGFILE"
#define DRIVER                      L"DRIVER"
#define PREPAREAS                   L"PREPAREAS"
#define CONNECTIONLCALL             L"CONNECTIONLCALL"
#define CONNECTIONLCCTYPE           L"CONNECTIONLCCTYPE"
#define CONNECTIONENCODING          L"ENCODING"
#define COGNOSSUPPORT               L"COGNOSSUPPORT"
#define DESCRIBEFORCOLUMNS          L"DESCRIBEFORCOLUMNS"
#define CONNECTIONLCNUMERIC         L"CONNECTIONLCNUMERIC"
#define DSN                         L"DSN"
#define SAVEFILE                    L"SAVEFILE"
#define FILEDSN                     L"FILEDSN"
#define QUERYTIMEOUT                L"QUERYTIMEOUT"
#define DRIVERUNICODETYPE           L"DriverUnicodeType"
#define ANSIARGENCODING             L"AnsiArgEncoding"
#define ANSIDATAENCODING            L"AnsiDataEncoding"
#define UNICODEARGENCODING          L"UnicodeArgEncoding"
#define UNICODEDATAENCODING         L"UnicodeDataEncoding"
#define LOGMODE                     L"LogMode"
#define LOGFULL						L"LogFull"
#define SHOWONLYCURRENTSCHEMA       L"ShowOnlyCurrentSchema"
#define STRINGSNOTNULL              L"StringsNotNull"
#define INTTYPESINRESULTSIFPOSSIBLE L"IntTypesInResultsIfPossible"
#define MAXPARAMSIZE                L"MaxParamSize"
#define DEFAULTPARAMSIZE            L"DefaultParamSize"
#define FEEDBACKINTERVAL            L"FeedbackInterval"
#define ALWAYSSEARCHPATTERNSINCAT   L"AlwaysSearchPatternsInCat"
#define CHARACTERDISPLAYSIZE        L"CharacterDisplaySize"
#define ENCRYPTION                  L"Encryption"
#define ENCRYPTIONSEED              L"EncryptionSeed"
#define OPENSCHEMA                  L"OpenSchema"
#define COLUMNSMICROCACHE           L"ColumnsMicroCache"
#define METADATAID                  L"MetadataID"
#define LEGACYCATALOG               L"LegacyCatalog"
#define MAXHANDLES                  L"MaxHandles"

//Log modes
#define LM_VERBOSE					"VERBOSE"
#define LM_DEBUGCOMM				"DEBUGCOMM"
#define LM_DEBUGCOMM_WORDS			"DEBUG COMM"
#define LM_DEFAULT					"DEFAULT"
#define LM_ON_ERROR_ONLY			"ONERRORONLY"
#define LM_ON_ERROR_ONLY_WORDS		"ON ERROR ONLY"
#define LM_NONE						"NONE"

//Temporary ODBC Log file Keys
#define EXA_ODBC_CONFIG_TMP_SECTION L"EXASolution ODBC Config"
#define EXA_ODBC_CONFIG_TMP_ENTRY L"TmpInstallDir"

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#endif
