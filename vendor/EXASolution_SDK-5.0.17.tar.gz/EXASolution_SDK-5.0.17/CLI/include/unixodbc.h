#ifndef UNIXODBCWRAPPER_H
#define UNIXODBCWRAPPER_H


/* SIZEOF_LONG_INT is defined in unixodbc_conf.h, but this
 * header is generated differently on x86 and x86_64.
 * To simplify things, define SIZEOF_LONG_INT here to overwrite
 * the definition in unixodbc_conf.h.
 */
#if (__WORDSIZE > 32) || defined(__LP64__) || defined(_LP64)
	#define SIZEOF_LONG_INT 8
#else
	#define SIZEOF_LONG_INT 4
#endif

#include <uo2214/sql.h>
#include <uo2214/sqlext.h>
#include <uo2214/odbcinst.h>


#endif
