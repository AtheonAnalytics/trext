EXASolution SDK

Copyright (c) 2004-2016 EXASOL AG. All rights reserved.

This package contains tools and libraries for the development of external
applications to interact with EXASolution and to use features like User
Defined Functions (UDFs).

* Packages for R and Python: We provide packages for R and Python
  for easily executing Python and R code on the EXASolution database from
  within your usual programming environment or IDE.

* Hadoop Integration Services: An implementation of the eUDF framework to
  connect Hadoop and EXASolution. Please consult the section
  "Hadoop Integration Service" in the manual for details.

* External User Defined Functions (eUDF): Tools for creating external
  services that run functions in any language, callable from EXASolution.

* Call Level Interface (CLI): for developing applications in C++. Comparable
  to ODBC but with additional features.

The UDF/eUDF parts of this package are tested and supported on Linux only,
but may work on other POSIX systems.

Please consult the README.txt files in the sub directories.
