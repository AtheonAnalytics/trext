Hadoop Integration Service

Copyright (c) 2004-2016 EXASOL AG. All rights reserved.

==========================
Hadoop Integration Service
==========================

The Hadoop Integration Service is a Java implementation of an eUDF service
and input/output format classes for the interconnection between EXASolution
and Hadoop jobs. This directory can be imported to Eclipse.

The two subfolders v1 and v2 contain implementations for Hadoop v1 and
Hadoop v2 (YARN).

-------------
Prerequisites
-------------

The Hadoop Integration Service requires ZeroMQ 2.2, Google Protocol Buffers
2.5.0 and a current version of jZMQ. To compile the dependencies you
need libuuid-devel, libgcc, autotools, libtool and Apache Maven. These
packages are part of normal Linux distributions and can be installed with
their package manager.

Installation of ZeroMQ
----------------------
$> wget http://download.zeromq.org/zeromq-2.2.0.tar.gz
$> tar xzvf zeromq-2.2.0.tar.gz
$> cd zeromq-2.2.0 && ./configure && make && sudo make install
$> sudo ln -s /usr/local/lib/libzmq.* /usr/lib/hadoop/lib/native/

Installation of Google Protocol Buffers
---------------------------------------
$> wget http://protobuf.googlecode.com/files/protobuf-2.5.0.tar.gz
$> tar xzvf protobuf-2.5.0.tar.gz
$> cd protobuf-2.5.0 && ./configure && make && sudo make install
$> ln -s /usr/local/lib/libproto* /usr/lib/hadoop/lib/native/
$> cd java
$> mvn install
$> sudo cp ~/.m2/repository/com/google/protobuf/protobuf-java/2.5.0/protobuf-java-2.5.0.jar /usr/lib/hadoop/

Installation of jZMQ
--------------------
$> git clone https://github.com/zeromq/jzmq.git
$> cd jzmq && ./autogen.sh && ./configure && make && sudo make install
$> sudo ln -s /usr/local/lib/libjzmq* /usr/lib/hadoop/lib/native/
$> sudo cp /usr/local/share/java/zmq.jar /usr/lib/hadoop/

Usage
-----
Please read the examples in files EXAGrep.java and EXAWordCount.java
in directory "v2/src/exasol/hadoop/". They contain fully working
examples.

The installation and usage is the same for both implementations (Hadoop 
v1 and v2).

