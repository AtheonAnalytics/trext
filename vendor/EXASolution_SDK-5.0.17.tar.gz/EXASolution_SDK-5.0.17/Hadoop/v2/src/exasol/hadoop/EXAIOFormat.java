package exasol.hadoop;

import exasol.hadoop.*;
import exasol.hadoop.ZMQContainer.*;
import exasol.hadoop.ZMQContainer.message_type.*;
import com.google.protobuf.InvalidProtocolBufferException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.lang.Runnable;
import java.net.InetAddress;
import java.util.List;
import java.util.Map.Entry;
import java.util.Iterator;
import java.util.Collections;
import java.util.ArrayList;
import java.util.LinkedList;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.InputFormat;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.RecordWriter;
import org.apache.hadoop.mapreduce.OutputCommitter;
import org.apache.hadoop.mapreduce.OutputFormat;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.InputSplit;
import org.zeromq.ZMQ;

public class EXAIOFormat {
    public static enum ColumnType {
        STRING, DATE, DOUBLE, INT32, INT64, NUMERIC, TIMESTAMP, BOOLEAN
    }

    public static class Key {
        private EXAIOFormat io;
        public Key(EXAIOFormat io) { this.io = io; }
        public Key(Configuration conf) throws IOException, InterruptedException {
            io = EXAIOFormat.createInstance(conf);
            if (!io.nextGroup())
                throw new IOException("Could not get a SQL group to writting");            
        }
        public Key(String manager, long sessionId) throws IOException, InterruptedException {
            io = EXAIOFormat.createInstance(manager, sessionId);
            if (!io.nextGroup())
                throw new IOException("Could not get a SQL group");
        }
        public Value getValue() { return io.currentGroup(); }
        public boolean next() throws IOException, InterruptedException {
            return io.nextGroup();
        }
        public EXAIOFormat getIO() { return io; }
        public void close() throws IOException { io.close(); }
    }

    public interface Value {
        public long currentRow();
        public long rowsInBlock();
        public long rowsInGroup();
        public int inputColumnsCount();
        public String inputColumnName(int column);
        public ColumnType inputColumnType(int column) throws IOException;
        public int outputColumnsCount();
        public String outputColumnName(int column);
        public ColumnType outputColumnType(int column) throws IOException;
        public boolean readNextRow(boolean resetGroup) throws IOException;
        public String getString(int column) throws IOException;
        public Boolean getBoolean(int column) throws IOException;
        public Integer getInt(int column) throws IOException;
        public Long getLong(int column) throws IOException;
        public Double getDouble(int column) throws IOException;
        public RowSetter newResultRow();
        public void flushResultRows() throws IOException;
    }

    public interface RowSetter {
        public RowSetter setString(String d) throws IOException;
        public RowSetter setInt(Integer d) throws IOException;
        public RowSetter setLong(Long d) throws IOException;
        public RowSetter setDouble(Double d) throws IOException;
        public RowSetter setBoolean(Boolean d) throws IOException;
        public Value emit() throws IOException;
    }

    public static class Input extends InputFormat<Key, Value> {
        public static class Split extends InputSplit implements Writable {
            public String url;
            public long sessionId;
            public long length = 1;
            public String[] locations = new String[0];

            public long getLength() throws IOException { return length; }
            public String[] getLocations() throws IOException { return locations; }

            public void write(DataOutput out) throws IOException {
                out.writeUTF(url);
                out.writeLong(sessionId);
                out.writeLong(length);
            }
            
            public void readFields(DataInput in) throws IOException {
                url = in.readUTF();
                sessionId = in.readLong();
                length = in.readLong();
            }
        }

        public static class Reader extends RecordReader<Key, Value> {
            private Split split;
            private EXAIOFormat container;
            private int currentPos = 0, posOnCurrentContainer = 0;
            private Key currentKey;

            public void initialize(InputSplit inputSplit, TaskAttemptContext context) throws IOException {
                split = (Split) inputSplit;
                System.err.printf("Initialize instance on url %s for session %d with context\n", split.url, split.sessionId);
                container = EXAIOFormat.createInstance(context.getConfiguration());
                currentKey = new Key(container);
            }
            public void initialize(Split s) throws IOException {
                split = s;
                System.err.printf("Initialize instance on url %s for session %d withoun context\n", split.url, split.sessionId);
                container = EXAIOFormat.createInstance(split.url, split.sessionId);
                currentKey = new Key(container);
            }
            public boolean nextKeyValue() throws IOException, InterruptedException {
                if (!container.nextGroup())
                    return false;
                ++currentPos;
                ++posOnCurrentContainer;
                return true;
            }

            public Key getCurrentKey() { return currentKey; }
            public Value getCurrentValue() { return container.currentGroup(); }
            public void close() throws IOException { container.close(); }
            public long getPos() throws IOException { return currentPos; }
            public float getProgress() throws IOException {
                return 1.0f - 1.0f / ((float) currentPos + 1.0f);
            }
        }

        public List<InputSplit> getSplits(JobContext context) throws IOException, InterruptedException {
            LinkedList<InputSplit> splits = new LinkedList<InputSplit>();
            Configuration conf = context.getConfiguration();
            if (!conf.get("exasol.method").equals("input"))
                throw new IOException("Invalid exasol.method configuration, should be 'input'");
            int splitsNumber = conf.getInt("exasol.input.splits", 0);
            if (splitsNumber < 1)
                throw new IOException("Invalid exasol.input.splits configuration, should be >0");
            long sessionId = conf.getLong("exasol.session", 0);
            if (sessionId == 0)
                throw new IOException("Invalid exasol.session configuration, should be >0");

            for (int i = 0; i < splitsNumber; i++) {
                Split split = new Split();
                split.url = conf.get("exasol.manager");
                split.sessionId = conf.getLong("exasol.session", 0);
                splits.add(split);
            }
                 
            return splits;
        }

        public RecordReader<Key, Value> createRecordReader(InputSplit split, TaskAttemptContext context) throws IOException, InterruptedException {
            Split exasplit = (Split) split;
            Reader reader = new Reader();
            return reader;
        }
    }

    public static class Output extends OutputFormat<Key, Value> {
        public static class Committer extends OutputCommitter {
            public void setupJob(JobContext jobContext) throws IOException {}
            public void commitJob(JobContext jobContext) throws IOException {}
            public void abortJob(JobContext jobContext, org.apache.hadoop.mapreduce.JobStatus.State state) throws IOException {}
            public void setupTask(TaskAttemptContext taskContext) throws IOException {}
            public boolean needsTaskCommit(TaskAttemptContext taskContext) throws IOException { return false; }
            public void commitTask(TaskAttemptContext taskContext) throws IOException {}
            public void abortTask(TaskAttemptContext taskContext) throws IOException {}
            public boolean isRecoverySupported() { return false; }
        }

        public static class Writer extends RecordWriter<Key, Value> {
            private EXAIOFormat io;
            public void write(Key key, Value value) throws IOException, InterruptedException {
                if (io == null) io = key.getIO();
                else if (io != key.getIO())
                    throw new IOException("Writting with different EXAIOFormat instances not supported");
                value.flushResultRows();
            }
            public void close(TaskAttemptContext context) throws IOException, InterruptedException {
                if (io != null)
                    io.close();
            }
        }
        
        public RecordWriter<Key,Value> getRecordWriter(TaskAttemptContext context) throws IOException, InterruptedException {
            return new Writer();
        }
        public void checkOutputSpecs(JobContext context) throws IOException, InterruptedException {
            Configuration conf = context.getConfiguration();
            if (!conf.get("exasol.method").equals("output"))
                throw new IOException("Invalid exasol.method configuration, should be 'output'");
        }
        public OutputCommitter getOutputCommitter(TaskAttemptContext context) throws IOException, InterruptedException {
            return new Committer();
        }
    }

    public static class Group implements Value {
        public exascript_info info;
        public exascript_metadata meta;

        private List<exascript_metadata.column_definition> inputColumnsList;
        private int inputColumnsCount;
        private List<exascript_metadata.column_definition> outputColumnsList;
        private int outputColumnsCount;
        private int stringPos = 0, stringColumns[];
        private int boolPos = 0, boolColumns[];
        private int intPos = 0, intColumns[];
        private int longPos = 0, longColumns[];
        private int doublePos = 0, doubleColumns[];
        private int currentRow = 0;
        private exascript_table_data data;
        private exascript_table_data.Builder output;
        private EXAIOFormat container;

        public Group(EXAIOFormat container, exascript_info info, exascript_metadata meta, exascript_table_data data) throws IOException {
            this.container = container; this.info = info; this.meta = meta; this.data = data;
            inputColumnsList = meta.getInputColumnsList();
            inputColumnsCount = meta.getInputColumnsCount();
            stringColumns = new int[inputColumnsCount];
            boolColumns = new int[inputColumnsCount];
            intColumns = new int[inputColumnsCount];
            longColumns = new int[inputColumnsCount];
            doubleColumns = new int[inputColumnsCount];

            output = exascript_table_data.newBuilder();
            output.setRowsInGroup(0);
            outputColumnsList = meta.getOutputColumnsList();
            outputColumnsCount = meta.getOutputColumnsCount();
        }

        public long currentRow() { return currentRow - 1; }
        public long rowsInBlock() { return data.getRows(); }
        public long rowsInGroup() { return data.getRowsInGroup(); }
        public int inputColumnsCount() { return inputColumnsCount; }
        public int outputColumnsCount() { return outputColumnsCount; }
        public String inputColumnName(int column) { return inputColumnsList.get(column).getName(); }
        public String outputColumnName(int column) { return outputColumnsList.get(column).getName(); }

        private ColumnType getColType(List<exascript_metadata.column_definition> collist, int column) throws IOException {
            switch(collist.get(column).getType()) {
            case PB_BOOLEAN   : return ColumnType.BOOLEAN;
            case PB_DOUBLE    : return ColumnType.DOUBLE;
            case PB_INT32     : return ColumnType.INT32;
            case PB_INT64     : return ColumnType.INT64;
            case PB_NUMERIC   : return ColumnType.NUMERIC;
            case PB_DATE      : return ColumnType.DATE;
            case PB_TIMESTAMP : return ColumnType.TIMESTAMP;
            case PB_STRING    : return ColumnType.STRING;
            }
            throw new IOException("Unknown input column type");
        }

        public ColumnType inputColumnType(int column) throws IOException {
            return getColType(inputColumnsList, column);
        }

        public ColumnType outputColumnType(int column) throws IOException {
            return getColType(outputColumnsList, column);
        }
                
        private boolean readNextBlock(boolean resetGroup) throws IOException {
            flushResultRows();
            data = container.receiveNextBlock(resetGroup);
            if (data == null) return false;
            stringPos = boolPos = intPos = longPos = doublePos = currentRow = 0;
            return true;
        }

        public boolean readNextRow(boolean resetGroup) throws IOException {
            if (resetGroup)
                if (!readNextBlock(true))
                    return false;
            if (currentRow >= data.getRows()) {
                flushResultRows();
                if (!readNextBlock(false))
                    return false;
            }
            int colnum = 0;
            int nulloffset = currentRow * inputColumnsCount;
            boolean isnull = false;
            for (exascript_metadata.column_definition col : inputColumnsList) {
                stringColumns[colnum] = -1;
                boolColumns[colnum] = -1;
                intColumns[colnum] = -1;
                longColumns[colnum] = -1;
                doubleColumns[colnum] = -1;
                isnull = data.getDataNulls(nulloffset++);
                switch(col.getType()) {
                case PB_BOOLEAN   : boolColumns[colnum]   = isnull ? -2 : boolPos++; break;
                case PB_DOUBLE    : doubleColumns[colnum] = isnull ? -2 : doublePos++; break;
                case PB_INT32     : intColumns[colnum]    = isnull ? -2 : intPos++; break;
                case PB_INT64     : longColumns[colnum]   = isnull ? -2 : longPos++; break;
                case PB_NUMERIC   :
                case PB_DATE      :
                case PB_TIMESTAMP :
                case PB_STRING    : stringColumns[colnum] = isnull ? -2 : stringPos++; break;
                default: throw new IOException("Unknown input column type");
                }
                ++colnum;
            }
            ++currentRow;
            return true;
        }

        public String getString(int column) throws IOException {
            if (stringColumns[column] == -2) return null;
            else if (stringColumns[column] == -1)
                throw new IOException("Wrong column type");
            return data.getDataString(stringColumns[column]);
        }

        public Boolean getBoolean(int column) throws IOException {
            if (boolColumns[column] == -2) return null;
            else if (boolColumns[column] == -1)
                throw new IOException("Wrong column type");
            return data.getDataBool(boolColumns[column]);
        }

        public Integer getInt(int column) throws IOException {
            if (intColumns[column] == -2) return null;
            else if (intColumns[column] == -1)
                throw new IOException("Wrong column type");
            return data.getDataInt32(intColumns[column]);
        }

        public Long getLong(int column) throws IOException {
            if (longColumns[column] == -2) return null;
            else if (longColumns[column] == -1)
                throw new IOException("Wrong column type");
            return data.getDataInt64(longColumns[column]);
        }

        public Double getDouble(int column) throws IOException {
            if (doubleColumns[column] == -2) return null;
            else if (doubleColumns[column] == -1)
                throw new IOException("Wrong column type");
            return data.getDataDouble(doubleColumns[column]);
        }

        public static class SetRow implements RowSetter {
            private int columnNumber = 0;
            private exascript_table_data.Builder output;
            private exascript_metadata meta;
            private EXAIOFormat container;
            private Value value;

            public SetRow(Value value, EXAIOFormat container, exascript_metadata meta, exascript_table_data.Builder output) {
                this.value = value; this.container = container; this.meta = meta; this.output = output;
            }
            public RowSetter setString(String d) throws IOException {
                column_type ct = meta.getOutputColumns(columnNumber).getType();
                if ((ct != column_type.PB_STRING)
                    && (ct != column_type.PB_DATE)
                    && (ct != column_type.PB_TIMESTAMP)
                    && (ct != column_type.PB_NUMERIC))
                    throw new IOException("Wrong column type");
                if (d == null) output.addDataNulls(true);
                else { output.addDataString(d); output.addDataNulls(false); }
                return columnNumber++ >= meta.getOutputColumnsCount() ? null : this;
            }
            public RowSetter setInt(Integer d) throws IOException  {
                if (meta.getOutputColumns(columnNumber).getType() != column_type.PB_INT32)
                    throw new IOException("Wrong column type");
                if (d == null) output.addDataNulls(true);
                else { output.addDataInt32(d); output.addDataNulls(false); }
                return columnNumber++ >= meta.getOutputColumnsCount() ? null : this;
            }
            public RowSetter setLong(Long d) throws IOException  {
                if (meta.getOutputColumns(columnNumber).getType() != column_type.PB_INT64)
                    throw new IOException("Wrong column type");
                if (d == null) output.addDataNulls(true);
                else { output.addDataInt64(d); output.addDataNulls(false); }
                return columnNumber++ >= meta.getOutputColumnsCount() ? null : this;
            }
            public RowSetter setDouble(Double d) throws IOException  {
                if (meta.getOutputColumns(columnNumber).getType() != column_type.PB_DOUBLE)
                    throw new IOException("Wrong column type");
                if (d == null) output.addDataNulls(true);
                else { output.addDataDouble(d); output.addDataNulls(false); }
                return columnNumber++ >= meta.getOutputColumnsCount() ? null : this;
            }
            public RowSetter setBoolean(Boolean d) throws IOException  {
                if (meta.getOutputColumns(columnNumber).getType() != column_type.PB_BOOLEAN)
                    throw new IOException("Wrong column type");
                if (d == null) output.addDataNulls(true);
                else { output.addDataBool(d); output.addDataNulls(false); }
                return columnNumber++ >= meta.getOutputColumnsCount() ? null : this;
            }
            public Value emit() throws IOException {
                if (columnNumber != meta.getOutputColumnsCount())
                    throw new IOException("Not all columns emited");
                if (!output.hasRows()) output.setRows(1);
                else output.setRows(output.getRows() + 1);
                return value;
            }
        }

        public RowSetter newResultRow() {
            return new SetRow(this, container, meta, output);
        }

        public void flushResultRows() throws IOException {
            if (output.getRows() > 0)
                container.emitData(output);
        }
    }
    
    private static class Pinger implements Runnable {
        private ZMQ.Socket sock;
        private String url;
        private long sessionId;
        private boolean finished;

        public Pinger(ZMQ.Context ctx, String url, long sessionId) {
            this.url = url;
            this.sessionId = sessionId;
            sock = ctx.socket(ZMQ.REQ);
            sock.connect(url);
            finished = false;
        }

        public synchronized void finish() {
            finished = true;
        }

        private synchronized boolean isFinished() {
            return finished;
        }

        public void run() {
            try {
                byte[] req =
                    EXAProtocol.request.newBuilder()
                    .setSessionId(sessionId)
                    .setUrl(url)
                    .setConfig(false)
                    .setRegister(false)
                    .build()
                    .toByteArray();
                EXAProtocol.response rep;
                while (!isFinished()) {
                    sock.send("EXASOL HADOOP 1.0", ZMQ.SNDMORE);
                    sock.send(req, 0);
                    rep = EXAProtocol.response.parseFrom(sock.recv(0));
                    if (!rep.getOk()) return;
                    if (rep.getFinished()) finish();
                    else Thread.sleep(500);
                }
            } catch (InvalidProtocolBufferException err) {
            } catch (InterruptedException err) { }
        }
    }

    private String managerUrl;
    private long sessionId;
    private int pos;
    private ZMQ.Socket managerSock;
    private ZMQ.Socket exaSock;
    private int exaPort;
    private ZMQ.Context ctx = ZMQ.context(1);
    private String url;
    private Pinger pinger;
    private Thread pingerThread;
    private exascript_info exaInfo;
    private exascript_metadata exaMeta;
    private exascript_request.Builder req;
    private long connectionId = 0;
    private Group currentGroup;
    private Key defaultKey;
    private boolean readGroupsFinished = false;
    private boolean readBlocksFinished = true;
    private boolean exaDisconnected = true;

    public static EXAIOFormat createInstance(Configuration conf) throws IOException {
        /* print current job configuration
        System.err.printf("--- Job configuration ---\n");
        List<String> conflist = new ArrayList<String>();
        Iterator<Entry<String, String>> confit = conf.iterator();
        while(confit.hasNext()) conflist.add(confit.next().getKey());
        Collections.sort(conflist);
        for(String key : conflist)
            System.err.printf("%s = %s\n", key, conf.get(key));
        System.err.printf("-------------------------\n");
        */

        return createInstance(conf.get("exasol.manager", null),
                              conf.getLong("exasol.session", 0));
    }

    public static EXAIOFormat createInstance(String manager, long sessionId) throws IOException {
        if (manager == null)
            throw new IOException("Invalid exasol.manager should contain URL to the manager");
        if (sessionId == 0)
            throw new IOException("Invalid exasol.sessios configuration, should be >0");
        return new EXAIOFormat(manager, sessionId);
    }

    public EXAIOFormat(String managerUrl, long sessionId) throws IOException {
        this.managerUrl = managerUrl;
        this.sessionId = sessionId;
        req = exascript_request.newBuilder();
        defaultKey = new Key(this);
        managerSock = ctx.socket(ZMQ.REQ);
        managerSock.connect(managerUrl);
        exaSock = ctx.socket(ZMQ.REQ);
        exaPort = exaSock.bindToRandomPort("tcp://0.0.0.0");
        byte[] ip = InetAddress.getLocalHost().getAddress();
        url = String.format("tcp://%d.%d.%d.%d:%d", (int)ip[0]&0xFF, (int)ip[1]&0xFF, (int)ip[2]&0xFF, (int)ip[3]&0xFF, exaPort);
        registerOnManager();
        pinger = new Pinger(ctx, managerUrl, sessionId);
        pingerThread = new Thread(pinger);
        pingerThread.start();
        connectToEXASolution();
    }

    private exascript_response comm(exascript_request.Builder req, message_type[] recvTypes) throws IOException {
        exascript_response rep;
        exaSock.send(req.build().toByteArray(), 0);
        rep = exascript_response.parseFrom(exaSock.recv(0));
        if (connectionId == 0) connectionId = rep.getConnectionId();
        else if (rep.getConnectionId() != connectionId)
            throw new IOException("Received wrong connection ID");
        boolean typeFound = false;
        for (message_type t : recvTypes)
            if (typeFound = (t == rep.getType()))
                break;
        if (!typeFound) throw new IOException("Received wrong response type");
        return rep;
    }

    private exascript_request.Builder exareq(message_type sendType) {
        return req.clear().setType(sendType).setConnectionId(connectionId);
    }

    private void registerOnManager() throws IOException {
        EXAProtocol.request req = EXAProtocol.request.newBuilder()
            .setSessionId(sessionId)
            .setUrl(url)
            .setConfig(false)
            .setRegister(true)
            .build();
        managerSock.send("EXASOL HADOOP 1.0", ZMQ.SNDMORE);
        managerSock.send(req.toByteArray(), 0);
        EXAProtocol.response rep = EXAProtocol.response.parseFrom(managerSock.recv(0));
        if (!rep.getOk()) {
            if (!rep.hasError()) throw new IOException("Unknown error on register reader");
            else throw new IOException(String.format("Error on register reader: %s",
                                                     rep.getError()));
        }
    }

    private void connectToEXASolution() throws IOException {
        exascript_response rep;      

        /* initiate connection with EXASolution and get meta information about connection */
        rep = comm(exareq(message_type.MT_CLIENT)
                   .setClient(exascript_client.newBuilder()
                              .setClientName(url)),
                   new message_type[]{message_type.MT_INFO});
        exaInfo = rep.getInfo();

        /* recv meta information about data */
        rep = comm(exareq(message_type.MT_META),
                   new message_type[]{message_type.MT_META});
        exaMeta = rep.getMeta();
        readGroupsFinished = readBlocksFinished = exaDisconnected = false;
    }

    private void disconnectFromEXASolution() throws IOException {
        if (!exaDisconnected) {
            exaDisconnected = true;
            exascript_response rep = comm(exareq(message_type.MT_FINISHED),
                                          new message_type[]{message_type.MT_FINISHED});
            readGroupsFinished = readBlocksFinished = true;
            exaSock.close();
        }
    }

    public exascript_table_data receiveNextBlock(boolean resetGroup) throws IOException {
        if (readGroupsFinished || readBlocksFinished)
            return null;
        message_type mt = resetGroup ? message_type.MT_RESET : message_type.MT_NEXT;
        exascript_response rep;
        rep = comm(exareq(mt),
                   new message_type[]{mt, message_type.MT_DONE, message_type.MT_CLOSE});
        if (rep.getType() == message_type.MT_DONE) {
            readBlocksFinished = true;
            return null;
        }
        if (rep.getType() == message_type.MT_CLOSE) {
            if (rep.getClose().hasExceptionMessage())
                throw new IOException(String.format("Got error from EXASolution: %s",
                                                    rep.getClose().getExceptionMessage()));
            throw new IOException("Unknown EXASolution error");
        }
        return rep.getNext().getTable();
    }

    public void emitData(exascript_table_data.Builder data) throws IOException {
        comm(exareq(message_type.MT_EMIT)
             .setEmit(exascript_emit_data_req.newBuilder().setTable(data)),
             new message_type[]{message_type.MT_EMIT});
        data.clear().setRows(0).setRowsInGroup(0);
    }

    public boolean nextGroup() throws IOException, InterruptedException {
        if (readGroupsFinished)
            return false;
        exascript_response rep;
        readGroupsFinished = true;
        readBlocksFinished = true;
        if (currentGroup != null) {
            /* finish last iteration */
            currentGroup = null;
            rep = comm(exareq(message_type.MT_DONE),
                       new message_type[]{message_type.MT_DONE, message_type.MT_CLEANUP});
            if (rep.getType() == message_type.MT_CLEANUP) {
                disconnectFromEXASolution();
                return false;
            }
        }
        /* recv next data */
        rep = comm(exareq(message_type.MT_RUN),
                   new message_type[]{message_type.MT_RUN, message_type.MT_CLEANUP});
        if (rep.getType() == message_type.MT_CLEANUP) {
            disconnectFromEXASolution();
            return false;
        }

        readGroupsFinished = false;
        readBlocksFinished = false;

        currentGroup = new Group(this, exaInfo, exaMeta, rep.getNext().getTable());
        if (!currentGroup.readNextRow(false)) {
            currentGroup = null;
            readGroupsFinished = false;
            readBlocksFinished = false;
            return false;
        }

        return true;
    }

    public Group currentGroup() { return currentGroup; }
    public Key currentKey() { return defaultKey; }

    public void close() throws IOException {
        disconnectFromEXASolution();
        pinger.finish();
        for (;;) {
            try { pingerThread.join(); }
            catch (InterruptedException err) { continue; }
            break;
        }
    }

    static public void main(String[] args) throws java.io.IOException, java.lang.InterruptedException {
        /* Test main, normally not used */
        EXAIOFormat.Input.Split split = new EXAIOFormat.Input.Split();
        split.url = args[0];
        split.sessionId = Long.parseLong(args[1]);
        EXAIOFormat.Input.Reader reader = new EXAIOFormat.Input.Reader();
        reader.initialize(split);
        while (reader.nextKeyValue()) {
            EXAIOFormat.Key key = reader.getCurrentKey();
            EXAIOFormat.Value value = reader.getCurrentValue();
            for(;;) {
                RowSetter res = value.newResultRow();
                System.out.println(value.getString(1));
                for(int c = 0; c < value.inputColumnsCount(); c++) {
                    switch(value.inputColumnType(c)) {
                    case DOUBLE    : res = res.setDouble(value.getDouble(c)); break;
                    case INT32     : res = res.setInt(value.getInt(c)); break;
                    case INT64     : res = res.setLong(value.getLong(c)); break;
                    case STRING    :
                    case DATE      :
                    case NUMERIC   :
                    case TIMESTAMP : res = res.setString(value.getString(c)); break;
                    case BOOLEAN   : res = res.setBoolean(value.getBoolean(c)); break;
                    }
                }
                res.emit();
                    
                if (!value.readNextRow(false)) break;
            }
        }
    }
}
