package exasol.hadoop;

import exasol.hadoop.*;
import com.google.protobuf.InvalidProtocolBufferException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.lang.Exception;
import java.lang.RuntimeException;
import java.lang.ClassNotFoundException;
import java.lang.InterruptedException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Iterator;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Properties;
import java.util.Stack;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.JobStatus;
import org.apache.hadoop.util.StringUtils;
import org.zeromq.ZMQ;

public class EXAManager {
    private static final Log LOG = LogFactory.getLog(EXAManager.class);

    private static class Session {
        public Long sessionId;
        public Job job;
        public String URL;
        public Configuration conf = new Configuration();
        public Properties properties = new Properties();
        public Stack<String> tasks = new Stack<String>();
        public LinkedList<String> vmids = new LinkedList<String>();
        public LinkedList<Long> connections = new LinkedList<Long>();
        public long connectionsCount = 0;
        public boolean finished = false;
        public boolean failed = false;
        public boolean monitorAttempts = false;
        public long maximumTasks = 0;
        public long finishedAt = System.currentTimeMillis();
        public long createdAt = System.currentTimeMillis();
        public long lastTaskPing = System.currentTimeMillis();
        public long lastEXAPing = System.currentTimeMillis();

        public Session(Long sessionId, Reader jobDescription, String URL)
            throws IOException, InterruptedException, ClassNotFoundException, RuntimeException {
            this.sessionId = sessionId;
            this.URL = URL;
            conf = new Configuration();
            properties = new Properties();
            properties.load(jobDescription);
            for(Entry<Object, Object> elem : properties.entrySet())
                conf.set((String) elem.getKey(), (String) elem.getValue());
            conf.set("exasol.manager", URL);
            conf.setLong("exasol.session", sessionId);
            if (!conf.get("exasol.method", "").equals("input") && !conf.get("exasol.method", "").equals("output"))
                throw new RuntimeException("Invalid exasol.method configuration given, should be 'input' or 'output'");
            job = Job.getInstance(conf, String.format("EXASolution session %d", sessionId));

            /* >>> print current job configuration */
            conf = job.getConfiguration();
            System.err.printf("--- Job configuration for session % 10d --- \n", sessionId);
            List<String> conflist = new ArrayList<String>();
            Iterator<Entry<String, String>> confit = conf.iterator();
            while(confit.hasNext()) conflist.add(confit.next().getKey());
            Collections.sort(conflist);
            for(String key : conflist)
                System.err.printf("%s = %s\n", key, conf.get(key, ""));
            System.err.printf("-------------------------------------------------\n");
            /* <<< */

            LOG.info(String.format("Validate job config for session %d", sessionId));
            validateConfig();
            LOG.info(String.format("Submitting job for session %d", sessionId));
            job.submit();
            LOG.info(String.format("Job for session %d submited", sessionId));
        }

        public void validateConfig() {
            if (!conf.get("exasol.method", "").equals("input") && !conf.get("exasol.method", "").equals("output"))
                throw new RuntimeException("Invalid exasol.method configuration given, should be 'input' or 'output'");
            if (conf.get("exasol.method", "").equals("input")) {
                int splitsNumber = conf.getInt("exasol.input.splits", 0);
                int mapAttempts = conf.getInt("mapreduce.map.maxattempts", 0);
                maximumTasks = conf.getInt("mapreduce.job.maps", 0);
                if (splitsNumber < 1)
                    throw new RuntimeException("Invalid number of splits set in configuration variable: exasol.input.splits");
                if (splitsNumber != maximumTasks)
                    LOG.warn(String.format("Configuration variables exasol.input.splits=%d and mapred.map.tasks=%d are not equal", splitsNumber, maximumTasks));
                if (mapAttempts != 1)
                    LOG.warn(String.format("Configuration variable mapred.map.max.attempts=%d is not equal 1, EXAIOFormat does not support multiple attempts", mapAttempts));
                if (!conf.get("mapreduce.job.inputformat.class", "").equals("exasol.hadoop.EXAIOFormat$Input"))
                    LOG.warn("Configuration variable exasol.method is set to 'input' but mapreduce.job.inputformat.class is not 'exasol.hadoop.EXAIOFormat$Input'");
                if (!conf.get("mapreduce.job.input.key.class", "").equals("exasol.hadoop.EXAIOFormat$Key"))
                    LOG.warn("Configuration variable exasol.method is set to 'input' but mapreduce.job.input.key.class is not 'exasol.hadoop.EXAIOFormat$Key'");
                if (!conf.get("mapreduce.job.input.value.class", "").equals("exasol.hadoop.EXAIOFormat$Value"))
                    LOG.warn("Configuration variable exasol.method is set to 'input' but mapreduce.job.input.value.class is not 'exasol.hadoop.EXAIOFormat$Value'");
            } else if (conf.get("exasol.method", "").equals("output")) {                
                int splitsNumber = conf.getInt("exasol.input.splits", 0);
                int reduceAttempts = conf.getInt("mapreduce.reduce.maxattempts", 0);
                maximumTasks = conf.getInt("mapreduce.job.reduces", 0);
                if (splitsNumber != 0)
                    LOG.warn("Configuration variable exasol.input.splits is set with 'output' as exasol.method");
                if (maximumTasks == 0)
                    LOG.warn("No number of reduce tasks with configuration variable mapred.reduce.tasks given, but it should be set to >0");
                if (reduceAttempts != 1)
                    LOG.warn(String.format("Configuration variable mapred.reduce.max.attempts=%d is not equal 1, EXAIOFormat does not support multiple attempts", reduceAttempts));
                if (!conf.get("mapreduce.job.outputformat.class", "").equals("exasol.hadoop.EXAIOFormat$Output"))
                    LOG.warn("Configuration variable exasol.method is set to 'output' but mapreduce.job.outputformat.class is not 'exasol.hadoop.EXAIOFormat$Output'");
                if (!conf.get("mapreduce.job.output.key.class", "").equals("exasol.hadoop.EXAIOFormat$Key"))
                    LOG.warn("Configuration variable exasol.method is set to 'output' but mapreduce.job.output.key.class is not 'exasol.hadoop.EXAIOFormat$Key'");
                if (!conf.get("mapreduce.job.output.value.class", "").equals("exasol.hadoop.EXAIOFormat$Value"))
                    LOG.warn("Configuration variable exasol.method is set to 'output' but mapreduce.job.output.value.class is not 'exasol.hadoop.EXAIOFormat$Value'");
                if (conf.get("mapreduce.map.output.key.class", "") == null)
                    LOG.warn("Configuration variable mapreduce.map.output.key.class is not set, it must be set, but must not be set to EXAIOFormat");
                if (conf.get("mapreduce.map.output.value.class", "") == null)
                    LOG.warn("Configuration variable mapreduce.map.output.value.class is not set, it must be set, but must not be set to EXAIOFormat");
            }
        }
    }
    
    private String URL;
    private ZMQ.Socket sock;
    private ZMQ.Context ctx = ZMQ.context(1);
    private HashMap<Long, Session> connections = new HashMap<Long, Session>();
    private HashMap<Long, Session> sessions = new HashMap<Long, Session>();
    private String lastReport = "";
    
    public EXAManager(String URL) {
        this.URL = URL;
        sock = ctx.socket(ZMQ.REP);
        sock.setLinger(0);
        sock.setReceiveTimeOut(500);
        sock.bind(URL);
    }

    public String preprocessJobDescription(ZMQContainer.exascript_info info, String desc) {
        return desc
            .replace("${database_name}", info.getDatabaseName())
            .replace("${database_version}", info.getDatabaseVersion())
            .replace("${script_name}", info.getScriptName())
            .replace("${session_id}", Long.toString(info.getSessionId()))
            .replace("${statement_id}", Integer.toString(info.getStatementId()))
            .replace("${node_count}", Integer.toString(info.getNodeCount()))
            .replace("${meta_info}", info.getMetaInfo());
    }

    public void handle_exap(ZMQContainer.exascript_request req, ZMQContainer.exascript_response.Builder rep)
        throws IOException, InterruptedException, ClassNotFoundException, RuntimeException {
        rep.setConnectionId(req.getConnectionId());
        if (req.getType() == ZMQContainer.message_type.MT_INFO) {
            /* Make a unique id from session ID and statement ID */
            Long sessionId = Math.abs(req.getInfo().getSessionId() * 10000 + req.getInfo().getStatementId());

            String vmId = String.format("%d_%d", req.getInfo().getNodeId(), req.getInfo().getVmId());
            Reader jobDescription = new StringReader(preprocessJobDescription(req.getInfo(),
                                                                              req.getInfo().getSourceCode()));
            Session ses;
            if (!sessions.containsKey(sessionId)) {
                LOG.info(String.format("Register new session %d", sessionId));
                ses = new Session(sessionId, jobDescription, URL);
                sessions.put(sessionId, ses);
            } else ses = sessions.get(sessionId);
            if (ses.tasks.empty() && !ses.finished) {
                if (ses.monitorAttempts) {
                    LOG.error(String.format("Not enough running tasks for connection %d and session %d, killing job", req.getConnectionId(), sessionId));
                    if (!ses.job.getStatus().isJobComplete())
                        ses.job.killJob();
                }
                rep.setType(ZMQContainer.message_type.MT_TRY_AGAIN);
                ses.lastEXAPing = System.currentTimeMillis();
            } else if (ses.finished) {
                if (ses.failed) {
                    rep.setType(ZMQContainer.message_type.MT_CLOSE);
                    rep.setClose(ZMQContainer.exascript_close.newBuilder()
                                 .setExceptionMessage("Hadoop job failed."));
                } else rep.setType(ZMQContainer.message_type.MT_FINISHED);
            } else {
                String taskURL = ses.tasks.pop();
                connections.put(req.getConnectionId(), ses);
                ses.connections.add(req.getConnectionId());
                ses.connectionsCount++;
                ses.lastTaskPing = System.currentTimeMillis();
                ses.vmids.add(vmId);
                if (ses.vmids.size() >= ses.maximumTasks)
                    ses.monitorAttempts = true;
                LOG.info(String.format("Redirect connection %d on session %d to task %s", req.getConnectionId(), sessionId, taskURL));
                rep.setType(ZMQContainer.message_type.MT_CLIENT);
                rep.setClient(ZMQContainer.exascript_client.newBuilder()
                              .setClientName(taskURL)
                              .setMetaInfo(String.format("redirector at %s for session %d", URL, ses.sessionId)));
            }
        } else if (req.getType() == ZMQContainer.message_type.MT_PING_PONG) {
            if (connections.containsKey(req.getConnectionId())) {
                Session ses = connections.get(req.getConnectionId());
                if (ses.job.getStatus().isJobComplete() || ses.finished) {
                    rep.setType(ZMQContainer.message_type.MT_CLOSE);
                    rep.setClose(ZMQContainer.exascript_close.newBuilder()
                                 .setExceptionMessage("Job unexpectly completed"));
                } else {
                    rep.setType(ZMQContainer.message_type.MT_PING_PONG);
                    ses.lastEXAPing = System.currentTimeMillis();
                }
            } else {
                rep.setType(ZMQContainer.message_type.MT_CLOSE);
                rep.setClose(ZMQContainer.exascript_close.newBuilder()
                             .setExceptionMessage("Unknown connection"));
            }
        } else if (req.getType() == ZMQContainer.message_type.MT_CLOSE) {
            if (req.hasClose()
                && req.getClose().hasExceptionMessage()
                && !req.getClose().getExceptionMessage().equals("")) {
                LOG.error(String.format("Got error message from EXASolution: %s", req.getClose().getExceptionMessage()));
                if (connections.containsKey(req.getConnectionId())) {
                    Session ses = connections.get(req.getConnectionId());
                    if (!ses.job.getStatus().isJobComplete() && !ses.finished)
                        ses.job.killJob();
                }
            }
            rep.setType(ZMQContainer.message_type.MT_CLOSE);
        } else {
            LOG.info(String.format("Got unknown request from connection %d", req.getConnectionId()));
            rep.setType(ZMQContainer.message_type.MT_CLOSE);
            rep.setClose(ZMQContainer.exascript_close.newBuilder()
                         .setExceptionMessage("Unknown message type"));
        }
    }

    public void handle_task(EXAProtocol.request req, EXAProtocol.response.Builder rep) {
        Long sessionId = req.getSessionId();
        Session ses;
        if (sessions.containsKey(sessionId)) {
            ses = sessions.get(sessionId);
            ses.lastTaskPing = System.currentTimeMillis();
            rep.setOk(true);
            if (ses.finished) {
                rep.setFinished(true);
            } else {
                rep.setFinished(false);
                if (req.getRegister()) {
                    LOG.info("Registered new taks with URL " + req.getUrl());
                    ses.tasks.push(req.getUrl());
                }
                if (req.getConfig())
                    rep.setConf(EXAProtocol.config.newBuilder().setSplits(ses.vmids.size()));
            }
        } else { rep.setOk(false); rep.setError("Unknown session id"); }
    }

    public void loop()
        throws com.google.protobuf.InvalidProtocolBufferException,
               RuntimeException, IOException, InterruptedException, ClassNotFoundException {
        EXAProtocol.response.Builder taskResponse = EXAProtocol.response.newBuilder();
        ZMQContainer.exascript_response.Builder exapResponse = ZMQContainer.exascript_response.newBuilder();
        for (;;) {
            byte[] data = sock.recv(0);
            boolean allok = false;
            try {
                if (data == null) {
                    /* timeout on receive, do nothing */
                    allok = true;
                } else if (!sock.hasReceiveMore()) {
                    exapResponse.clear();
                    handle_exap(ZMQContainer.exascript_request.parseFrom(data), exapResponse);
                    sock.send(exapResponse.build().toByteArray(), 0);
                    allok = true;
                } else if (new String(data).equals("EXASOL HADOOP 1.0")) {
                    data = sock.recv(0);
                    handle_task(EXAProtocol.request.parseFrom(data), taskResponse);
                    sock.send(taskResponse.build().toByteArray(), 0);
                    allok = true;
                } else throw new RuntimeException("Got request of unknown protocol");
            } finally {
                try { if (!allok) sock.send("ERROR: Wrong protocol".getBytes(), 0); }
                catch (Exception err) { }
            }
            LinkedList<Long> toDelete = new LinkedList<Long>();
            for (Session ses : sessions.values()) {
                if (ses.finished && (System.currentTimeMillis() - ses.finishedAt) > 600000) {
                    toDelete.push(ses.sessionId);
                } else if (!ses.finished) {
                    if (ses.job.mapProgress() > 0 || ses.job.reduceProgress() > 0) {
                        String report = String.format("Job for session %d: map %s reduce %s",
                                                      ses.sessionId,
                                                      StringUtils.formatPercent(ses.job.mapProgress(), 0),
                                                      StringUtils.formatPercent(ses.job.reduceProgress(), 0));
                        if (!report.equals(lastReport)) {
                            LOG.info(report);
                            lastReport = report;
                        }
                    }
                    JobStatus status = ses.job.getStatus();
                    if (status.isJobComplete()) {
                        ses.finished = true;
                        ses.finishedAt = System.currentTimeMillis();
                        if (ses.job.isSuccessful())
                            LOG.info(String.format("Job for session %d completed successfully", ses.sessionId));
                        else {
                            ses.failed = true;
                            if (status.getFailureInfo().equals(""))
                                LOG.info(String.format("Job for session %d failed with state %s due to unknown reason",
                                                       ses.sessionId, status.getState()));
                            else LOG.info(String.format("Job for session %d failed with state %s due to: '%s'",
                                                        ses.sessionId, status.getState(), status.getFailureInfo()));
                        }
                        LOG.info(String.format("Session %d is finished", ses.sessionId));
                        for (long conn : ses.connections)
                            connections.remove(conn);
                        ses.connections = new LinkedList<Long>();
                    } else {
                        if ((System.currentTimeMillis() - ses.lastEXAPing) > 600000) {
                            LOG.warn(String.format("Ping timeout with EXASolution on session %d, killing job", ses.sessionId));
                            ses.job.killJob();
                        }
                        if (ses.connectionsCount > 0 && (System.currentTimeMillis() - ses.lastTaskPing) > 600000) {
                            LOG.warn(String.format("Ping timeout with job tasks on session %d, killing job", ses.sessionId));
                            ses.job.killJob();
                        }
                    }
                }
            }
            for (Long sesId : toDelete) {
                LOG.info(String.format("Remove session %d", sesId));
                sessions.remove(sesId);
            }
        }
    }

    public static void main(String[] args) throws InvalidProtocolBufferException, InterruptedException, IOException, ClassNotFoundException {
        if (args.length != 1) {
            System.err.printf("Usage: EXAManager.class <URL>\n");
            System.exit(1);
        }
        EXAManager manager = new EXAManager(args[0]);
        manager.loop();
        /*try { manager.loop(); }
        catch (Exception err) {
            System.err.printf("@@@ ERROR: %s", err.getMessage());
        }*/
    }
}
