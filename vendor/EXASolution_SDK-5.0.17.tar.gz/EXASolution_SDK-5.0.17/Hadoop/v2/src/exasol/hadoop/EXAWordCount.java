package exasol.hadoop;

import java.lang.InterruptedException;
import java.io.IOException;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class EXAWordCount {

/* To use this sample following steps are required:

1. Create EXASolution SQL Script for this mapper in EXASolution:
SQL_EXA> CREATE OR REPLACE EXTERNAL SCALAR SCRIPT wordCount(text VARCHAR(200000))
EMITS (word VARCHAR(200)) AS
# redirector tcp://192.168.1.1:4050
exasol.method = input
exasol.input.splits = 8
mapred.output.dir = /output/${database_name}/${session_id}/${statement_id}
mapreduce.job.jar = /usr/lib/hadoop/EXAhadoop.jar
mapreduce.job.name = wordcount
mapreduce.job.map.class = exasol.hadoop.EXAWordCount$EEMapper
mapreduce.job.inputformat.class = exasol.hadoop.EXAIOFormat$Input
mapreduce.job.input.key.class = exasol.hadoop.EXAIOFormat$Key
mapreduce.job.input.value.class = exasol.hadoop.EXAIOFormat$Value
mapreduce.job.outputformat.class = org.apache.hadoop.mapreduce.lib.output.NullOutputFormat
mapreduce.job.output.key.class = org.apache.hadoop.io.LongWritable
mapreduce.job.output.value.class = org.apache.hadoop.io.Text
mapreduce.job.maxtaskfailures.per.tracker = 0
mapreduce.job.maps = 8
mapreduce.map.maxattempts = 1
/

2. Compile and distribute EXAhadoop.jar in Hadoop, all Hadoop nodes
require access to this JAR. Installation Procedure is described in
README file of the EXASolution_eUDF package.

3. Start EXAManager on a node with access to Hadoop services:
$> hadoop jar EXAhadoop.jar exasol.hadoop.EXAManager tcp://192.168.1.1:4050

4. Start the Job from EXASolution:
SQL_EXA> SELECT COUNT(*) AS num FROM (
    SELECT wordCount(text)
    FROM sampletable
)
GROUP BY word
ORDER BY num;

*/

    public static class EEMapper extends Mapper<EXAIOFormat.Key, EXAIOFormat.Value, LongWritable, Text> {
        public void map(EXAIOFormat.Key key, EXAIOFormat.Value value, Context context) throws IOException, InterruptedException {
            for (;;) {
                String[] words = value.getString(0).split(" ");
                for (String word : words)
                    value.newResultRow().setString(word).emit();
                if (!value.readNextRow(false)) break;
            }
            value.flushResultRows();
        }
    }
}
