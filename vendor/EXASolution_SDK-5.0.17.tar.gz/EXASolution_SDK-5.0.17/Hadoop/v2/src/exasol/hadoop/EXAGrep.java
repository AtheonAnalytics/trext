package exasol.hadoop;

import java.lang.InterruptedException;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/* To use this sample following steps are required:

1. Create EXASolution SQL Script for this mapper in EXASolution:

SQL_EXA> CREATE OR REPLACE EXTERNAL SET SCRIPT grepLogs(expr VARCHAR(2000))
EMITS (word VARCHAR(2000)) AS
# redirector tcp://10.48.102.101:4050
exasol.method = output
mapred.input.dir = /user/hduser/texts/
mapreduce.job.jar = /usr/lib/hadoop/EXAhadoop.jar
mapreduce.job.name = greplogs

mapreduce.job.map.class = exasol.hadoop.EXAGrep$Mapper
mapreduce.job.input.key.class = org.apache.hadoop.io.LongWritable
mapreduce.job.input.value.class = org.apache.hadoop.io.Text
mapreduce.job.inputformat.class = org.apache.hadoop.mapreduce.lib.input.TextInputFormat
mapreduce.map.output.key.class = org.apache.hadoop.io.LongWritable
mapreduce.map.output.value.class = org.apache.hadoop.io.Text

mapreduce.job.reduce.class = exasol.hadoop.EXAGrep$Reducer
mapreduce.job.outputformat.class = exasol.hadoop.EXAIOFormat$Output
mapreduce.job.output.key.class = exasol.hadoop.EXAIOFormat$Key
mapreduce.job.output.value.class = exasol.hadoop.EXAIOFormat$Value

mapreduce.job.maxtaskfailures.per.tracker = 0
mapreduce.job.reduces = 8
mapreduce.reduce.maxattempts = 1
/

2. Compile and distribute EXAhadoop.jar in Hadoop, all Hadoop nodes
require access to this JAR. Installation Procedure is described in
README file of the EXASolution_eUDF package.

3. Start EXAManager on a node with access to Hadoop services:
$> hadoop jar EXAhadoop.jar exasol.hadoop.EXAManager tcp://192.168.1.1:4050

4. Create a table for input values, in this case only dummy numbers to
set the parallelization factor (produce right number of groups):
SQL_EXA> CREATE OR REPLACE TABLE parhint (par INT);
SQL_EXA> INSERT INTO parhint VALUES (0),(1),(2),(3),(4),(5),(6),(7);

4. Start the Job from EXASolution:
SQL_EXA> SELECT grepLogs('a.*b') FROM parhint GROUP BY par;

*/

public class EXAGrep {

    public static class Mapper extends org.apache.hadoop.mapreduce.Mapper<LongWritable, Text, LongWritable, Text> {
        private int kc = 0;
        private LongWritable[] lws = { new LongWritable(0), new LongWritable(1), new LongWritable(2),
                                       new LongWritable(3), new LongWritable(4), new LongWritable(5),
                                       new LongWritable(6), new LongWritable(7) };

        public void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
            context.write(lws[kc++ % 4], value);
        }
    }

    public static class Reducer extends org.apache.hadoop.mapreduce.Reducer<LongWritable, Text, EXAIOFormat.Key, EXAIOFormat.Value> {
        private EXAIOFormat.Key outKey;
        private EXAIOFormat.Value outValue;
        private Pattern pattern;

        public void setup(Context context) throws IOException, InterruptedException {
            outKey = new EXAIOFormat.Key(context.getConfiguration());
            outValue = outKey.getValue();
            pattern = Pattern.compile(outValue.getString(0));
        }

        public void reduce(LongWritable key, Iterable<Text> value,
                           Context context) throws IOException, InterruptedException {
            for (Text v : value) {
                String s = v.toString();
                Matcher match = pattern.matcher(s);
                if (match.find())              
                    outValue .newResultRow()
                             .setString(s)
                             .emit();
            }
            context.write(outKey, outValue);            
        }
        
        public void cleanup(Context context) throws IOException, InterruptedException {
            // read possibly unreaden groups and finish the EXASolution worker
            while (outKey.next());
        }
    }
}
