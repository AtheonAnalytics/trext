package exasol.hadoop;

import java.lang.InterruptedException;
import java.io.IOException;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;

public class EXAWordCount {

/* To use this sample following steps are required:

1. Create EXASolution SQL Script for this mapper in EXASolution:
SQL_EXA> CREATE OR REPLACE EXTERNAL SCALAR SCRIPT wordCount(text VARCHAR(200000))
EMITS (word VARCHAR(200)) AS
# redirector tcp://192.168.1.1:4050
mapred.jar = /usr/lib/hadoop/EXAhadoop.jar
exasol.method = input
mapred.job.name = wordcount

exasol.input.splits = 8
mapred.map.max.attempts = 1
mapred.map.tasks = 1

mapred.input.format.class = exasol.hadoop.EXAIOFormat$Input
mapred.input.key.class = exasol.hadoop.EXAIOFormat$Key
mapred.input.value.class = exasol.hadoop.EXAIOFormat$Value
mapred.mapper.class = exasol.hadoop.EXAWordCount$EEMapper
mapred.output.format.class = org.apache.hadoop.mapred.lib.NullOutputFormat
mapred.output.key.class = org.apache.hadoop.io.LongWritable
mapred.output.value.class = org.apache.hadoop.io.Text
/

2. Compile and distribute EXAhadoop.jar in Hadoop, all Hadoop nodes
require access to this JAR. Installation Procedure is described in
README file of the EXASolution_eUDF package.

3. Start EXAManager on a node with access to Hadoop services:
$> hadoop jar EXAhadoop.jar exasol.hadoop.EXAManager tcp://192.168.1.1:4050

4. Start the Job from EXASolution:
SQL_EXA> SELECT COUNT(*) AS num FROM (
    SELECT wordCount(text)
    FROM sampletable
)
GROUP BY word
ORDER BY num;

*/

    public static class EEMapper extends MapReduceBase implements Mapper<EXAIOFormat.Key, EXAIOFormat.Value, LongWritable, Text> {
        public void map(EXAIOFormat.Key key,
                        EXAIOFormat.Value value,
                        OutputCollector<LongWritable, Text> output,
                        Reporter reporter)
            throws IOException {
            for (;;) {
                String[] words = value.getString(0).split(" ");
                for (String word : words)
                    value.newResultRow().setString(word).emit();
                if (!value.readNextRow(false))
                    break;
                value.flushResultRows();
            }
        }
    }
}
