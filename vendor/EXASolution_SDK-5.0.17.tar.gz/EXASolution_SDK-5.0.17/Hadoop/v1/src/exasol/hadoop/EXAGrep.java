package exasol.hadoop;

import java.lang.InterruptedException;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Iterator;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;

/* To use this sample following steps are required:

1. Create EXASolution SQL Script for this mapper in EXASolution:

SQL_EXA> CREATE OR REPLACE EXTERNAL SET SCRIPT grepLogs(expr VARCHAR(2000))
EMITS (word VARCHAR(2000)) AS
# redirector tcp://192.168.1.1:4050
mapred.jar = /usr/lib/hadoop/EXAhadoop.jar
exasol.method = output
mapred.input.dir = /user/hduser/texts/
mapred.job.name = greplogs

mapred.map.max.attempts = 1
mapred.reduce.max.attempts = 1
mapred.reduce.tasks = 8

mapred.input.key.class = org.apache.hadoop.io.LongWritable
mapred.input.value.class = org.apache.hadoop.io.Text
mapred.mapoutput.key.class = org.apache.hadoop.io.LongWritable
mapred.mapoutput.value.class = org.apache.hadoop.io.Text
mapred.mapper.class = exasol.hadoop.EXAGrep$EEMapper
mapred.reducer.class = exasol.hadoop.EXAGrep$EEReducer
mapred.output.format.class = exasol.hadoop.EXAIOFormat$Output
mapred.output.key.class = exasol.hadoop.EXAIOFormat$Key
mapred.output.value.class = exasol.hadoop.EXAIOFormat$Value
/

2. Compile and distribute EXAhadoop.jar in Hadoop, all Hadoop nodes
require access to this JAR. Installation Procedure is described in
README file of the EXASolution_eUDF package.

3. Start EXAManager on a node with access to Hadoop services:
$> hadoop jar EXAhadoop.jar exasol.hadoop.EXAManager tcp://192.168.1.1:4050

4. Create a table for input values, in this case only dummy numbers to
set the parallelization factor (produce right number of groups):
SQL_EXA> CREATE OR REPLACE TABLE parhint (par INT);
SQL_EXA> INSERT INTO parhint VALUES (0),(1),(2),(3),(4),(5),(6),(7);

4. Start the Job from EXASolution:
SQL_EXA> SELECT grepLogs('a.*b') FROM parhint GROUP BY par;

*/

public class EXAGrep {

    public static class EEMapper
        extends MapReduceBase
        implements Mapper<LongWritable, Text, LongWritable, Text>
    {
        private int kc = 0;
        private LongWritable[] lws = { new LongWritable(0), new LongWritable(1), new LongWritable(2),
                                       new LongWritable(3), new LongWritable(4), new LongWritable(5),
                                       new LongWritable(6), new LongWritable(7) };

        public void map(LongWritable key, Text value,
                        OutputCollector<LongWritable, Text> output,
                        Reporter reporter) throws IOException {
            output.collect(lws[kc++ % 8], value);
        }
    }

    public static class EEReducer
        extends MapReduceBase
        implements Reducer<LongWritable, Text, EXAIOFormat.Key, EXAIOFormat.Value>
    {
        private EXAIOFormat.Key outKey;
        private EXAIOFormat.Value outValue;
        private Pattern pattern;
        private JobConf conf;

        public void configure(JobConf conf) {
            this.conf = conf;
        }

        public void reduce(LongWritable key, Iterator<Text> value,
                           OutputCollector<EXAIOFormat.Key, EXAIOFormat.Value> output,
                           Reporter reporter) throws IOException {
            if (outKey == null) {
                outKey = new EXAIOFormat.Key(conf);
                outValue = outKey.getValue();
                pattern = Pattern.compile(outValue.getString(0));
            }
            while (value.hasNext()) {
                String s = value.next().toString();
                Matcher match = pattern.matcher(s);
                if (match.find())
                    outValue .newResultRow()
                             .setString(s)
                             .emit();
            }
            output.collect(outKey, outValue);
        }

        public void close() {
            try { while (outKey.next()); }
            catch (Exception err) {
                System.err.printf("ERROR: Failed to finish EXAIOFormat.Output\n");
                err.printStackTrace();
            }
        }
    }
}
