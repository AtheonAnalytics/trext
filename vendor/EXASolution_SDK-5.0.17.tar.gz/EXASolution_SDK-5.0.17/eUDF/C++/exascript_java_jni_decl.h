#ifndef EXASCRIPT_JAVA_JNI_DECL_H
#define EXASCRIPT_JAVA_JNI_DECL_H

#ifdef __cplusplus
extern "C" {
#endif

jint JNICALL Java_exascript_1javaJNI_UNSUPPORTED_1get(JNIEnv *jenv, jclass jcls);
jint JNICALL Java_exascript_1javaJNI_DOUBLE_1get(JNIEnv *jenv, jclass jcls);
jint JNICALL Java_exascript_1javaJNI_INT32_1get(JNIEnv *jenv, jclass jcls);
jint JNICALL Java_exascript_1javaJNI_INT64_1get(JNIEnv *jenv, jclass jcls);
jint JNICALL Java_exascript_1javaJNI_NUMERIC_1get(JNIEnv *jenv, jclass jcls);
jint JNICALL Java_exascript_1javaJNI_TIMESTAMP_1get(JNIEnv *jenv, jclass jcls);
jint JNICALL Java_exascript_1javaJNI_DATE_1get(JNIEnv *jenv, jclass jcls);
jint JNICALL Java_exascript_1javaJNI_STRING_1get(JNIEnv *jenv, jclass jcls);
jint JNICALL Java_exascript_1javaJNI_BOOLEAN_1get(JNIEnv *jenv, jclass jcls);
jint JNICALL Java_exascript_1javaJNI_EXACTLY_1ONCE_1get(JNIEnv *jenv, jclass jcls);
jint JNICALL Java_exascript_1javaJNI_MULTIPLE_1get(JNIEnv *jenv, jclass jcls);

jlong JNICALL Java_exascript_1javaJNI_new_1Metadata(JNIEnv *jenv, jclass jcls);
jstring JNICALL Java_exascript_1javaJNI_Metadata_1databaseName(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jstring JNICALL Java_exascript_1javaJNI_Metadata_1databaseVersion(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jstring JNICALL Java_exascript_1javaJNI_Metadata_1scriptName(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jstring JNICALL Java_exascript_1javaJNI_Metadata_1scriptCode(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jstring JNICALL Java_exascript_1javaJNI_Metadata_1moduleContent(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jstring jarg2);
jobject JNICALL Java_exascript_1javaJNI_Metadata_1sessionID(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jstring JNICALL Java_exascript_1javaJNI_Metadata_1sessionID_1S(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jlong JNICALL Java_exascript_1javaJNI_Metadata_1statementID(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jlong JNICALL Java_exascript_1javaJNI_Metadata_1nodeCount(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jlong JNICALL Java_exascript_1javaJNI_Metadata_1nodeID(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jobject JNICALL Java_exascript_1javaJNI_Metadata_1vmID(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jstring JNICALL Java_exascript_1javaJNI_Metadata_1vmID_1S(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jobject JNICALL Java_exascript_1javaJNI_Metadata_1memoryLimit(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jlong JNICALL Java_exascript_1javaJNI_Metadata_1inputColumnCount(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jstring JNICALL Java_exascript_1javaJNI_Metadata_1inputColumnName(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jint JNICALL Java_exascript_1javaJNI_Metadata_1inputColumnType(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jstring JNICALL Java_exascript_1javaJNI_Metadata_1inputColumnTypeName(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jlong JNICALL Java_exascript_1javaJNI_Metadata_1inputColumnSize(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jlong JNICALL Java_exascript_1javaJNI_Metadata_1inputColumnPrecision(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jlong JNICALL Java_exascript_1javaJNI_Metadata_1inputColumnScale(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jint JNICALL Java_exascript_1javaJNI_Metadata_1inputType(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jlong JNICALL Java_exascript_1javaJNI_Metadata_1outputColumnCount(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jstring JNICALL Java_exascript_1javaJNI_Metadata_1outputColumnName(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jint JNICALL Java_exascript_1javaJNI_Metadata_1outputColumnType(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jstring JNICALL Java_exascript_1javaJNI_Metadata_1outputColumnTypeName(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jlong JNICALL Java_exascript_1javaJNI_Metadata_1outputColumnSize(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jlong JNICALL Java_exascript_1javaJNI_Metadata_1outputColumnPrecision(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jlong JNICALL Java_exascript_1javaJNI_Metadata_1outputColumnScale(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jint JNICALL Java_exascript_1javaJNI_Metadata_1outputType(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jstring JNICALL Java_exascript_1javaJNI_Metadata_1checkException(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
void JNICALL Java_exascript_1javaJNI_delete_1Metadata(JNIEnv *jenv, jclass jcls, jlong jarg1);

jlong JNICALL Java_exascript_1javaJNI_new_1TableIterator(JNIEnv *jenv, jclass jcls);
jstring JNICALL Java_exascript_1javaJNI_TableIterator_1checkException(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
void JNICALL Java_exascript_1javaJNI_TableIterator_1reinitialize(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jboolean JNICALL Java_exascript_1javaJNI_TableIterator_1next(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jboolean JNICALL Java_exascript_1javaJNI_TableIterator_1eot(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
void JNICALL Java_exascript_1javaJNI_TableIterator_1reset(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jlong JNICALL Java_exascript_1javaJNI_TableIterator_1restBufferSize(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jlong JNICALL Java_exascript_1javaJNI_TableIterator_1rowsInGroup(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jlong JNICALL Java_exascript_1javaJNI_TableIterator_1rowsCompleted(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jdouble JNICALL Java_exascript_1javaJNI_TableIterator_1getDouble(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jbyteArray JNICALL Java_exascript_1javaJNI_TableIterator_1getStringByteArray(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jint JNICALL Java_exascript_1javaJNI_TableIterator_1getInt32(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jlong JNICALL Java_exascript_1javaJNI_TableIterator_1getInt64(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jstring JNICALL Java_exascript_1javaJNI_TableIterator_1getNumeric(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jstring JNICALL Java_exascript_1javaJNI_TableIterator_1getDate(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jstring JNICALL Java_exascript_1javaJNI_TableIterator_1getTimestamp(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jboolean JNICALL Java_exascript_1javaJNI_TableIterator_1getBoolean(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
jboolean JNICALL Java_exascript_1javaJNI_TableIterator_1wasNull(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
void JNICALL Java_exascript_1javaJNI_delete_1TableIterator(JNIEnv *jenv, jclass jcls, jlong jarg1);

jlong JNICALL Java_exascript_1javaJNI_new_1ResultHandler(JNIEnv *jenv, jclass jcls);
jstring JNICALL Java_exascript_1javaJNI_ResultHandler_1checkException(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
void JNICALL Java_exascript_1javaJNI_ResultHandler_1reinitialize(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
jboolean JNICALL Java_exascript_1javaJNI_ResultHandler_1next(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
void JNICALL Java_exascript_1javaJNI_ResultHandler_1flush(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_);
void JNICALL Java_exascript_1javaJNI_ResultHandler_1setDouble(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2, jdouble jarg3);
void JNICALL Java_exascript_1javaJNI_ResultHandler_1setStringByteArray(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2, jbyteArray jarg3, jlong jarg4);
void JNICALL Java_exascript_1javaJNI_ResultHandler_1setInt32(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2, jint jarg3);
void JNICALL Java_exascript_1javaJNI_ResultHandler_1setInt64(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2, jlong jarg3);
void JNICALL Java_exascript_1javaJNI_ResultHandler_1setNumeric(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2, jstring jarg3);
void JNICALL Java_exascript_1javaJNI_ResultHandler_1setDate(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2, jstring jarg3);
void JNICALL Java_exascript_1javaJNI_ResultHandler_1setTimestamp(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2, jstring jarg3);
void JNICALL Java_exascript_1javaJNI_ResultHandler_1setBoolean(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2, jboolean jarg3);
void JNICALL Java_exascript_1javaJNI_ResultHandler_1setNull(JNIEnv *jenv, jclass jcls, jlong jarg1, jobject jarg1_, jlong jarg2);
void JNICALL Java_exascript_1javaJNI_delete_1ResultHandler(JNIEnv *jenv, jclass jcls, jlong jarg1);

JNINativeMethod methods[] = {
    {(char *)"UNSUPPORTED_get", (char *)"()I", (void *)&Java_exascript_1javaJNI_UNSUPPORTED_1get},
    {(char *)"DOUBLE_get", (char *)"()I", (void *)&Java_exascript_1javaJNI_DOUBLE_1get},
    {(char *)"INT32_get", (char *)"()I", (void *)&Java_exascript_1javaJNI_INT32_1get},
    {(char *)"INT64_get", (char *)"()I", (void *)&Java_exascript_1javaJNI_INT64_1get},
    {(char *)"NUMERIC_get", (char *)"()I", (void *)&Java_exascript_1javaJNI_NUMERIC_1get},
    {(char *)"TIMESTAMP_get", (char *)"()I", (void *)&Java_exascript_1javaJNI_TIMESTAMP_1get},
    {(char *)"DATE_get", (char *)"()I", (void *)&Java_exascript_1javaJNI_DATE_1get},
    {(char *)"STRING_get", (char *)"()I", (void *)&Java_exascript_1javaJNI_STRING_1get},
    {(char *)"BOOLEAN_get", (char *)"()I", (void *)&Java_exascript_1javaJNI_BOOLEAN_1get},
    {(char *)"EXACTLY_ONCE_get", (char *)"()I", (void *)&Java_exascript_1javaJNI_EXACTLY_1ONCE_1get},
    {(char *)"MULTIPLE_get", (char *)"()I", (void *)&Java_exascript_1javaJNI_MULTIPLE_1get},

    {(char *)"new_Metadata", (char *)"()J", (void *)&Java_exascript_1javaJNI_new_1Metadata},
    {(char *)"Metadata_databaseName", (char *)"(JLMetadata;)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_Metadata_1databaseName},
    {(char *)"Metadata_databaseVersion", (char *)"(JLMetadata;)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_Metadata_1databaseVersion},
    {(char *)"Metadata_scriptName", (char *)"(JLMetadata;)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_Metadata_1scriptName},
    {(char *)"Metadata_scriptCode", (char *)"(JLMetadata;)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_Metadata_1scriptCode},
    {(char *)"Metadata_moduleContent", (char *)"(JLMetadata;Ljava/lang/String;)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_Metadata_1moduleContent},
    {(char *)"Metadata_sessionID", (char *)"(JLMetadata;)Ljava/math/BigInteger;", (void *)&Java_exascript_1javaJNI_Metadata_1sessionID},
    {(char *)"Metadata_sessionID_S", (char *)"(JLMetadata;)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_Metadata_1sessionID_1S},
    {(char *)"Metadata_statementID", (char *)"(JLMetadata;)J", (void *)&Java_exascript_1javaJNI_Metadata_1statementID},
    {(char *)"Metadata_nodeCount", (char *)"(JLMetadata;)J", (void *)&Java_exascript_1javaJNI_Metadata_1nodeCount},
    {(char *)"Metadata_nodeID", (char *)"(JLMetadata;)J", (void *)&Java_exascript_1javaJNI_Metadata_1nodeID},
    {(char *)"Metadata_vmID", (char *)"(JLMetadata;)Ljava/math/BigInteger;", (void *)&Java_exascript_1javaJNI_Metadata_1vmID},
    {(char *)"Metadata_vmID_S", (char *)"(JLMetadata;)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_Metadata_1vmID_1S},
    {(char *)"Metadata_memoryLimit", (char *)"(JLMetadata;)Ljava/math/BigInteger;", (void *)&Java_exascript_1javaJNI_Metadata_1memoryLimit},
    {(char *)"Metadata_inputColumnCount", (char *)"(JLMetadata;)J", (void *)&Java_exascript_1javaJNI_Metadata_1inputColumnCount},
    {(char *)"Metadata_inputColumnName", (char *)"(JLMetadata;J)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_Metadata_1inputColumnName},
    {(char *)"Metadata_inputColumnType", (char *)"(JLMetadata;J)I", (void *)&Java_exascript_1javaJNI_Metadata_1inputColumnType},
    {(char *)"Metadata_inputColumnTypeName", (char *)"(JLMetadata;J)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_Metadata_1inputColumnTypeName},
    {(char *)"Metadata_inputColumnSize", (char *)"(JLMetadata;J)J", (void *)&Java_exascript_1javaJNI_Metadata_1inputColumnSize},
    {(char *)"Metadata_inputColumnPrecision", (char *)"(JLMetadata;J)J", (void *)&Java_exascript_1javaJNI_Metadata_1inputColumnPrecision},
    {(char *)"Metadata_inputColumnScale", (char *)"(JLMetadata;J)J", (void *)&Java_exascript_1javaJNI_Metadata_1inputColumnScale},
    {(char *)"Metadata_inputType", (char *)"(JLMetadata;)I", (void *)&Java_exascript_1javaJNI_Metadata_1inputType},
    {(char *)"Metadata_outputColumnCount", (char *)"(JLMetadata;)J", (void *)&Java_exascript_1javaJNI_Metadata_1outputColumnCount},
    {(char *)"Metadata_outputColumnName", (char *)"(JLMetadata;J)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_Metadata_1outputColumnName},
    {(char *)"Metadata_outputColumnType", (char *)"(JLMetadata;J)I", (void *)&Java_exascript_1javaJNI_Metadata_1outputColumnType},
    {(char *)"Metadata_outputColumnTypeName", (char *)"(JLMetadata;J)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_Metadata_1outputColumnTypeName},
    {(char *)"Metadata_outputColumnSize", (char *)"(JLMetadata;J)J", (void *)&Java_exascript_1javaJNI_Metadata_1outputColumnSize},
    {(char *)"Metadata_outputColumnPrecision", (char *)"(JLMetadata;J)J", (void *)&Java_exascript_1javaJNI_Metadata_1outputColumnPrecision},
    {(char *)"Metadata_outputColumnScale", (char *)"(JLMetadata;J)J", (void *)&Java_exascript_1javaJNI_Metadata_1outputColumnScale},
    {(char *)"Metadata_outputType", (char *)"(JLMetadata;)I", (void *)&Java_exascript_1javaJNI_Metadata_1outputType},
    {(char *)"Metadata_checkException", (char *)"(JLMetadata;)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_Metadata_1checkException},
    {(char *)"delete_Metadata", (char *)"(J)V", (void *)&JNICALL Java_exascript_1javaJNI_delete_1Metadata},

    {(char *)"new_TableIterator", (char *)"()J", (void *)&Java_exascript_1javaJNI_new_1TableIterator},
    {(char *)"TableIterator_checkException", (char *)"(JLTableIterator;)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_TableIterator_1checkException},
    {(char *)"TableIterator_reinitialize", (char *)"(JLTableIterator;)V", (void *)&Java_exascript_1javaJNI_TableIterator_1reinitialize},
    {(char *)"TableIterator_next", (char *)"(JLTableIterator;)Z", (void *)&Java_exascript_1javaJNI_TableIterator_1next},
    {(char *)"TableIterator_eot", (char *)"(JLTableIterator;)Z", (void *)&Java_exascript_1javaJNI_TableIterator_1eot},
    {(char *)"TableIterator_reset", (char *)"(JLTableIterator;)V", (void *)&Java_exascript_1javaJNI_TableIterator_1reset},
    {(char *)"TableIterator_restBufferSize", (char *)"(JLTableIterator;)J", (void *)&Java_exascript_1javaJNI_TableIterator_1restBufferSize},
    {(char *)"TableIterator_rowsInGroup", (char *)"(JLTableIterator;)J", (void *)&Java_exascript_1javaJNI_TableIterator_1rowsInGroup},
    {(char *)"TableIterator_rowsCompleted", (char *)"(JLTableIterator;)J", (void *)&Java_exascript_1javaJNI_TableIterator_1rowsCompleted},
    {(char *)"TableIterator_getDouble", (char *)"(JLTableIterator;J)D", (void *)&Java_exascript_1javaJNI_TableIterator_1getDouble},
    {(char *)"TableIterator_getStringByteArray", (char *)"(JLTableIterator;J)[B", (void *)&Java_exascript_1javaJNI_TableIterator_1getStringByteArray},
    {(char *)"TableIterator_getInt32", (char *)"(JLTableIterator;J)I", (void *)&Java_exascript_1javaJNI_TableIterator_1getInt32},
    {(char *)"TableIterator_getInt64", (char *)"(JLTableIterator;J)J", (void *)&Java_exascript_1javaJNI_TableIterator_1getInt64},
    {(char *)"TableIterator_getNumeric", (char *)"(JLTableIterator;J)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_TableIterator_1getNumeric},
    {(char *)"TableIterator_getDate", (char *)"(JLTableIterator;J)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_TableIterator_1getDate},
    {(char *)"TableIterator_getTimestamp", (char *)"(JLTableIterator;J)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_TableIterator_1getTimestamp},
    {(char *)"TableIterator_getBoolean", (char *)"(JLTableIterator;J)Z", (void *)&Java_exascript_1javaJNI_TableIterator_1getBoolean},
    {(char *)"TableIterator_wasNull", (char *)"(JLTableIterator;)Z", (void *)&Java_exascript_1javaJNI_TableIterator_1wasNull},
    {(char *)"delete_TableIterator", (char *)"(J)V", (void *)&Java_exascript_1javaJNI_delete_1TableIterator},

    {(char *)"new_ResultHandler", (char *)"()J", (void *)&Java_exascript_1javaJNI_new_1ResultHandler},
    {(char *)"ResultHandler_checkException", (char *)"(JLResultHandler;)Ljava/lang/String;", (void *)&Java_exascript_1javaJNI_ResultHandler_1checkException},
    {(char *)"ResultHandler_reinitialize", (char *)"(JLResultHandler;)V", (void *)&Java_exascript_1javaJNI_ResultHandler_1reinitialize},
    {(char *)"ResultHandler_next", (char *)"(JLResultHandler;)Z", (void *)&Java_exascript_1javaJNI_ResultHandler_1next},
    {(char *)"ResultHandler_flush", (char *)"(JLResultHandler;)V", (void *)&Java_exascript_1javaJNI_ResultHandler_1flush},
    {(char *)"ResultHandler_setDouble", (char *)"(JLResultHandler;JD)V", (void *)&Java_exascript_1javaJNI_ResultHandler_1setDouble},
    {(char *)"ResultHandler_setStringByteArray", (char *)"(JLResultHandler;J[BJ)V", (void *)&Java_exascript_1javaJNI_ResultHandler_1setStringByteArray},
    {(char *)"ResultHandler_setInt32", (char *)"(JLResultHandler;JI)V", (void *)&Java_exascript_1javaJNI_ResultHandler_1setInt32},
    {(char *)"ResultHandler_setInt64", (char *)"(JLResultHandler;JJ)V", (void *)&Java_exascript_1javaJNI_ResultHandler_1setInt64},
    {(char *)"ResultHandler_setNumeric", (char *)"(JLResultHandler;JLjava/lang/String;)V", (void *)&Java_exascript_1javaJNI_ResultHandler_1setNumeric},
    {(char *)"ResultHandler_setDate", (char *)"(JLResultHandler;JLjava/lang/String;)V", (void *)&Java_exascript_1javaJNI_ResultHandler_1setDate},
    {(char *)"ResultHandler_setTimestamp", (char *)"(JLResultHandler;JLjava/lang/String;)V", (void *)&Java_exascript_1javaJNI_ResultHandler_1setTimestamp},
    {(char *)"ResultHandler_setBoolean", (char *)"(JLResultHandler;JZ)V", (void *)&Java_exascript_1javaJNI_ResultHandler_1setBoolean},
    {(char *)"ResultHandler_setNull", (char *)"(JLResultHandler;J)V", (void *)&Java_exascript_1javaJNI_ResultHandler_1setNull},
    {(char *)"delete_ResultHandler", (char *)"(J)V", (void *)&Java_exascript_1javaJNI_delete_1ResultHandler}
};

#ifdef __cplusplus
}
#endif

#endif
