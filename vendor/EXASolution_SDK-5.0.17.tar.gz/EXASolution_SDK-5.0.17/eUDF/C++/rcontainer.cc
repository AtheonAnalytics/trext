#include <swigcontainers_ext.h>
#include <R.h>
#include <Rdefines.h>
#include <Rembedded.h>
#include <Rinterface.h>
#include <R_ext/Parse.h>
#include <R_ext/Rdynload.h>
#include <R_ext/Boolean.h>
#include <exascript_r.h>
#include <exascript_r_int.h>

using namespace SWIGVMContainers;
using namespace std;

extern "C" void R_init_exascript_r(void *dll);

class SWIGVMContainers::RVMImpl {
public:
    RVMImpl(bool checkOnly);
    ~RVMImpl();
    bool run();

private:
    bool m_checkOnly;
};

RVM::RVM(bool checkOnly): m_impl(new RVMImpl(checkOnly)) { }
RVM::~RVM() { delete m_impl; }
bool RVM::run() { return m_impl->run(); }

static void evaluate_code(const char *code) {
    SEXP cmdSexp, cmdexpr;
    ParseStatus status;
    PROTECT(cmdSexp = allocVector(STRSXP, 1));
    SET_STRING_ELT(cmdSexp, 0, mkChar(code));
    cmdexpr = PROTECT(R_ParseVector(cmdSexp, -1, &status, R_NilValue));
    if (status != PARSE_OK) {
        UNPROTECT(2);
        throw RVM::exception("Failed to parse code");
    }
    for (R_len_t i = 0; i < length(cmdexpr); i++) {
        int errorOccurred;
        R_tryEvalSilent(VECTOR_ELT(cmdexpr, i), R_GlobalEnv, &errorOccurred);
        if (errorOccurred) {
            UNPROTECT(2);
            const char *buf = R_curErrorBuf();
            throw RVM::exception(buf);
        }
    }
    UNPROTECT(2);
}

static void evaluate_code_protected(const char *code) {
    SEXP expr, cmd, fun;
    int errorOccurred;
    PROTECT(fun = findFun(install("INTERNAL_PARSE_WRAPPER__"), R_GlobalEnv));
    PROTECT(expr = allocVector(LANGSXP, 2));
    PROTECT(cmd = allocVector(STRSXP, 1));
    SET_STRING_ELT(cmd, 0, mkChar(code));
    SETCAR(expr, fun);
    SETCADR(expr, cmd);
    R_tryEvalSilent(expr, R_GlobalEnv, &errorOccurred);
    UNPROTECT(3);
    if (errorOccurred)
        throw RVM::exception(R_curErrorBuf());
}

#define RVM_next_block_gen(type, vtype, rtype, var, value, null)  \
static void RVM_next_block_set_##type(SWIGTableIterator *data, SEXP &col, int c, unsigned long r) { \
    vtype var = data->get##type(c); \
    rtype (col)[r] = data->wasNull() ? null : value;       \
}
RVM_next_block_gen(Int32, int32_t, INTEGER, t, t, NA_INTEGER)
RVM_next_block_gen(Int64, double, REAL, t, double(t), NA_REAL)
RVM_next_block_gen(Double, double, REAL, t, t, NA_REAL)
RVM_next_block_gen(Numeric, const char*, REAL, t, ::atof(t), NA_REAL)
RVM_next_block_gen(Boolean, bool, LOGICAL, t, int(t), NA_LOGICAL)
#undef RVM_next_block_gen

#define RVM_next_block_gen(type) \
static void RVM_next_block_set_##type(SWIGTableIterator *data, SEXP &col, int c, unsigned long r) { \
    const char *t = data->get##type(c);                                       \
    if (!data->wasNull()) SET_STRING_ELT(col, r, mkChar(t)); \
    else SET_STRING_ELT(col, r, NA_STRING); \
}
RVM_next_block_gen(String)
RVM_next_block_gen(Date)
RVM_next_block_gen(Timestamp)
#undef RVM_next_block_gen

typedef void (*r_set_fun_t)(SWIGTableIterator *, SEXP &, int, unsigned long);

static void RVM_emit_block_set_Int32(SWIGResultHandler *data, SEXP &col, long c, long r)
{ if (INTEGER(col)[r] == NA_INTEGER) data->setNull(c); else data->setInt32(c, INTEGER(col)[r]); }
static void RVM_emit_block_set_Int64(SWIGResultHandler *data, SEXP &col, long c, long r)
{
    if (REAL(col)[r] == NA_REAL || ISNAN(REAL(col)[r]) || !R_FINITE(REAL(col)[r]))
        data->setNull(c);
    else data->setInt64(c, (int64_t)REAL(col)[r]);
}
static void RVM_emit_block_set_Double(SWIGResultHandler *data, SEXP &col, long c, long r)
{
    if (REAL(col)[r] == NA_REAL || ISNAN(REAL(col)[r]) || !R_FINITE(REAL(col)[r]))
        data->setNull(c);
    else data->setDouble(c, REAL(col)[r]);
}
static void RVM_emit_block_set_Boolean(SWIGResultHandler *data, SEXP &col, long c, long r)
{ if (LOGICAL(col)[r] == NA_LOGICAL) data->setNull(c); else data->setBoolean(c, LOGICAL(col)[r]); }
static void RVM_emit_block_set_Numeric(SWIGResultHandler *data, SEXP &col, long c, long r)
{ if (STRING_ELT(col, r) == NA_STRING) data->setNull(c); else data->setNumeric(c, CHAR(STRING_ELT(col, r))); }
static void RVM_emit_block_set_Date(SWIGResultHandler *data, SEXP &col, long c, long r)
{ if (STRING_ELT(col, r) == NA_STRING) data->setNull(c); else data->setDate(c, CHAR(STRING_ELT(col, r))); }
static void RVM_emit_block_set_Timestamp(SWIGResultHandler *data, SEXP &col, long c, long r)
{ if (STRING_ELT(col, r) == NA_STRING) data->setNull(c); else data->setTimestamp(c, CHAR(STRING_ELT(col, r))); }
static void RVM_emit_block_set_String(SWIGResultHandler *data, SEXP &col, long c, long r)
{
    if (STRING_ELT(col, r) == NA_STRING) data->setNull(c);
    else {
        const std::string s(CHAR(STRING_ELT(col, r)));
        data->setString(c, s.c_str(), s.size());
    }
}

extern "C" {
    SEXP RVM_next_block(SEXP dataexp, SEXP rowstofetch, SEXP buffer, SEXP buffersize) {
        SWIGTableIterator *data = static_cast<SWIGTableIterator*>(R_ExternalPtrAddr(dataexp));
        std::vector<std::string> &colnames = *(SWIGVM_params->inp_names);
        std::vector<SWIGVM_columntype_t> &coltypes = *(SWIGVM_params->inp_types);
        long cols_count = colnames.size();
        long rows = data->rowsInGroup() - data->rowsCompleted() + 1;
        long rowsalloc = rows;
        unsigned long currow = 0;
        SEXP cols[cols_count], ret = NULL, retnames;
        r_set_fun_t setfs[cols_count];
        bool ret_is_buffer = false;
        
        if (INTEGER(rowstofetch)[0] != NA_INTEGER) {
            if (INTEGER(rowstofetch)[0] < 0)
                rowsalloc = rows = 1;
            else if (INTEGER(rowstofetch)[0] < rows)
                rowsalloc = rows = INTEGER(rowstofetch)[0];
        }
        if (rowsalloc == 0)
            rowsalloc = 1;

        if (data->eot())
            return R_NilValue;

        if (INTEGER(buffersize)[0] == rowsalloc) {
            ret = buffer;
            ret_is_buffer = true;
            for (long c = 0; c < cols_count; ++c)
                cols[c] = VECTOR_ELT(buffer, c);
        }

        for (long c = 0; c < cols_count; ++c) {
            switch (coltypes[c].type) {
            case INT32:
                setfs[c] = &RVM_next_block_set_Int32;
                if (!ret_is_buffer) PROTECT(cols[c] = NEW_INTEGER(rowsalloc));
                break;
            case DOUBLE:
                setfs[c] = &RVM_next_block_set_Double;
                if (!ret_is_buffer) PROTECT(cols[c] = NEW_NUMERIC(rowsalloc));
                break;
            case INT64:
                setfs[c] = &RVM_next_block_set_Int64;
                if (!ret_is_buffer) PROTECT(cols[c] = NEW_NUMERIC(rowsalloc));
                break;
            case NUMERIC:
                setfs[c] = &RVM_next_block_set_Numeric;
                if (!ret_is_buffer) PROTECT(cols[c] = NEW_NUMERIC(rowsalloc));
                break;
            case STRING:
                setfs[c] = &RVM_next_block_set_String;
                if (!ret_is_buffer) PROTECT(cols[c] = NEW_CHARACTER(rowsalloc));
                break;
            case DATE:
                setfs[c] = &RVM_next_block_set_Date;
                if (!ret_is_buffer) PROTECT(cols[c] = NEW_CHARACTER(rowsalloc));
                break;
            case TIMESTAMP:
                setfs[c] = &RVM_next_block_set_Timestamp;
                if (!ret_is_buffer) PROTECT(cols[c] = NEW_CHARACTER(rowsalloc));
                break;
            case BOOLEAN:
                setfs[c] = &RVM_next_block_set_Boolean;
                if (!ret_is_buffer) PROTECT(cols[c] = NEW_LOGICAL(rowsalloc));
                break;
            default:
                SWIGVM_params->exch->setException("Internal error: wrong column type");
                break;
            }
        }

        if (rows > 0) {
            do {
                for (long c = 0; c < cols_count; ++c)
                    setfs[c](data, cols[c], c, currow);
                if (SWIGVM_params->exch->exthrowed) break;
                ++currow;
                if (!data->next()) break;
            } while(currow < (unsigned long)rows);
            if (!SWIGVM_params->exch->exthrowed && currow != (unsigned long)rows)
                SWIGVM_params->exch->setException("Could not read all rows");
        } else if (rows == 0) {
            for (long c = 0; c < cols_count; ++c)
                setfs[c](data, cols[c], c, currow);
        }

        if (!ret_is_buffer) {
            PROTECT(retnames = allocVector(STRSXP, cols_count));
            PROTECT(ret = allocVector(VECSXP, cols_count));
            for (long c = 0; c < cols_count; ++c) {
                SET_STRING_ELT(retnames, c, mkChar(colnames[c].c_str()));
                SET_VECTOR_ELT(ret, c, cols[c]);
            }
            setAttrib(ret, R_NamesSymbol, retnames);
            UNPROTECT(cols_count + 2);
        }
        return ret;
    }

    SEXP RVM_emit_block(SEXP dataexp, SEXP datain) {
        SWIGResultHandler *data = static_cast<SWIGResultHandler*>(R_ExternalPtrAddr(dataexp));
        std::vector<SWIGVM_columntype_t> &coltypes = *(SWIGVM_params->out_types);
        long cols_count = coltypes.size();
        long emiting_rows = 0;
        struct {
            SEXP dat;
            long len;
            void (*fun)(SWIGResultHandler* data, SEXP &inp, long c, long r);
        } setfs[cols_count];

        if (datain == R_NilValue || isNull(datain) || !IS_LIST(datain) || LENGTH(datain) != cols_count) {
            if (datain != R_NilValue && IS_LIST(datain)) {
                stringstream sb;
                sb << "emit function argument count (" << LENGTH(datain)
                   << ") must match the number of output columns (" << cols_count << ')';
                SWIGVM_params->exch->setException(sb.str().c_str());
            } else
                SWIGVM_params->exch->setException("emit function argument count must match the number of output columns");
            return R_NilValue;
        }
        for (long c = 0; c < cols_count; ++c) {
            setfs[c].dat = VECTOR_ELT(datain, c);
            if (isNull(setfs[c].dat)) {
                SWIGVM_params->exch->setException("emitting NULL values not supported");
                return R_NilValue;
            }   
            setfs[c].len = GET_LENGTH(setfs[c].dat);
            if (setfs[c].len < 1) {
                SWIGVM_params->exch->setException("emitting empty vectors not supported");
                return R_NilValue;
            }   
            if (emiting_rows < setfs[c].len)
                emiting_rows = setfs[c].len;
            switch (coltypes[c].type) {
            case INT32     : setfs[c].fun = &RVM_emit_block_set_Int32;     break;
            case INT64     : setfs[c].fun = &RVM_emit_block_set_Int64;     break;
            case DOUBLE    : setfs[c].fun = &RVM_emit_block_set_Double;    break;
            case NUMERIC   : setfs[c].fun = &RVM_emit_block_set_Numeric;   break;
            case DATE      : setfs[c].fun = &RVM_emit_block_set_Date;      break;
            case TIMESTAMP : setfs[c].fun = &RVM_emit_block_set_Timestamp; break;
            case STRING    : setfs[c].fun = &RVM_emit_block_set_String;    break;
            case BOOLEAN   : setfs[c].fun = &RVM_emit_block_set_Boolean;   break;
            default:
                SWIGVM_params->exch->setException("Internal error: wrong column type");
                break;
            }
        }
        for (long r = 0; r < emiting_rows; ++r) {
            for (long c = 0; c < cols_count; ++c)
                setfs[c].fun(data, setfs[c].dat, c, r % setfs[c].len);
            data->next();
        }
        return R_NilValue;
    }
}

RVMImpl::RVMImpl(bool checkOnly): m_checkOnly(checkOnly) {
    char const *argv[] = {"Rcontainer", "--gui=none", "--silent", "--no-save", "--slave"};
    int argc = 5;
    DllInfo *info = R_getEmbeddingDllInfo();

    setenv("R_HOME", RT_ROOT_DIRECTORY "/lib64/R", 1);
    Rf_initEmbeddedR(argc, const_cast<char**>(argv));
    R_Interactive = (Rboolean)0; /* 0 has problems with Exceptions -> needs options(error = ...) ? */
    R_init_exascript_r(info);

    evaluate_code(integrated_exascript_r_r);
    evaluate_code(integrated_exascript_r_preset_r);
    evaluate_code_protected(SWIGVM_params->script_code);
    evaluate_code(integrated_exascript_r_wrap_r);
}

RVMImpl::~RVMImpl() {
    SEXP fun, expr;
    int errorOccurred;
    PROTECT(fun = findFun(install("INTERNAL_CLEANUP_WRAPPER__"), R_GlobalEnv));
    PROTECT(expr = allocVector(LANGSXP, 1));
    SETCAR(expr, fun);
    R_tryEvalSilent(expr, R_GlobalEnv, &errorOccurred);
    if (errorOccurred)
        throw RVM::exception(R_curErrorBuf());
    Rf_endEmbeddedR(0);
    R_CleanTempDir();
}

bool RVMImpl::run() {
    SEXP fun, expr;
    int errorOccurred;

    PROTECT(fun = findFun(install("INTERNAL_RUN_WRAPPER__"), R_GlobalEnv));
    PROTECT(expr = allocVector(LANGSXP, 1));
    SETCAR(expr, fun);
    R_tryEvalSilent(expr, R_GlobalEnv, &errorOccurred);
    UNPROTECT(2);
    if (errorOccurred)
        throw RVM::exception(R_curErrorBuf());
    return true;
}
