#include <swigcontainers_ext.h>
#include <iostream>
#ifdef _POSIX_C_SOURCE
#undef _POSIX_C_SOURCE
#endif
#ifdef _XOPEN_SOURCE
#undef _XOPEN_SOURCE
#endif
#include <Python.h>
#include <exascript_python.h>
#include <exascript_python_int.h>

#define DISABLE_PYTHON_SUBINTERP

using namespace SWIGVMContainers;
using namespace std;

extern "C" void init_exascript_python(void);

static void check() {
    PyObject *pt, *pv, *tb, *s = NULL, *pvc, *pvcn;
    string pvcns("");
    if (PyErr_Occurred() == NULL) return;
    PyErr_Fetch(&pt, &pv, &tb); if (pt == NULL) return;
    PyErr_NormalizeException(&pt, &pv, &tb); if (pt == NULL) return;
    s = PyObject_Str(pv);
    if (NULL != (pvc = PyObject_GetAttrString(pv, "__class__"))) {
        if (NULL != (pvcn = PyObject_GetAttrString(pvc, "__name__"))) {
            pvcns = string(PyString_AS_STRING(pvcn)) + string(": ");
            Py_XDECREF(pvcn);
        }
        Py_XDECREF(pvc);
    }
    PythonVM::exception x((pvcns + PyString_AS_STRING(s)).c_str());
    Py_XDECREF(s);
    PyErr_Clear();
    throw x;
}

class SWIGVMContainers::PythonVMImpl {
    public:
        PythonVMImpl(bool checkOnly);
        ~PythonVMImpl();
        bool run();

    private:
        string script_code;
        bool m_checkOnly;
        PyObject *globals, *code, *script;
        PyObject *exatable, *runobj, *cleanobj;
        PyObject *retvalue;
#ifndef DISABLE_PYTHON_SUBINTERP
        PyThreadState *pythread;
        static PyThreadState *main_thread;
#endif
};

#ifndef DISABLE_PYTHON_SUBINTERP
class PythonThreadBlock {
    PyGILState_STATE state;
    PyThreadState *save;
    public:
        PythonThreadBlock(): state(PyGILState_Ensure()), save(PyThreadState_Get()) {}
        ~PythonThreadBlock() { PyThreadState_Swap(save); PyGILState_Release(state); }
};
#endif

PythonVM::PythonVM(bool checkOnly): m_impl(new PythonVMImpl(checkOnly)) { }
PythonVM::~PythonVM() { delete m_impl; }
bool PythonVM::run() { return m_impl->run(); }

#ifndef DISABLE_PYTHON_SUBINTERP
PyThreadState *PythonVMImpl::main_thread = NULL;
#endif

PythonVMImpl::PythonVMImpl(bool checkOnly): m_checkOnly(checkOnly)
{
    script_code = string("\xEF\xBB\xBF") + string(SWIGVM_params->script_code);
    script = exatable = globals = retvalue = NULL;
#ifndef DISABLE_PYTHON_SUBINTERP
    pythread = NULL;
#endif

    if (!Py_IsInitialized()) {
        ::setlocale(LC_ALL, "en_US.utf8");
        Py_NoSiteFlag = 1;
        Py_Initialize();
        PyEval_InitThreads();
#ifndef DISABLE_PYTHON_SUBINTERP
        main_thread = PyEval_SaveThread();
#endif
    }

    {   
#ifndef DISABLE_PYTHON_SUBINTERP
        PythonThreadBlock block;
#endif
        
        script = Py_CompileString(script_code.c_str(), SWIGVM_params->script_name, Py_file_input); check();
        if (script == NULL) throw PythonVM::exception("Failed to compile script");

#ifndef DISABLE_PYTHON_SUBINTERP
        pythread = PyThreadState_New(main_thread->interp);
        if (pythread == NULL)
            throw PythonVM::exception("Failed to create Python interpreter");
#endif
    }

    if (!checkOnly) {
#ifndef DISABLE_PYTHON_SUBINTERP
        PythonThreadBlock block;
        PyThreadState_Swap(pythread);
#endif

        globals = PyDict_New();
        PyDict_SetItemString(globals, "__builtins__", PyEval_GetBuiltins());
        init_exascript_python();

        code = Py_CompileString(integrated_exascript_python_py, "exascript_python.py", Py_file_input); check();
        if (code == NULL) throw PythonVM::exception("Failed to compile internal module");
        exatable = PyImport_ExecCodeModule((char*)"exascript_python", code); check();

        code = Py_CompileString(integrated_exascript_python_preset_py, "<EXASCRIPTPP>", Py_file_input); check();
        if (code == NULL) throw PythonVM::exception("Failed to compile preset script");
        PyEval_EvalCode(reinterpret_cast<PyCodeObject*>(code), globals, globals); check();
        Py_DECREF(code);

        //PyEval_EvalCode(reinterpret_cast<PyCodeObject*>(script), globals, globals); check();
        PyObject *runobj = PyDict_GetItemString(globals, "__pythonvm_wrapped_parse"); check();
        PyObject *retvalue = PyObject_CallFunction(runobj, NULL); check();
        Py_XDECREF(retvalue); retvalue = NULL;

        code = Py_CompileString(integrated_exascript_python_wrap_py, "<EXASCRIPT>", Py_file_input); check();
        if (code == NULL) throw PythonVM::exception("Failed to compile wrapping script");
        PyEval_EvalCode(reinterpret_cast<PyCodeObject*>(code), globals, globals); check();
        Py_XDECREF(code);
    }
}

PythonVMImpl::~PythonVMImpl() {
    {   
#ifndef DISABLE_PYTHON_SUBINTERP
        PythonThreadBlock block;
        if (pythread != NULL)
            PyThreadState_Swap(pythread);
#endif

        Py_XDECREF(retvalue);
        if (!m_checkOnly) {
            cleanobj = PyDict_GetItemString(globals, "cleanup");
            if (cleanobj) {
                retvalue = PyObject_CallObject(cleanobj, NULL);
                check();
            }
        }
        Py_XDECREF(script);
        Py_XDECREF(exatable);
        Py_XDECREF(globals);
    }
}

bool PythonVMImpl::run() {
    if (m_checkOnly) throw PythonVM::exception("Python VM in check only mode");

    {   
#ifndef DISABLE_PYTHON_SUBINTERP
        PythonThreadBlock block;
        PyThreadState_Swap(pythread);
#endif
        runobj = PyDict_GetItemString(globals, "__pythonvm_wrapped_run"); check();
        retvalue = PyObject_CallFunction(runobj, NULL); check();
        Py_XDECREF(retvalue); retvalue = NULL;
    }
    return true;
}
