#include <iostream>
#include <dirent.h>
#include <sys/stat.h>
#include <openssl/md5.h>
#include <set>
#include <jni.h>
#include <swigcontainers_ext.h>
#include <exascript_java_jni_decl.h>

using namespace SWIGVMContainers;
using namespace std;

class SWIGVMContainers::JavaVMImpl {
    public:
        JavaVMImpl(bool checkOnly);
        ~JavaVMImpl();
        bool run();

    private:
        void createJvm();
        void compileScript();
        void check();
        void registerFunctions();
        void setClasspath();
        void cleanupClasspath();
        void throwException(const char *message);
        void importScripts();
        void addExternalJarPaths();
        void getExternalJvmOptions();
        void setJvmOptions();
        void addJarToClasspath(const string& path);
        vector<unsigned char> scriptToMd5(const char *script);
        string getOptionLine(const string option, const string whitespace, const string lineEnd, size_t& pos);
        bool m_checkOnly;
        string m_exaJavaPath;
        string m_testJavaPath;
        string m_scriptCode;
        string m_tmpClasspath;
        string m_exaJarPath;
        string m_classpath;
        set<string> m_jarPaths;
        set< vector<unsigned char> > m_importedScriptChecksums;
        bool m_exceptionThrown;
        vector<string> m_jvmOptions;
        JavaVM *m_jvm;
        JNIEnv *m_env;
};

JavaVMach::JavaVMach(bool checkOnly): m_impl(new JavaVMImpl(checkOnly)) {
}

JavaVMach::~JavaVMach() {
    delete m_impl;
}

bool JavaVMach::run() {
    return m_impl->run();
}

JavaVMImpl::JavaVMImpl(bool checkOnly): m_checkOnly(checkOnly), m_exaJavaPath("/home/exasolution/java"), m_scriptCode(SWIGVM_params->script_code), m_exceptionThrown(false), m_jvm(NULL), m_env(NULL) {
    char *tmpPath = getenv("JAVA_TMP_DIR");
    m_testJavaPath = (!tmpPath || strcmp(tmpPath, "/") == 0) ? "" : tmpPath;
    setClasspath();
    importScripts();
    addExternalJarPaths();
    getExternalJvmOptions();
    setJvmOptions();
    createJvm();
    registerFunctions();
    compileScript();
}

JavaVMImpl::~JavaVMImpl() {
    try {
        m_jvm->DestroyJavaVM();
        cleanupClasspath();
    } catch(...) { }
}

bool JavaVMImpl::run() {
    if (m_checkOnly)
        throwException("Java VM in check only mode");
    jclass cls = m_env->FindClass("ExaWrapper");
    check();
    if (!cls)
        throwException("FindClass for ExaWrapper failed");
    jmethodID mid = m_env->GetStaticMethodID(cls, "run", "()V");
    check();
    if (!mid)
        throwException("GetStaticMethodID for run failed");
    m_env->CallStaticVoidMethod(cls, mid);
    check();
    return true;
}

void JavaVMImpl::createJvm() {
    unsigned int numJvmOptions = m_jvmOptions.size();
    JavaVMOption *options = new JavaVMOption[numJvmOptions];
    for (size_t i = 0; i < numJvmOptions; ++i) {
        options[i].optionString = (char*)(m_jvmOptions[i].c_str());
        options[i].extraInfo = NULL;
    }

    JavaVMInitArgs vm_args;
    vm_args.version = JNI_VERSION_1_6;
    vm_args.nOptions = numJvmOptions;
    vm_args.options = options;
    vm_args.ignoreUnrecognized = JNI_FALSE;

    int rc = JNI_CreateJavaVM(&m_jvm, (void**)&m_env, &vm_args);
    if (rc != JNI_OK) {
        stringstream ss;
        ss << "Cannot start the JVM: ";
        switch (rc) {
            case JNI_ERR: ss << "unknown error"; break;
            case JNI_EDETACHED: ss << "thread is detached from VM"; break;
            case JNI_EVERSION: ss << "version error"; break;
            case JNI_ENOMEM: ss << "out of memory"; break;
            case JNI_EEXIST: ss << "VM already exists"; break;
            case JNI_EINVAL: ss << "invalid arguments"; break;
            default: ss << "unknown"; break;
        }
        ss << " (" << rc << ")";
        delete [] options;
        throwException(ss.str().c_str());
    }
    delete [] options;
}

void JavaVMImpl::compileScript() {
    jstring classnameStr = m_env->NewStringUTF(SWIGVM_params->script_name);
    check();
    jstring codeStr = m_env->NewStringUTF(m_scriptCode.c_str());
    check();
    jstring classpathStr = m_env->NewStringUTF(m_tmpClasspath.c_str());
    check();
    if (!classnameStr || !codeStr || !classpathStr)
        throwException("NewStringUTF for compile failed");
    jclass cls = m_env->FindClass("ExaCompiler");
    check();
    if (!cls)
        throwException("FindClass for ExaCompiler failed");
    jmethodID mid = m_env->GetStaticMethodID(cls, "compile", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V");
    check();
    if (!mid)
        throwException("GetStaticMethodID for compile failed");
    m_env->CallStaticVoidMethod(cls, mid, classnameStr, codeStr, classpathStr);
    check();
}

void JavaVMImpl::addExternalJarPaths() {
    const string jarKeyword = "%jar";
    const string whitespace = " \t\f\v";
    const string lineEnd = ";";
    size_t pos;
    while (true) {
        string jarPath = getOptionLine(jarKeyword, whitespace, lineEnd, pos);
        if (jarPath == "")
            break;
        for (size_t start = 0, delim = 0; ; start = delim + 1) {
            delim = jarPath.find(":", start);
            if (delim != string::npos) {
                string jar = jarPath.substr(start, delim - start);
                if (m_jarPaths.find(jar) == m_jarPaths.end())
                    m_jarPaths.insert(jar);
            }
            else {
                string jar = jarPath.substr(start);
                if (m_jarPaths.find(jar) == m_jarPaths.end())
                    m_jarPaths.insert(jar);
                break;
            }
        }
    }
    for (set<string>::iterator it = m_jarPaths.begin(); it != m_jarPaths.end(); ++it) {
        addJarToClasspath(*it);
    }
}

void JavaVMImpl::importScripts() {
    SWIGMetadata *meta = NULL;
    const string importKeyword = "%import";
    const string whitespace = " \t\f\v";
    const string lineEnd = ";";
    size_t pos;
    m_importedScriptChecksums.insert(scriptToMd5(m_scriptCode.c_str()));
    while (true) {
        string scriptName = getOptionLine(importKeyword, whitespace, lineEnd, pos);
        if (scriptName == "")
            break;
        if (!meta) {
            meta = new SWIGMetadata();
            if (!meta)
                throwException("Failure while importing scripts");
        }
        const char *scriptCode = meta->moduleContent(scriptName.c_str());
        const char *exception = meta->checkException();
        if (exception)
            throwException(exception);
        if (m_importedScriptChecksums.insert(scriptToMd5(scriptCode)).second) {
            // Script has not been imported yet
            m_scriptCode.insert(pos, scriptCode);
        }
    }
    if (meta)
        delete meta;
}

void JavaVMImpl::check() {
    jthrowable ex = m_env->ExceptionOccurred();
    if (ex) {
        m_env->ExceptionClear();
        string exceptionMessage = "";
        jclass exClass = m_env->GetObjectClass(ex);
        if (!exClass)
            throwException("FindClass for Throwable failed");
        // Throwable.toString()
        jmethodID toString = m_env->GetMethodID(exClass, "toString", "()Ljava/lang/String;");
        check();
        if (!toString)
            throwException("Throwable.toString() could not be found");
        jobject object = m_env->CallObjectMethod(ex, toString);
        if (object) {
            jstring message = static_cast<jstring>(object);
            char const *utfMessage = m_env->GetStringUTFChars(message, 0);
            exceptionMessage.append("\n");
            exceptionMessage.append(utfMessage);
            m_env->ReleaseStringUTFChars(message, utfMessage);
        }
        else {
            exceptionMessage.append("Throwable.toString(): result is null");
        }
        // Throwable.getStackTrace()
        jmethodID getStackTrace = m_env->GetMethodID(exClass, "getStackTrace", "()[Ljava/lang/StackTraceElement;");
        check();
        if (!getStackTrace)
            throwException("Throwable.getStackTrace() could not be found");
        jobjectArray frames = (jobjectArray)m_env->CallObjectMethod(ex, getStackTrace);
        if (frames) {
            jclass frameClass = m_env->FindClass("java/lang/StackTraceElement");
            check();
            if (!frameClass)
                throwException("FindClass for StackTraceElement failed");
            jmethodID frameToString = m_env->GetMethodID(frameClass, "toString", "()Ljava/lang/String;");
            check();
            if (!frameToString)
                throwException("StackTraceElement.toString() could not be found");
            jsize framesLength = m_env->GetArrayLength(frames);
            for (int i = 0; i < framesLength; i++) {
                jobject frame = m_env->GetObjectArrayElement(frames, i);
                check();
                jobject frameMsgObj = m_env->CallObjectMethod(frame, frameToString);
                if (frameMsgObj) {
                    jstring message = static_cast<jstring>(frameMsgObj);
                    const char *utfMessage = m_env->GetStringUTFChars(message, 0);
                    string line = utfMessage;
                    // If stack trace lines are wrapper or reflection entries, stop
                    if ((line.find("ExaWrapper.") == 0) || (line.find("ExaCompiler.") == 0) || (line.find("sun.reflect.") == 0)) {
                        if (i != 0)
                            exceptionMessage.append("\n");
                        m_env->ReleaseStringUTFChars(message, utfMessage);
                        break;
                    }
                    else {
                        if (i == 0)
                            exceptionMessage.append("\nStack trace:");
                        exceptionMessage.append("\n");
                        exceptionMessage.append(utfMessage);
                        m_env->ReleaseStringUTFChars(message, utfMessage);
                    }
                }
            }
        }
        throwException(exceptionMessage.c_str());
    }
}

void JavaVMImpl::registerFunctions() {
    jclass cls = m_env->FindClass("exascript_javaJNI");
    check();
    if (!cls)
        throwException("FindClass for exascript_javaJNI failed");
    int rc = m_env->RegisterNatives(cls, methods, sizeof(methods) / sizeof(methods[0]));
    check();
    if (rc)
        throwException("RegisterNatives failed");
}

void JavaVMImpl::setClasspath() {
    struct stat st;
    // Try m_exaJavaPath
    int rc = stat(m_exaJavaPath.c_str(), &st);
    if (rc == 0) {
        if (S_ISDIR(st.st_mode)) {
            m_tmpClasspath = m_exaJavaPath;
        }
        else {
            stringstream errorMsg;
            errorMsg << "Java VM classpath '" << m_exaJavaPath.c_str() << "' is not a directory";
            throwException(errorMsg.str().c_str());
        }
    }
    else if (rc && errno == ENOENT) {
        // Try m_testJavaPath
        rc = stat(m_testJavaPath.c_str(), &st);
        if (rc == 0) {
            if (S_ISDIR(st.st_mode)) {
                m_tmpClasspath = m_testJavaPath;
            }
            else {
                stringstream errorMsg;
                errorMsg << "Java VM classpath '" << m_testJavaPath.c_str() << "' is not a directory";
                throwException(errorMsg.str().c_str());
            }
        }
        else {
            stringstream errorMsg;
            errorMsg << "Java VM cannot open classpath directory '" << m_testJavaPath.c_str() << "': " << strerror(errno);
            throwException(errorMsg.str().c_str());
        }
    }
    else {
        stringstream errorMsg;
        errorMsg << "Java VM cannot open classpath directory '" << m_exaJavaPath.c_str() << "': " << strerror(errno);
        throwException(errorMsg.str().c_str());
    }

    // Create temp dir in classpath for .class files
    stringstream temp_path;
    temp_path << m_tmpClasspath << "/java_udf_" << SWIGVM_params->connection_id;
    m_tmpClasspath = temp_path.str();
    rc = mkdir((char *)m_tmpClasspath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    if (rc) {
        stringstream errorMsg;
        errorMsg << "Java VM cannot create temporary classpath directory '" << m_tmpClasspath.c_str() << "': " << strerror(errno);
        throwException(errorMsg.str().c_str());
    }

    // Set path to exaudf.jar
    char tmp[PATH_MAX];
    readlink("/proc/self/exe", tmp, sizeof(tmp));
    string path(tmp);
    string binDir("/bin/");
    size_t binPos = path.rfind(binDir);
    if (binPos == string::npos)
        throwException("Java VM cannot set the classpath");
    m_exaJarPath = path.substr(0, binPos + binDir.length() - 1) + "/udf/exaudf.jar";

    m_classpath = m_tmpClasspath + ":" + m_exaJarPath;
}

void JavaVMImpl::cleanupClasspath() {
    DIR *dir;
    struct dirent *entry;
    char path[PATH_MAX];
    int rc;

    dir = opendir(m_tmpClasspath.c_str());
    if (!dir) {
        if (errno == ENOENT) {
            // Directory does not exist (compilation error, etc.)
            return;
        }
        else {
            stringstream errorMsg;
            errorMsg << "Java VM cannot open temporary classpath directory \'" << m_exaJarPath.c_str() << "' for cleanup: " << strerror(errno);
            throwException(errorMsg.str().c_str());
        }
    }
    while ((entry = readdir(dir)) != NULL) {
        if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, ".."))
            continue;
        snprintf(path, sizeof(path), "%s/%s", m_tmpClasspath.c_str(), entry->d_name);
        rc = unlink(path);
        if (rc) {
            stringstream errorMsg;
            errorMsg << "Java VM cannot delete '" << entry->d_name << "' in temporary classpath directory during cleanup: " << strerror(errno);
            throwException(errorMsg.str().c_str());
        }
    }
    rc = closedir(dir);
    if (rc) {
        stringstream errorMsg;
        errorMsg << "Java VM cannot close temporary classpath directory '" << m_tmpClasspath.c_str() << "' after cleanup: " << strerror(errno);
        throwException(errorMsg.str().c_str());
    }
    rc = rmdir(m_tmpClasspath.c_str());
    if (rc) {
        stringstream errorMsg;
        errorMsg << "Java VM cannot remove temporary classpath directory '" << m_tmpClasspath.c_str() << "' after cleanup: " << strerror(errno);
        throwException(errorMsg.str().c_str());
    }
}

vector<unsigned char> JavaVMImpl::scriptToMd5(const char *script) {
    MD5_CTX ctx;
    unsigned char md5[MD5_DIGEST_LENGTH];
    MD5_Init(&ctx);
    MD5_Update(&ctx, script, strlen(script));
    MD5_Final(md5, &ctx);
    return vector<unsigned char>(md5, md5 + sizeof(md5));
}

void JavaVMImpl::addJarToClasspath(const string& path) {
    string jarPath = m_exaJavaPath + "/jars/" + path;

    struct stat st;
    int rc = stat(jarPath.c_str(), &st);
    if (rc && errno == ENOENT) {
        // Not found in HOME, try path directly
        jarPath = path;
        rc = stat(jarPath.c_str(), &st);
        if (rc) {
            stringstream errorMsg;
            errorMsg << "Java VM cannot find '" << jarPath.c_str() << "': " << strerror(errno);
            throwException(errorMsg.str().c_str());
        }
    }
    else if (rc) {
        stringstream errorMsg;
        errorMsg << "Java VM cannot find '" << jarPath.c_str() << "': " << strerror(errno);
        throwException(errorMsg.str().c_str());
    }

    if (!S_ISREG(st.st_mode)) {
        stringstream errorMsg;
        errorMsg << "'" << jarPath.c_str() << "' is not a regular file";
        throwException(errorMsg.str().c_str());
    }

    // Add file to classpath
    m_classpath += ":" + jarPath;
}

void JavaVMImpl::getExternalJvmOptions() {
    const string jvmOption = "%jvmoption";
    const string whitespace = " \t\f\v";
    const string lineEnd = ";";
    size_t pos;
    while (true) {
        string options = getOptionLine(jvmOption, whitespace, lineEnd, pos);
        if (options == "")
            break;
        for (size_t start = 0, delim = 0; ; start = delim + 1) {
            start = options.find_first_not_of(whitespace, start);
            if (start == string::npos)
                break;
            delim = options.find_first_of(whitespace, start);
            if (delim != string::npos) {
                m_jvmOptions.push_back(options.substr(start, delim - start));
            }
            else {
                m_jvmOptions.push_back(options.substr(start));
                break;
            }
        }
    }
}

void JavaVMImpl::setJvmOptions() {
    bool minHeap = false;
    bool maxHeap = false;
    bool maxStack = false;
    for (vector<string>::iterator it = m_jvmOptions.begin(); it != m_jvmOptions.end(); ++it) {
        if ((*it).find("-Xms") != string::npos) {
            minHeap = true;
        }
        else if ((*it).find("-Xmx") != string::npos) {
            maxHeap = true;
        }
        else if ((*it).find("-Xss") != string::npos) {
            maxStack = true;
        }
        else {
            stringstream errorMsg;
            errorMsg << "%jvmoption does not support option '" << *it << "'";
            throwException(errorMsg.str().c_str());
        }
    }

    // Initial heap size
    unsigned long minHeapSize = 128;
    unsigned long maxHeapSize = 1024;
    if (!minHeap) {
        stringstream ss;
        ss << "-Xms" << minHeapSize << "m";
        m_jvmOptions.push_back(ss.str());
    }
    // Max heap size
    if (!maxHeap) {
        unsigned long maxHeapSizeMb = static_cast<long>(0.625 * (SWIGVM_params->maximal_memory_limit / (1024 * 1024)));
        maxHeapSizeMb = (maxHeapSizeMb < minHeapSize) ? minHeapSize : maxHeapSizeMb;
        maxHeapSizeMb = (maxHeapSizeMb > maxHeapSize) ? maxHeapSize : maxHeapSizeMb;
        stringstream ss;
        ss << "-Xmx" << maxHeapSizeMb << "m";
        m_jvmOptions.push_back(ss.str());
    }
    // Max thread stack size
    if (!maxStack)
        m_jvmOptions.push_back("-Xss512k");
    // Error file path
    m_jvmOptions.push_back("-XX:ErrorFile=" + m_tmpClasspath + "/hs_err_pid%p.log");
    // Classpath
    m_jvmOptions.push_back("-Djava.class.path=" + m_classpath);
    // Serial garbage collection
    m_jvmOptions.push_back("-XX:+UseSerialGC");
}

string JavaVMImpl::getOptionLine(const string option, const string whitespace, const string lineEnd, size_t& pos) {
    string result;
    size_t startPos = m_scriptCode.find(option);
    if (startPos != string::npos) {
        size_t firstPos = startPos + option.length();
        firstPos = m_scriptCode.find_first_not_of(whitespace, firstPos);
        if (firstPos == string::npos) {
            stringstream ss;
            ss << "No values found for " << option << " statement";
            throwException(ss.str().c_str());
        }
        size_t lastPos = m_scriptCode.find_first_of(lineEnd + "\r\n", firstPos);
        if (lastPos == string::npos || m_scriptCode.compare(lastPos, lineEnd.length(), lineEnd) != 0) {
            stringstream ss;
            ss << "End of " << option << " statement not found";
            throwException(ss.str().c_str());
        }
        if (firstPos >= lastPos) {
            stringstream ss;
            ss << "No values found for " << option << " statement";
            throwException(ss.str().c_str());
        }
        size_t optionsEnd = m_scriptCode.find_last_not_of(whitespace, lastPos - 1);
        if (optionsEnd == string::npos || optionsEnd < firstPos) {
            stringstream ss;
            ss << "No values found for " << option << " statement";
            throwException(ss.str().c_str());
        }
        result = m_scriptCode.substr(firstPos, optionsEnd - firstPos + 1);
        m_scriptCode.erase(startPos, lastPos - startPos + 1);
    }
    pos = startPos;
    return result;
}

void JavaVMImpl::throwException(const char *message) {
    if (!m_exceptionThrown) {
        m_exceptionThrown = true;
        cleanupClasspath();
    }
    throw JavaVMach::exception(message);
}
