#include <sys/types.h>
#include <sys/stat.h>
#include <sys/resource.h>
#include <unistd.h>
#include <swigcontainers_ext.h>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <zmq.hpp>
#include <fcntl.h>
#include <fstream>

using namespace SWIGVMContainers;
using namespace std;
using namespace google::protobuf;

__thread SWIGVM_params_t *SWIGVMContainers::SWIGVM_params;

static string socket_name;
static char *socket_name_str;
static string output_buffer;
static SWIGVMExceptionHandler exchandler;
static pid_t parent_pid, my_pid;
static exascript_vmtype vm_type;
static exascript_request request;
static exascript_response response;

static string g_database_name;
static string g_database_version;
static string g_script_name;
static string g_source_code;
static unsigned long long g_session_id;
static unsigned long g_statement_id;
static unsigned int g_node_count;
static unsigned int g_node_id;
static unsigned long long g_vm_id;
static char *parent_executable_path;
static struct stat stat_buffer;
static bool remote_client;

#ifndef NDEBUG
#define SWIGVM_LOG_CLIENT
#endif
//#define SWIGVM_LOG_CLIENT
//#define LOG_COMMUNICATION

static void external_process_check()
{
    if (remote_client) return;
    if (parent_pid != 1) {
        if (::lstat(parent_executable_path, &stat_buffer) != 0) {
            ::unlink(socket_name_str);
#ifdef SWIGVM_LOG_CLIENT
            cerr << "### SWIGVM aborting with name '" << socket_name_str
                 << "' from process " << parent_pid
                 << " (" << ::getppid() << ',' << ::getpid() << ')' << endl;
#endif
            ::abort();
        }
    } else if (::access(&(socket_name_str[6]), F_OK) != 0) {
#ifdef SWIGVM_LOG_CLIENT
        cerr << "### SWIGVM aborting with name '" << socket_name_str
             << "' from process " << parent_pid
             << " (" << ::getppid() << ',' << ::getpid() << ')' << endl;
#endif
        ::abort();
    }
}

void *check_thread_routine(void* data)
{
    while(true) {
        external_process_check();
        ::usleep(100000);
    }
    return NULL;

}

void SWIGVMContainers::socket_send(zmq::socket_t &socket, zmq::message_t &zmsg)
{
#ifdef LOG_COMMUNICATION
    stringstream sb;
    uint32_t len = zmsg.size();
    sb << "/tmp/zmqcomm_log_" << ::getpid() << "_send.data";
    int fd = ::open(sb.str().c_str(), O_CREAT | O_APPEND | O_WRONLY, 00644);
    if (fd >= 0) {
        ::write(fd, &len, sizeof(uint32_t));
        ::write(fd, zmsg.data(), len);
        ::close(fd);
    }
#endif
    for (;;) {
        try {
            if (socket.send(zmsg) == true)
                return;
            external_process_check();
        } catch (std::exception &err) {
            external_process_check();
        } catch (...) {
            external_process_check();
        }
        ::usleep(100000);
    }
}

bool SWIGVMContainers::socket_recv(zmq::socket_t &socket, zmq::message_t &zmsg, bool return_on_error)
{
    for (;;) {
        try {
            if (socket.recv(&zmsg) == true) {
#ifdef LOG_COMMUNICATION
                stringstream sb;
                uint32_t len = zmsg.size();
                sb << "/tmp/zmqcomm_log_" << ::getpid() << "_recv.data";
                int fd = ::open(sb.str().c_str(), O_CREAT | O_APPEND | O_WRONLY, 00644);
                if (fd >= 0) {
                    ::write(fd, &len, sizeof(uint32_t));
                    ::write(fd, zmsg.data(), len);
                    ::close(fd);
                }
#endif
                return true;
            }
            external_process_check();
        } catch (std::exception &err) {
            external_process_check();
            
        } catch (...) {
            external_process_check();
        }
        if (return_on_error) return false;
        ::usleep(100000);
    }
    return false;
}

static bool send_init(zmq::socket_t &socket, const string client_name)
{
    request.Clear();
    request.set_type(MT_CLIENT);
    request.set_connection_id(0);
    exascript_client *req = request.mutable_client();
    req->set_client_name(client_name);
    if (!request.SerializeToString(&output_buffer)) {
        exchandler.setException("Communication error: failed to serialize data");
        return false;
    }
    zmq::message_t zmsg((void*)output_buffer.c_str(), output_buffer.length(), NULL, NULL);
    socket_send(socket, zmsg);

    zmq::message_t zmsgrecv;
    response.Clear();
    if (!socket_recv(socket, zmsgrecv, true))
        return false;
    if (!response.ParseFromArray(zmsgrecv.data(), zmsgrecv.size())) {
        exchandler.setException("Failed to parse data");
        return false;
    }

    SWIGVM_params->connection_id = response.connection_id();
#ifdef SWIGVM_LOG_CLIENT
    stringstream sb; sb << std::hex << SWIGVM_params->connection_id;
    cerr << "### SWIGVM connected with id " << sb.str() << endl;
#endif
    if (response.type() == MT_CLOSE) {
        if (response.close().has_exception_message())
            exchandler.setException(response.close().exception_message().c_str());
        else exchandler.setException("Connection closed by server");
        return false;
    }
    if (response.type() != MT_INFO) {
        exchandler.setException("Wrong message type, should be MT_INFO");
        return false;
    }
    const exascript_info &rep = response.info();
    g_database_name = rep.database_name();
    g_database_version = rep.database_version();
    g_script_name = rep.script_name();
    g_source_code = rep.source_code();
    g_session_id = rep.session_id();
    g_statement_id = rep.statement_id();
    g_node_count = rep.node_count();
    g_node_id = rep.node_id();
    g_vm_id = rep.vm_id();
    vm_type = rep.vm_type();

    SWIGVM_params->maximal_memory_limit = rep.maximal_memory_limit();
    struct rlimit d;
    d.rlim_cur = d.rlim_max = rep.maximal_memory_limit();
    if (setrlimit(RLIMIT_AS, &d) != 0)
#ifdef SWIGVM_LOG_CLIENT
        cerr << "WARNING: Failed to set memory limit" << endl;
#else
        throw SWIGVM::exception("Failed to set memory limit");
#endif
    d.rlim_cur = d.rlim_max = 0;
    if (setrlimit(RLIMIT_CORE, &d) != 0)
#ifdef SWIGVM_LOG_CLIENT
        cerr << "WARNING: Failed to set core limit" << endl;
#else
        throw SWIGVM::exception("Failed to set core limit");
#endif
    /* d.rlim_cur = d.rlim_max = 65536; */
    d.rlim_cur = d.rlim_max = 32768;
    if (setrlimit(RLIMIT_NOFILE, &d) != 0)
#ifdef SWIGVM_LOG_CLIENT
        cerr << "WARNING: Failed to set nofile limit" << endl;
#else
        throw SWIGVM::exception("Failed to set nofile limit");
#endif
    d.rlim_cur = d.rlim_max = 32768;
    if (setrlimit(RLIMIT_NPROC, &d) != 0)
#ifdef SWIGVM_LOG_CLIENT
        cerr << "WARNING: Failed to set nproc limit" << endl;
#else
        throw SWIGVM::exception("Failed to set nproc limit");
#endif
    { /* send meta request */
        request.Clear();
        request.set_type(MT_META);
        request.set_connection_id(SWIGVM_params->connection_id);
        if (!request.SerializeToString(&output_buffer)) {
            exchandler.setException("Communication error: failed to serialize data");
            return false;
        }
        zmq::message_t zmsg((void*)output_buffer.c_str(), output_buffer.length(), NULL, NULL);
        socket_send(socket, zmsg);
    } /* receive meta response */
    {   zmq::message_t zmsg;
        socket_recv(socket, zmsg);
        response.Clear();
        if (!response.ParseFromArray(zmsg.data(), zmsg.size())) {
            exchandler.setException("Communication error: failed to parse data");
            return false;
        }
        if (response.type() == MT_CLOSE) {
            if (response.close().has_exception_message())
                exchandler.setException(response.close().exception_message().c_str());
            else exchandler.setException("Connection closed by server");
            return false;
        }
        if (response.type() != MT_META) {
            exchandler.setException("Wrong message type, should be META");
            return false;
        }
        const exascript_metadata &rep = response.meta();
        SWIGVM_params->inp_iter_type = (SWIGVM_itertype_e)(rep.input_iter_type());
        SWIGVM_params->out_iter_type = (SWIGVM_itertype_e)(rep.output_iter_type());
        for (int col = 0; col < rep.input_columns_size(); ++col) {
            const exascript_metadata_column_definition &coldef = rep.input_columns(col);
            SWIGVM_params->inp_names->push_back(coldef.name());
            SWIGVM_params->inp_types->push_back(SWIGVM_columntype_t());
            SWIGVM_columntype_t &coltype = SWIGVM_params->inp_types->back();
            coltype.len = 0; coltype.prec = 0; coltype.scale = 0;
            coltype.type_name = coldef.type_name();
            switch (coldef.type()) {
            case PB_UNSUPPORTED:
                exchandler.setException("Unsupported column type found");
                return false;
            case PB_DOUBLE:
                coltype.type = DOUBLE;
                break;
            case PB_INT32:
                coltype.type = INT32;
                coltype.prec = coldef.precision();
                coltype.scale = coldef.scale();
                break;
            case PB_INT64:
                coltype.type = INT64;
                coltype.prec = coldef.precision();
                coltype.scale = coldef.scale();
                break;
            case PB_NUMERIC:
                coltype.type = NUMERIC;
                coltype.prec = coldef.precision();
                coltype.scale = coldef.scale();
                break;
            case PB_TIMESTAMP:
                coltype.type = TIMESTAMP;
                break;
            case PB_DATE:
                coltype.type = DATE;
                break;
            case PB_STRING:
                coltype.type = STRING;
                coltype.len = coldef.size();
                break;
            case PB_BOOLEAN:
                coltype.type = BOOLEAN;
                break;
            default:
                exchandler.setException("Unknown column type found");
                return false;
            }	
        }
        for (int col = 0; col < rep.output_columns_size(); ++col) {
            const exascript_metadata_column_definition &coldef = rep.output_columns(col);
            SWIGVM_params->out_names->push_back(coldef.name());
            SWIGVM_params->out_types->push_back(SWIGVM_columntype_t());
            SWIGVM_columntype_t &coltype = SWIGVM_params->out_types->back();
            coltype.len = 0; coltype.prec = 0; coltype.scale = 0;
            coltype.type_name = coldef.type_name();
            switch (coldef.type()) {
            case PB_UNSUPPORTED:
                exchandler.setException("Unsupported column type found");
                return false;
            case PB_DOUBLE:
                coltype.type = DOUBLE;
                break;
            case PB_INT32:
                coltype.type = INT32;
                coltype.prec = coldef.precision();
                coltype.scale = coldef.scale();
                break;
            case PB_INT64:
                coltype.type = INT64;
                coltype.prec = coldef.precision();
                coltype.scale = coldef.scale();
                break;
            case PB_NUMERIC:
                coltype.type = NUMERIC;
                coltype.prec = coldef.precision();
                coltype.scale = coldef.scale();
                break;
            case PB_TIMESTAMP:
                coltype.type = TIMESTAMP;
                break;
            case PB_DATE:
                coltype.type = DATE;
                break;
            case PB_STRING:
                coltype.type = STRING;
                coltype.len = coldef.size();
                break;
            case PB_BOOLEAN:
                coltype.type = BOOLEAN;
                break;
            default:
                exchandler.setException("Unknown column type found");
                return false;
            }
        }
    }
    return true;
}

static void send_close(zmq::socket_t &socket, const string &exmsg)
{
    request.Clear();
    request.set_type(MT_CLOSE);
    request.set_connection_id(SWIGVM_params->connection_id);
    exascript_close *req = request.mutable_close();
    if (exmsg != "") req->set_exception_message(exmsg);
    request.SerializeToString(&output_buffer);
    zmq::message_t zmsg((void*)output_buffer.c_str(), output_buffer.length(), NULL, NULL);
    socket_send(socket, zmsg);
}

static bool send_run(zmq::socket_t &socket)
{
    {   /* send done request */
        request.Clear();
        request.set_type(MT_RUN);
        request.set_connection_id(SWIGVM_params->connection_id);
        if (!request.SerializeToString(&output_buffer))
            throw SWIGVM::exception("Communication error: failed to serialize data");
        zmq::message_t zmsg((void*)output_buffer.c_str(), output_buffer.length(), NULL, NULL);
        socket_send(socket, zmsg);
    } { /* receive done response */
        zmq::message_t zmsg;
        socket_recv(socket, zmsg);
        response.Clear();
        if (!response.ParseFromArray(zmsg.data(), zmsg.size()))
            throw SWIGVM::exception("Communication error: failed to parse data");
        if (response.type() == MT_CLOSE) {
            if (response.close().has_exception_message())
                throw SWIGVM::exception(response.close().exception_message().c_str());
            throw SWIGVM::exception("Wrong response type, got empty close response");
        } else if (response.type() == MT_CLEANUP) {
            return false;
        } else if (response.type() != MT_RUN) {
            throw SWIGVM::exception("Wrong response type, should be done");
        }
    }
    return true;
}

static bool send_done(zmq::socket_t &socket)
{
    {   /* send done request */
        request.Clear();
        request.set_type(MT_DONE);
        request.set_connection_id(SWIGVM_params->connection_id);
        if (!request.SerializeToString(&output_buffer))
            throw SWIGVM::exception("Communication error: failed to serialize data");
        zmq::message_t zmsg((void*)output_buffer.c_str(), output_buffer.length(), NULL, NULL);
        socket_send(socket, zmsg);
    } { /* receive done response */
        zmq::message_t zmsg;
        socket_recv(socket, zmsg);
        response.Clear();
        if (!response.ParseFromArray(zmsg.data(), zmsg.size()))
            throw SWIGVM::exception("Communication error: failed to parse data");
        if (response.type() == MT_CLOSE) {
            if (response.close().has_exception_message())
                throw SWIGVM::exception(response.close().exception_message().c_str());
            throw SWIGVM::exception("Wrong response type, got empty close response");
        } else if (response.type() == MT_CLEANUP) {
            return false;
        } else if (response.type() != MT_DONE)
            throw SWIGVM::exception("Wrong response type, should be done");
    }
    return true;
}

static void send_finished(zmq::socket_t &socket)
{
    {   /* send done request */
        request.Clear();
        request.set_type(MT_FINISHED);
        request.set_connection_id(SWIGVM_params->connection_id);
        if (!request.SerializeToString(&output_buffer))
            throw SWIGVM::exception("Communication error: failed to serialize data");
        zmq::message_t zmsg((void*)output_buffer.c_str(), output_buffer.length(), NULL, NULL);
        socket_send(socket, zmsg);
    } { /* receive done response */
        zmq::message_t zmsg;
        socket_recv(socket, zmsg);
        response.Clear();
        if(!response.ParseFromArray(zmsg.data(), zmsg.size()))
            throw SWIGVM::exception("Communication error: failed to parse data");
        if (response.type() == MT_CLOSE) {
            if (response.close().has_exception_message())
                throw SWIGVM::exception(response.close().exception_message().c_str());
            throw SWIGVM::exception("Wrong response type, got empty close response");
        } else if (response.type() != MT_FINISHED)
            throw SWIGVM::exception("Wrong response type, should be finished");
    }
}

int main(int argc, char **argv) {
    if (argc < 2) {
        cerr << "Usage: " << argv[0] << " <socket> [<parent_pid>|python|r|java [pidfile]]" << endl;
        return 1;
    }

    socket_name = argv[1];
    socket_name_str = argv[1];
    char *socket_name_file = argv[1];
    exascript_vmtype remote_vm_type = PB_VM_PYTHON;
    remote_client = false;
    my_pid = ::getpid();
    SWIGVM_params = new SWIGVM_params_t(true);
    zmq::context_t context(1);

    if (socket_name.length() > 4 && strncmp(socket_name_str, "tcp:", 4) == 0) {
        remote_client = true;
        if (argc >= 3) {
            if (strcmp(argv[2], "python") == 0)
                remote_vm_type = PB_VM_PYTHON;
            else if (strcmp(argv[2], "r") == 0)
                remote_vm_type = PB_VM_R;
            else if (strcmp(argv[2], "java") == 0)
                remote_vm_type = PB_VM_JAVA;
            else {
                cerr << "Remote VM type '" << argv[3] << "' not supported." << endl;
                return 2;
            }
        }
        if (argc >= 4)
            ofstream(argv[3]) << my_pid;
        parent_pid = 0;
    } else if (argc < 3) {
        cerr << "Usage: " << argv[0] << " <socket> [<parent_pid>|python|r|java [pidfile]]" << endl;
        return 1;
    } else {
        stringstream sb(argv[2]);
        sb >> parent_pid;
    }

    if (socket_name.length() > 6 && strncmp(socket_name_str, "ipc:", 4) == 0)
        socket_name_file = &(socket_name_file[6]);

    {   stringstream sb;
        sb << "/proc/" << parent_pid << "/exe";
        parent_executable_path = new char[sb.str().length() + 1];
        memcpy(parent_executable_path, sb.str().c_str(), sb.str().length()+1);
    }

#ifdef SWIGVM_LOG_CLIENT
    cerr << "### SWIGVM starting " << argv[0] << " with name '" << socket_name
         << "' from process " << parent_pid
         << " (" << ::getppid() << ',' << ::getpid() << "): '"
         << argv[1] << '\'' << endl;
#endif

    pthread_t check_thread;
    if (!remote_client)
        pthread_create(&check_thread, NULL, check_thread_routine, NULL);

    int linger_timeout = 0;
    int recv_sock_timeout = 1000;
    int send_sock_timeout = 1000;

    if (remote_client) {
        recv_sock_timeout = 10000;
        send_sock_timeout = 5000;
    }

reinit:
    zmq::socket_t socket(context, ZMQ_REQ);

    socket.setsockopt(ZMQ_LINGER, &linger_timeout, sizeof(linger_timeout));
    socket.setsockopt(ZMQ_RCVTIMEO, &recv_sock_timeout, sizeof(recv_sock_timeout));
    socket.setsockopt(ZMQ_SNDTIMEO, &send_sock_timeout, sizeof(send_sock_timeout));

    if (remote_client) socket.bind(socket_name_str);
    else socket.connect(socket_name_str);

    SWIGVM_params->sock = &socket;
    SWIGVM_params->exch = &exchandler;

    if (!send_init(socket, socket_name)) {
        if (!remote_client && exchandler.exthrowed) {
            send_close(socket, exchandler.exmsg);
            return 1;
        }
        goto reinit;
    }
    if (vm_type == PB_VM_EXTERNAL) {
        if (!remote_client) {
            cerr << "ZMQVM is not started as remote VM." << endl;
            return 3;
        }
        vm_type = remote_vm_type;
    }

    SWIGVM_params->dbname = (char*) g_database_name.c_str();
    SWIGVM_params->dbversion = (char*) g_database_version.c_str();
    SWIGVM_params->script_name = (char*) g_script_name.c_str();
    SWIGVM_params->script_code = (char*) g_source_code.c_str();
    SWIGVM_params->session_id = g_session_id;
    SWIGVM_params->statement_id = g_statement_id;
    SWIGVM_params->node_count = g_node_count;
    SWIGVM_params->node_id = g_node_id;
    SWIGVM_params->vm_id = g_vm_id;

    SWIGVM *vm = NULL;
    try {
        switch (vm_type) {
#ifdef ENABLE_PYTHON_VM
            case PB_VM_PYTHON:
                vm = new PythonVM(false);
                break;
#endif
#ifdef ENABLE_R_VM
            case PB_VM_R:
                vm = new RVM(false);
                break;
#endif
#ifdef ENABLE_GUILE_VM
            case PB_VM_SCHEME:
                vm = new SchemeVM(false);
                break;
            case PB_VM_JAVASCRIPT:
                vm = new JavascriptVM(false);
                break;
#endif
#ifdef ENABLE_JAVA_VM
            case PB_VM_JAVA:
                vm = new JavaVMach(false);
                break;
#endif
            default:
                send_close(socket, "Unknown or unsupported VM type");
                return 1;
        }
        for(;;) {
            if (!send_run(socket))
                break;
            SWIGVM_params->inp_force_finish = false;
            while(!vm->run());
            if (!send_done(socket))
                break;
        }
        delete vm; vm = NULL;
        send_finished(socket);
    } catch (std::exception &err) {
        send_close(socket, err.what()); socket.close();
#ifdef SWIGVM_LOG_CLIENT
        cerr << "### SWIGVM crashing with name '" << socket_name
             << "' from process " << parent_pid
             << " (" << ::getppid() << ',' << ::getpid() << "): " << err.what() << endl;
#endif
        goto error;
    } catch (...) {
        send_close(socket, "Internal/Unknown error throwed"); socket.close();
#ifdef SWIGVM_LOG_CLIENT
        cerr << "### SWIGVM crashing with name '" << socket_name
             << "' from process " << parent_pid
             << " (" << ::getppid() << ',' << ::getpid() << ')' << endl;
#endif
        goto error;
    }
#ifdef SWIGVM_LOG_CLIENT
    cerr << "### SWIGVM finishing with name '" << socket_name
         << "' from process " << parent_pid
         << " (" << ::getppid() << ',' << ::getpid() << ')' << endl;
#endif
    socket.close();
    if (!remote_client) {
        ::pthread_cancel(check_thread);
        ::unlink(socket_name_file);
    }
    return 0;

error:
    delete vm; vm = NULL;
    socket.close();
    if (!remote_client) {
        ::pthread_cancel(check_thread);
        ::unlink(socket_name_file);
    } else {
        ::sleep(3); // give other components time to shutdown
    }
    return 1;
}
