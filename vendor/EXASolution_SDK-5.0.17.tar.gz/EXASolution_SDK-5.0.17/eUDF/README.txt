EXASolution Development Tools for external scripts

Copyright (c) 2004-2016 EXASOL AG. All rights reserved.

=========================================================
EXASolution Development Tools for external scripts (eUDF)
=========================================================

This directory contains several implementations of eUDF framekworks
for different environments and goals. 

The following directories and files exist:

Python
  Implementation of all eUDF components with Python, mostly for
  testing and debugging purposes.

C++
  A complete implementation of eUDF containers for executing Python 
  and R code, fully compatible with internal UDFs. It also contains
  the protocol definition classes (ZeroMQ and Google Protocol Buffers).


-------------------------------
Prerequisites for eUDF services
-------------------------------

Our implementations for eUDF require ZeroMQ 2.2 and Google Protocol Buffers
2.5.0. To compile the dependencies you need libuuid-devel, libgcc,
autotools, libtool. These packages are part of normal Linux
distributions and can be installed with their package manager.

Installation of ZeroMQ
----------------------
$> wget http://download.zeromq.org/zeromq-2.2.0.tar.gz
$> tar xzvf zeromq-2.2.0.tar.gz
$> cd zeromq-2.2.0 && ./configure && make && sudo make install
$> sudo ln -s /usr/local/lib/libzmq.* /usr/lib/hadoop/lib/native/

Installation of Google Protocol Buffers
---------------------------------------
$> wget http://protobuf.googlecode.com/files/protobuf-2.5.0.tar.gz
$> tar xzvf protobuf-2.5.0.tar.gz
$> cd protobuf-2.5.0 && ./configure && make && sudo make install
$> ln -s /usr/local/lib/libproto* /usr/lib/hadoop/lib/native/
$> cd java
$> mvn install
$> sudo cp ~/.m2/repository/com/google/protobuf/protobuf-java/2.5.0/protobuf-java-2.5.0.jar /usr/lib/hadoop/


---------------------
Python implementation
---------------------

The implementation of eUDF services in Python contains the following files:

allinone_python.py
  This is a dummy Python environment implementation of internal Python
  UDFs and can be used to debug EXASolution Python scripts. Users
  should copy this file and modify it. It has two comments, #BEGIN 
  and #END, between which users can insert their own UDF code. This 
  file should be executed with two arguments, input and output CSV 
  file names. By that it's possible to test and debug Python UDF
  scripts locally in your favorite IDE without EXASolution.

redirector.py
  Python implementation of the redirector service for eUDF scripts. 
  Should be called with the redirector URL on which it listens for 
  EXASolution requests, and one or more container URLS which executes 
  the code.

vmpython.py
  Sample implementation of a simple script container that can execute 
  Python code.

exasolution.py
  Emulates a running EXASolution, but reads and writes data from/to 
  CSV files. It allows to test eUDF containers without EXASolution.

library.py
zmqcontainer_pb2.py
  Support libraries.

Executing these scripts without arguments will display a help
text. These scripts have no execute flag, please call it with your
Python 2.7, like this:
$> python2.7 allinone_python.py in.csv out.csv

It requires ZeroMQ 2.2 with compiled Python support and Google
Protocol Buffers 2.5.0.


------------------
C++ implementation
------------------

To compile the C++ components run following command in the C++ directory:
$> make JAVA_HOME=/path/to/java/installation

This command creates a executable with name "zmqcontainerclient",
which works like the "vmpython.py" Module in the Python
implementation, but supports Java, Python and R scripts.

The C++ implementation has following dependencies:
- Google Protocol Buffers 2.5.0
- ZeroMQ 2.2
- OpenJDK 1.7.0
- Python 2.7
- R 3.0


---------
Glossary
---------

Container or VM
  eUDF service which reads the data from EXASolution, executes some code 
  on this data and emits result tuples to EXASolution. Semantically,
  it works exactly like internal UDF virtual machines.

Redirector service
  A service that knows about available containers, starts  containers 
  on demand and replies its ZMQ URL to EXASolution. By that, it 
  orchestrates the connections between EXASolution and containers.
