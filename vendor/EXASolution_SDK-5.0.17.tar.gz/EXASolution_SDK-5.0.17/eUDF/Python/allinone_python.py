import sys, csv, datetime, imp, traceback
def get_code():
    cur = open(sys.argv[0]).read()
    return cur[cur.index('#'+'BEGIN')+7:cur.index('#'+'END')]
def cleanup(): pass # empty cleanup if it is not defined later
exa = None          # global exa variable, will be defined later
# === Configuration ============================================================
# metadata
cfg_database_name       = 'testdb'
cfg_database_version    = '4.2.0'
cfg_script_name         = 'test_script'
cfg_script_code         = get_code()
cfg_script_language     = 'Python 2.7.2'
cfg_session_id          = 'XXX'
cfg_statement_id        = 1234
cfg_node_count          = 1
cfg_node_id             = 0
cfg_vm_id               = '1234'

# input configuration
cfg_input_type          = 'SCALAR'
cfg_input_columns       = [{'name': 'col1',
                            'type': int,
                            'sqltype': 'DECIMAL(18,0)',
                            'precision': 18,
                            'scale': 0},
                           {'name': 'col2',
                            'type': unicode,
                            'sqltype': 'VARCHAR(20)',
                            'length': 20}]
cfg_input_column_count  = len(cfg_input_columns)

# output configuration
cfg_output_type         = 'RETURN'
cfg_output_columns      = [{'name': 'out1',
                            'type': unicode,
                            'sqltype': 'VARCHAR(30)',
                            'length': 30}]
cfg_output_column_count = len(cfg_output_columns)

# === Script ===================================================================
#BEGIN
def run(ctx):
    return u"<%s,%s>" % (unicode(ctx.col1), unicode(ctx.col2))

#END
# Alternatively you can write the code in extra file and uncomment next lines:
#   cfg_script_code = open('myscript.py').read()
#   exec cfg_script_code
# === PowerLytics emulator (DO NOT CHANGE) =====================================
class _Exa:
    def __init__(self):
        class exameta: pass
        mo = exameta()
        mo.database_name = cfg_database_name
        mo.database_version = cfg_database_version
        mo.script_name = cfg_script_name
        mo.script_code = cfg_script_code
        mo.script_language = cfg_script_language
        mo.session_id = cfg_session_id
        mo.statement_id = cfg_statement_id
        mo.node_count = cfg_node_count
        mo.node_id = cfg_node_id
        mo.vm_id = cfg_vm_id
        mo.input_type = cfg_input_type
        mo.output_type = cfg_output_type
        mo.input_column_count = cfg_input_column_count
        mo.output_column_count = cfg_output_column_count
        class exacolumn:
            def __init__(self, d):
                self.name = d['name']
                self.type = d['type']
                self.sql_type = d['sqltype']
                self.precision = d.get('precision', None)
                self.scale = d.get('scale', None)
                self.length = d.get('length', None)
                mo.input_columns = [exacolumn(a) for a in cfg_input_columns]
                mo.output_colunns = [exacolumn(a) for a in cfg_output_columns]
        self.meta = mo
        self.__modules = {}
    def import_script(self, script):
        try: code = open('%s.py' % script).read()
        except Exception, err:
            raise ImportError(u'Importing script %s failed: %s' % (script, str(err)))
        if self.__modules.has_key(code):
            return self.__modules[code]
        obj = imp.new_module(script)
        obj.__file__ = '<%s>' % script
        obj.__dict__['exa'] = self
        try: exec compile(code, script, 'exec') in obj.__dict__
        except Exception, err:
            raise ImportError(u'Importing module %s failed: %s' % (script, str(err)))
        self.__modules[code] = obj
        return obj
exa = _Exa()

class exaiter:
    def __init__(self, inp, out):
        self.__inp_name = inp
        self.next(reset = True)
        self.__out = csv.writer(open(out, 'w'))
        self.__dat = {}
        def rd(num, fun):
            def x():
                dat = self.__row[num]
                if dat == '': return None
                return fun(dat)
            return x
        def convert_date(x):
            val = datetime.datetime.strptime(x, "%Y-%m-%d")
            return datetime.date(val.year, val.month, val.day)
        def convert_timestamp(x):
            return datetime.datetime.strptime(x, "%Y-%m-%d %H:%M:%S.%f")
        def convert_bool(x):
            return str(x).lower() in ('yes', 'true', '1', 't')
        for colnum in range(cfg_input_column_count):
            col = cfg_input_columns[colnum]
            if col['type'] in (float, long, int, unicode):
                self.__dat[col['name']] = rd(colnum, col['type'])
            elif col['type'] == datetime.date:
                self.__dat[col['name']] = rd(colnum, convert_date)
            elif col['type'] == datetime.datetime:
                self.__dat[col['name']] = rd(colnum, convert_timestamp)
            elif col['type'] == bool:
                self.__dat[col['name']] = rd(colnum, convert_bool)
            else: raise RuntimeError("Unknown type: %s" % repr(col['type']))
            self.__dat[colnum] = self.__dat[col['name']]
        self.__emit = []
        for colnum in range(cfg_output_column_count):
            col = cfg_output_columns[colnum]
            if col['type'] in (float, long, int, unicode):
                self.__emit.append(unicode)
            elif col['type'] == datetime.date:
                self.__emit.append(lambda x: x.isoformat())
            elif col['type'] == datetime.datetime:
                self.__emit.append(lambda x: x.isoformat(' '))
            else: raise RuntimeError("Unknown type: %s" % repr(col['type']))
        self.__emit = tuple(self.__emit)
    def __getitem__(self, key):
        if self.__finished: raise RuntimeError("Iteration finished")
        key = unicode(key)
        if key not in self.__dat:
            raise RuntimeError(u"Column with name '%s' does not exist" % key)
        return self.__dat[key]()
    def __getattr__(self, key):
        if self.__finished: raise RuntimeError("Iteration finished")
        key = unicode(key)
        if key not in self.__dat:
            raise RuntimeError(u"Column with name '%s' does not exist" % key)
        return self.__dat[key]()
    def emit(self, *output):
        row = []
        for d,f in zip(output, self.__emit):
            row.append(f(d))
        self.__out.writerow(row)
        return None
    def next(self, reset = False):
        if reset:
            self.__inp = csv.reader(open(self.__inp_name), skipinitialspace = True)
            self.__finished = False
        if self.__finished: return False
        try: self.__row = self.__inp.next()
        except StopIteration:
            self.__finished = True
            return False
        return True
    def reset(self):
        return self.next(reset = True)
    def restBufferSize(self):
        return 0
    def groupSize(self):
        return 0

def main(args):
    if len(args) != 3:
        print "Usage:", args[0], "<input> <output>"
        return 1
    def disallowed_function(*args, **kw):
        raise RuntimeError("next(), reset() and emit() functions are not allowed in scalar context")
    try:
        it = exaiter(args[1], args[2]); it_next = it.next; it_emit = it.emit
        if cfg_input_type == 'SCALAR': it.next = it.reset = disallowed_function
        if cfg_output_type == 'RETURN': it.emit = disallowed_function
        if cfg_input_type == 'EMIT':
            if cfg_output_type == 'RETURN': it_emit(run(it))
            else: run(it)
        else:
            if cfg_output_type == 'RETURN':
                while True:
                    it_emit(run(it))
                    if not it_next(): break
            else:
                while True:
                    run(it)
                    if not it_next(): break
        cleanup()
    except Exception, err:
        errtypel, errobj, backtrace = sys.exc_info()
        if backtrace.tb_next: backtrace = backtrace.tb_next
        err.args = ("".join(traceback.format_exception(errtypel, errobj, backtrace)),)
        raise err
    return 0

if __name__ == '__main__':
    sys.exit(main(sys.argv))
