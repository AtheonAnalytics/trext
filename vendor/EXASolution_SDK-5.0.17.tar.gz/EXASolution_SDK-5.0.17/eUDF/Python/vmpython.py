import traceback, sys
if len(sys.argv) != 2:
    print "Usage:", sys.argv[0], "<bind_url>"
    sys.exit(1)

import library
print "Ready..."

# initialize the 'exa' variable, which holds the metadata
exa = library.exa(library.comm(sys.argv[1]))

try:
    # execute the script code
    exec exa.meta.script_code

    run = globals()['run']
    if 'cleanup' in globals():
        cleanup = globals()['cleanup']

    it = library.exaiter(exa)
    # store original values of it.next and it.emit to disallow these functions in the iterator
    it_next = it.next; it_emit = it.emit
    if exa._input_type == 'SCALAR':
        # on scalar UDFs user should not call next and reset functions but simply return, because the run function is
        # called per row
        it.next = it.reset = library.disallowed_function
    if exa._output_type == 'RETURN':
        # on return UDFs user should not call emit function but simply return the value, which should be emited.
        it.emit = library.disallowed_function

    # the main loop, one iteration per group, which is randomaly choosen by EXASolution or if GROUP BY is used in the
    # query and the function is a SET function, corresponds to the GROUP BY groups.
    while True:
        # initiate the itereration, returns MT_RUN or, if no more groups available, returns MT_CLEANUP, in which we
        # break the main loop
        exa._comm(exa._z.MT_RUN, (exa._z.MT_RUN, exa._z.MT_CLEANUP))
        if exa._comm.rep.type == exa._z.MT_CLEANUP: break

        # Read first block of rows
        if not it_next(first = True):
            raise RuntimeError("First block fetch failed")

        if exa._input_type == 'SET':
            # the UDF is a 'SET' function, so let the iteration be done by the user in the run function
            if exa._output_type == 'RETURN':
                # the UDF is a 'RETURN' function, so the run function returns the value, which should be emited
                print "WORK", exa._comm.connection_id, "in mode SET->RETURN"
                it_emit(run(it))
            elif exa._output_type == 'EMIT':
                # the UDF is a 'EMIT' function, so the run function emits the data by self
                print "WORK", exa._comm.connection_id, "in mode SET->EMIT"
                run(it)
            else: raise RuntimeError("Internal error - unknown output mode")

        elif exa._input_type == 'SCALAR':
            # the UDF is a 'SCALAR' function, so the run function is called on per row basis.
            if exa._output_type == 'RETURN':
                print "WORK", exa._comm.connection_id, "in mode SCALAR->RETURN"
                while True:
                    it_emit(run(it))
                    if not it_next(): break
            elif exa._output_type == 'EMIT':
                print "WORK", exa._comm.connection_id, "in mode SCALAR->EMIT"
                while True:
                    run(it)
                    if not it_next(): break
            else: raise RuntimeError("Internal error - unknown output mode")

        else: raise RuntimeError("Internal error - unknown input mode")
        it_emit() # flush the internal output buffer

        # finish current group
        exa._comm(exa._z.MT_DONE, (exa._z.MT_DONE, exa._z.MT_CLEANUP))
        if exa._comm.rep.type == exa._z.MT_CLEANUP: break
    
    # all groups are processed, call 'cleanup' function if defined
    if 'cleanup' in globals():
        cleanup()
    try: exa._comm(exa._z.MT_FINISHED, exa._z.MT_FINISHED)
    except Exception: pass # last sync, error here are not important

except Exception, err:
    # print backtrace on error
    errtypel, errobj, backtrace = sys.exc_info()
    exa._comm.req.close.exception_message = "%s: %s" % (err.__class__.__name__, str(err).strip())
    print "ERROR", exa._comm.connection_id, ":", exa._comm.req.close.exception_message
    print "".join(traceback.format_exception(errtypel, errobj, backtrace))
    exa._comm(exa._z.MT_CLOSE)
    sys.exit(1)
