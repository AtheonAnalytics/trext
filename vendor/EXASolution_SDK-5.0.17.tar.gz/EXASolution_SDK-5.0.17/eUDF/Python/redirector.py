import sys
from time import asctime as t
sys.stdout = sys.stderr

if len(sys.argv) < 3:
    print "Usage: %s <bind_socket> <vm_socket_1> [... <vm_socket_n>]" % sys.argv[0]
    sys.exit(1)

print t(), "Import modules and initialize redirector"

import zmq, time, random
from zmqcontainer_pb2 import *

VM_TIMEOUT = 120
USABLE_TIMEOUT = 3

vm_socket_urls = []
for url in sys.argv[2:]:
    vm_socket_urls.append({
            'client': None, 
            'url': url,
            'ping': time.time(),
            'usable_after': 0})
vm_socket_refs = list(range(len(vm_socket_urls)))
redir_socket_url = sys.argv[1]
request = exascript_request()
response = exascript_response()
zcontext = zmq.Context()

redir_socket = None
def reinitialize_socket():
    global redir_socket
    if redir_socket != None:
        redir_socket.close()
        del redir_socket
    redir_socket = zcontext.socket(zmq.REP)
    redir_socket.bind(redir_socket_url)

reinitialize_socket()

print t(), "Redirector initialized, wait for requests."
while True:
    request.Clear()
    try: msg = redir_socket.recv()
    except Exception, err:
        print t(), "Got error on recv:", repr(err)
        continue

    for vm in vm_socket_urls:
        if vm['client'] != None and (time.time() - vm['ping']) > VM_TIMEOUT:
            print t(), "PING timeout for", vm['client'], "-> reassign url"
            vm['client'] = None

    try: request.ParseFromString(msg)
    except Exception, err:
        print t(), "Got error on deserializiation of request:", repr(err), repr(msg)
        response.Clear()
        response.connection_id = 0
        response.type = MT_TRY_AGAIN
        redir_socket.send(response.SerializeToString())
        continue
    
    if request.type == MT_INFO:
        free_vm = None
        random.shuffle(vm_socket_refs)
        for vmid in vm_socket_refs:
            vm = vm_socket_urls[vmid]
            if vm['client'] == None and vm['usable_after'] < time.time():
                free_vm = vm
                break
        response.Clear()
        if free_vm == None:
            response.type = MT_TRY_AGAIN
            print t(), "Got redirection request for", request.connection_id, "-> try again"
        else:
            response.type = MT_CLIENT
            response.client.client_name = free_vm['url']
            response.client.meta_info = 'redirector at %s for connection %s' % (redir_socket_url, str(request.connection_id))
            free_vm['ping'] = time.time()
            free_vm['client'] = request.connection_id
            print t(), "Got redirection request for", request.connection_id, "-> redirect to", vm['url']
        response.connection_id = request.connection_id
        redir_socket.send(response.SerializeToString())
        continue

    if request.type == MT_PING_PONG:
        print t(), "Got ping for", request.connection_id
        for vm in vm_socket_urls:
            if vm['client'] == request.connection_id:
                vm['ping'] = time.time()
        response.Clear()
        response.type = MT_PING_PONG
        response.connection_id = request.connection_id
        redir_socket.send(response.SerializeToString())
        continue
    
    if request.type == MT_CLOSE:
        print t(), "Got close for", request.connection_id
        for vm in vm_socket_urls:
            if vm['client'] == request.connection_id:
                vm['client'] = None
                vm['usable_after'] = time.time() + USABLE_TIMEOUT
        response.Clear()
        response.type = MT_FINISHED
        response.connection_id = request.connection_id
        redir_socket.send(response.SerializeToString())
        continue

    print t(), "Got unknown request for", request.connection_id, "-> send close"
    response.Clear()
    response.type = MT_CLOSE
    response.close.exception_message = "Redirector got unknown request"
    redir_socket.send(response.SerializeToString())
